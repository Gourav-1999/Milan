package com.example.milan

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
