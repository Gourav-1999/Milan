import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:milan/detail_birthdate_page.dart';
import 'package:milan/details_location_page.dart';

class SelectInterestsPage extends StatefulWidget {
  @override
  _SelectInterestsPageState createState() => _SelectInterestsPageState();
}

class _SelectInterestsPageState extends State<SelectInterestsPage> {
  // List of available interests

  List<SelectInterest> listItems = [];
  selectInterest(){
    listItems.clear();
    listItems.add(SelectInterest(icon: Icons.games_rounded, name: 'Gaming'));
    listItems.add(SelectInterest(icon: Icons.science_rounded, name: 'Science'));
    listItems.add(SelectInterest(icon: Icons.music_note_rounded, name: 'Music'));
    listItems.add(SelectInterest(icon: Icons.airplay_rounded, name: 'Technology'));
    listItems.add(SelectInterest(icon: Icons.language_rounded, name: 'Language'));
    listItems.add(SelectInterest(icon: Icons.airplanemode_active_rounded, name: 'Travel'));
    listItems.add(SelectInterest(icon: Icons.sports_cricket_rounded, name: 'Sports'));
    listItems.add(SelectInterest(icon: Icons.self_improvement_outlined, name: 'Meditation'));
    listItems.add(SelectInterest(icon: Icons.sports_gymnastics_rounded, name: 'Gym'));
    listItems.add(SelectInterest(icon: Icons.electric_car_sharp, name: 'Cars'));
    listItems.add(SelectInterest(icon: Icons.menu_book, name: 'Book'));
    listItems.add(SelectInterest(icon: Icons.business, name: 'Business'));
    listItems.add(SelectInterest(icon: Icons.fastfood_rounded, name: 'Food'));

    setState(() {

    });

  }
  @override
  void initState() {
    // TODO: implement initState
    selectInterest();
    super.initState();
  }

  // Set to hold the selected interests
  Set<String> selectedInterests = {};

  @override
  Widget build(BuildContext context) {
    return ScreenUtilInit(
      designSize: const Size(430, 942),
      minTextAdapt: true,
      splitScreenMode: true,
      child: SafeArea(
        child: Scaffold(
          body: Padding(
            padding: EdgeInsets.only(left: 18.w, top: 50.h),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                GestureDetector(
                  onTap: () {
                    Navigator.of(context).pushReplacement(
                      MaterialPageRoute(builder: (BuildContext context) {
                        return const BirthDate();
                      }),
                    );
                  },
                  child: Container(
                    margin: EdgeInsets.only(bottom: 18),
                    height: 30.h,
                    width: 30.w,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(20),
                      shape: BoxShape.rectangle,
                      color: Colors.black.withOpacity(0.025),
                    ),
                    child: const Center(child: Icon(Icons.arrow_back)),
                  ),
                ),
                Text(
                  "Select Your\nInterests",
                  style: GoogleFonts.gabarito(
                      fontSize: 30.sp, fontWeight: FontWeight.w600),
                ),
                SizedBox(
                  height: 15.h,
                ),
                Text(
                  "Millions of interests, endless friendships.",
                  style: GoogleFonts.gabarito(
                      fontSize: 16.sp, fontWeight: FontWeight.w500),
                ),
                SizedBox( height: 20.h,),
                Expanded(
                  child: Container(
                    margin: EdgeInsets.only(right: 18.w),

                    // height: 30.h,
                    // width: 300.w,
                    child: GridView.builder(
                      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                        crossAxisCount: 3, // 2 columns in the grid
                        crossAxisSpacing: 10.0,
                        mainAxisSpacing: 10.0,
                        childAspectRatio: 2
                      ),
                      itemCount: listItems.length,
                      itemBuilder: (context, index) {
                        return GestureDetector(
                          onTap: () {
                            setState(() {
                              if (selectedInterests.contains(listItems[index].name)) {
                                selectedInterests.remove(listItems[index].name);
                              } else {
                                selectedInterests.add(listItems[index].name);
                              }
                            });
                          },
                          child: Container(
                            padding: EdgeInsets.all(5),
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(15.0),
                              color: selectedInterests.contains(listItems[index].name)
                                  ? Colors.white
                                  : Colors.black.withOpacity(0.035),
                              border: selectedInterests.contains(listItems[index].name)?Border.all(width: 1.5,color: Colors.blue)
                                  : Border.all(color: Colors.transparent)
                            ),
                            alignment: Alignment.center,
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Expanded(
                                  child: Text(
                                    listItems[index].name,
                                    textAlign: TextAlign.center,
                                    style: TextStyle(
                                      color: selectedInterests.contains(listItems[index].name)
                                          ? Colors.blue
                                          : Colors.black,
                                    ),
                                  ),
                                ),
                                Icon(listItems[index].icon,color: selectedInterests.contains(listItems[index].name)
                                    ? Colors.blue
                                    : Colors.black,)
                              ],
                            ),
                          ),
                        );
                      },
                    ),
                  ),
                ),
                Center(
                  child: SizedBox(
                    height: 58.h,
                    width: 360.w,
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.black,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(25.0),
                        ), // Background color
                      ),
                      onPressed: () {
                        Navigator.of(context).pushReplacement(
                            MaterialPageRoute(builder: (BuildContext context) {
                              return Location();
                            }));
                      },
                      child: const Text(
                        "Next",
                        style: TextStyle(
                            color: Colors.white,
                            fontSize: 20,
                            overflow: TextOverflow.ellipsis),
                        maxLines: 1,
                      ))
                    ),
                ),
                SizedBox(height: 15.h,)
              ],
            ),
          ),
        ),
      ),
    );
  }
}
class SelectInterest{
  String name;
  IconData icon;
  SelectInterest({required this.icon,required this.name});
}
