import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  @override
  Widget build(BuildContext context) {
    return ScreenUtilInit(
      designSize: const Size(430, 942),
      minTextAdapt: true,
      splitScreenMode: true,
      child: SafeArea(child: Scaffold(
        body: Padding(
          padding: EdgeInsets.only(left: 18.w,top: 30.h),
          child: Column(
            children: [
              Container(
                height: 700.h,
                width: 390.w,
                decoration:  BoxDecoration(
                  borderRadius: BorderRadius.circular(20),
                  image: DecorationImage(
                    image: AssetImage("assets/images/homepagegirl.png"),
                    fit: BoxFit.cover
                  )
                ),
              )
            ],
          ),
        ),
      )),
    );
  }
}
