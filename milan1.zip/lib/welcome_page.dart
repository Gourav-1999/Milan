import 'dart:async';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_onboarding_slider/background_final_button.dart';
import 'package:flutter_onboarding_slider/flutter_onboarding_slider.dart';
import 'package:flutter_overboard/flutter_overboard.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:milan/login_page.dart';

class WelcomePage extends StatefulWidget {
  const WelcomePage({super.key});
  @override
  State<WelcomePage> createState() => _WelcomePage();
}

class _WelcomePage extends State<WelcomePage> {

  @override
  void initState() {
    super.initState();
    Timer(const Duration(seconds: 2),
            () =>
            Navigator.pushReplacement(context,
                MaterialPageRoute(builder:
                    (context) =>
                 Milan()
                )
            )
    );
  }

  @override
  Widget build(BuildContext context) {
    return Container(
        alignment: Alignment.center,
        color: Colors.white,
        child: Image(image: AssetImage("assets/overboard/heartimg.png"),)
    );
  }
}
class Milan extends StatelessWidget {
   Milan({super.key});

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body: ScreenUtilInit(
          designSize: const Size(430, 932),
          minTextAdapt: true,
          splitScreenMode: true,
          child: OnBoardingSlider(
            finishButtonTextStyle: TextStyle(color: Colors.white,fontSize: 20),
            controllerColor: Colors.black,
            headerBackgroundColor: Colors.white,
            skipIcon: const Text("Next",style: TextStyle(color: Colors.white,fontSize: 20),),
            finishButtonText: 'Get Started',
            onFinish: () {
              Navigator
                  .of(context)
                  .pushReplacement(new MaterialPageRoute(builder: (BuildContext context) {
                return new LoginPage();
              }));
            },
            finishButtonStyle: const FinishButtonStyle(
              backgroundColor: Colors.black,
            ),
            skipTextButton: const Text(
              "Skip",
              maxLines: 1,
              style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                  decoration: TextDecoration.underline,
                  color: Colors.black,
                  decorationColor: Colors.black,
                  decorationThickness: 1),
            ),
            background: [
              Padding(
                padding: const EdgeInsets.only(top: 200),
                child: Image.asset(
                    'assets/overboard/Group1.png',
                    width: 390, height: 506.0
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(top: 180,left: 40),
                child: Image.asset(
                    'assets/overboard/Group2.png',
                    width: 327.73, height: 543.0
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(top: 120),
                child: Image.asset(
                    'assets/overboard/Group3.png',
                    width: 409.95, height: 584.0
                ),
              ),
            ],
            totalPage: 3,
            speed: 1.8,
            pageBodies: [
            Column(crossAxisAlignment: CrossAxisAlignment.start,
             children: [
               Padding(
                 padding: const EdgeInsets.only(left: 34,top: 10),
                 child: Text("Find Amazing",
                    style: GoogleFonts.gabarito(
                    fontSize: 35,
                    fontWeight: FontWeight.w400,
                    ),
                    ),
               ),
               Padding(
                 padding: const EdgeInsets.only(left: 34),
                 child: Text("People Around You",
                   style:GoogleFonts.gabarito(
                     fontSize: 35,
                     fontWeight: FontWeight.w800
                   ),
                 ),
               ),
             ],
             ),
              Column(crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Padding(
                    padding: const EdgeInsets.only(left: 34,top: 10),
                    child: Text("Connect With",
                      style: GoogleFonts.gabarito(
                        fontSize: 35,
                        fontWeight: FontWeight.w400,
                      ),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(left: 34),
                    child: Text("Friends Nearby",
                      style:GoogleFonts.gabarito(
                          fontSize: 35,
                          fontWeight: FontWeight.w800
                      ),
                    ),
                  ),
                ],
              ),
              Column(crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Padding(
                    padding: const EdgeInsets.only(left: 34,top: 10),
                    child: Text("Start Building",
                      style: GoogleFonts.gabarito(
                        fontSize: 35,
                        fontWeight: FontWeight.w400,
                      ),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(left: 34),
                    child: Text("Your Local Network",
                      style:GoogleFonts.gabarito(
                          fontSize: 35,
                          fontWeight: FontWeight.w800
                      ),
                    ),
                  ),
                ],
              ),
            ],
          )
        ),
      ),
    );
  }
}
