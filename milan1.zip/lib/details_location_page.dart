import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:milan/detail_manual_locatio_page.dart';
import 'package:milan/detail_photograph_page.dart';
import 'detail_children_page.dart';
import 'detail_interest_page.dart';  // Assuming this is your next screen

class Location extends StatefulWidget {
  const Location({super.key});

  @override
  State<Location> createState() => _LocationState();
}

class _LocationState extends State<Location> {
  DateTime? selectedDate;

  @override
  Widget build(BuildContext context) {
    return ScreenUtilInit(
      designSize: const Size(430, 942),
      minTextAdapt: true,
      splitScreenMode: true,
      child: SafeArea(
        child: Scaffold(
          body: Padding(
            padding: EdgeInsets.only(left: 18.w, top: 50.h),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                GestureDetector(
                  onTap: () {
                    Navigator.of(context).pushReplacement(
                      MaterialPageRoute(builder: (BuildContext context) {
                        return SelectInterestsPage();
                      }),
                    );
                  },
                  child: Container(
                    margin: EdgeInsets.only(bottom: 18),
                    height: 30.h,
                    width: 30.w,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(20),
                      shape: BoxShape.rectangle,
                      color: Colors.black.withOpacity(0.025),
                    ),
                    child: const Center(child: Icon(Icons.arrow_back)),
                  ),
                ),
                Text(
                  "What is Your\nLocation?",
                  style: GoogleFonts.gabarito(
                      fontSize: 30.sp, fontWeight: FontWeight.w600),
                ),
                SizedBox(
                  height: 15.h,
                ),
                Text(
                  "Close the distance, connect with friends.",
                  style: GoogleFonts.gabarito(
                      fontSize: 16.sp, fontWeight: FontWeight.w500),
                ),
                SizedBox(
                  height: 60.h,
                ),
                Center(
                  child: Column(
                    children: [
                      Container(
                        margin: EdgeInsets.only(right: 18.w),
                        height: 277.h,
                        width: 226.w,
                        decoration: const BoxDecoration(
                          image: DecorationImage(
                            image: AssetImage("assets/images/location.png"),
                            fit: BoxFit.cover
                          )
                        ),
                      ),
                      Container(
                        margin: EdgeInsets.only(right: 18.w),
                        height: 240.h,
                        width: 226.w,
                        child: Text(
                          "1609 W Brandon Blvd, Brandon, Florida, United States",
                          style: GoogleFonts.gabarito(
                              fontSize: 16.sp, fontWeight: FontWeight.w400),
                          maxLines: 3,
                          textAlign: TextAlign.center,
                        ),
                      ),
                      GestureDetector(
                        onTap: (){
                          Navigator.of(context).pushReplacement(
                              MaterialPageRoute(builder: (BuildContext context) {
                                return EnterLocation();
                              }));
                        },
                        child: Text(
                          "Enter Location Manually",
                          style: GoogleFonts.gabarito(
                              fontSize: 16.sp, fontWeight: FontWeight.w500,
                            color:Colors.blue,),
                          textAlign: TextAlign.center,
                        ),
                      ),
                    ],
                  ),
                ),
                 SizedBox(height: 10.h,),
                 Center(child: _submitBoxButton)
              ],
            ),
          ),
        ),
      ),
    );
  }
}
Widget get _submitBoxButton => SizedBox(
  height: 58.h,
  width: 360.w,
  child: Builder(builder: (context) {
    return ElevatedButton(
        style: ElevatedButton.styleFrom(
          backgroundColor: Colors.black,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(25.0),
          ), // Background color
        ),
        onPressed: () {
          Navigator.of(context).pushReplacement(
              new MaterialPageRoute(builder: (BuildContext context) {
                return new YourPhotographs();
              }));
        },
        child: const Text(
          "Next",
          style: TextStyle(
              color: Colors.white,
              fontSize: 20,
              overflow: TextOverflow.ellipsis),
          maxLines: 1,
        ));
  }),
);