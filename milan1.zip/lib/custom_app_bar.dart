import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
class CustomAppBar extends StatelessWidget implements PreferredSizeWidget {
  int index;
  String title;
  CustomAppBar({super.key, required this.index, required this.title});

  @override
  Widget build(BuildContext context) {
    return index == 0
        ? Row(
          children: [
            Expanded(
                child: Text(
              title,
                  style: GoogleFonts.gabarito(
                      fontSize: 18, fontWeight: FontWeight.w600),
                ),
            ),
          ],
        )
        : index == 1
            ? Row(
              children: [
                Expanded(
                    child: Text(
                  title,
                      style: GoogleFonts.lato(
                          fontSize: 16, fontWeight: FontWeight.w500),
                )),
              ],
            )
            : index == 2
                ? Row(
                  children: [
                    Expanded(
                        child: Text(
                      title,
                          style: GoogleFonts.gabarito(
                              fontSize: 20, fontWeight: FontWeight.w700),
                    )),
                  ],
                )
                : Row(
                    children: [
                      Expanded(
                          child: Text(
                        title,
                            style: GoogleFonts.lato(
                                fontSize: 16, fontWeight: FontWeight.w500),
                      )),
                    ],
                  );
  }

  @override
  // TODO: implement preferredSize
  Size get preferredSize => const Size.fromHeight(60);
}
