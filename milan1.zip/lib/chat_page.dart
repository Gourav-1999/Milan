import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import 'package:milan/custom_app_bar.dart';

class Chat extends StatefulWidget {
  const Chat({super.key});

  @override
  State<Chat> createState() => _ChatState();
}
DateTime _date = DateTime.now();
String date = DateFormat('dd/MM/y').format(_date);

String tm = DateFormat('hh:mm ').format(_date);

String day = DateFormat('EEEE').format(_date);

String hours = DateFormat('jz').format(_date);

int index=2;
List<UserDataModal> dataList = [];
class _ChatState extends State<Chat> {
  initDataList() {
    dataList.clear();

    dataList.add(
        UserDataModal(images: "assets/chat/download.png", names: "Joker",time: tm,msg: "Hi!"));
    dataList.add(
        UserDataModal(images: "assets/chat/download1.png", names: "Adam",time: hours,msg: "Good Morning!"));
    dataList.add(
        UserDataModal(images: "assets/chat/download2.png", names: "Kate",time: tm,msg: "Who like me."));
    dataList.add(
        UserDataModal(images: "assets/chat/download.png", names: "Robin",time: day,msg: "Hi,everyone!"));
    dataList.add(
        UserDataModal(images: "assets/chat/download1.png", names: "Sara",time: day,msg: "Come talk to me!"));
    dataList.add(
        UserDataModal(images: "assets/chat/download2.png", names: "Victor",time: hours,msg: "Hello."));
    dataList.add(
        UserDataModal(images: "assets/chat/download.png", names: "Thomas",time: tm,msg: "Can we friends?"));
    dataList.add(
        UserDataModal(images: "assets/chat/download1.png", names: "Jack",time: date,msg: "Are you single?"));
    dataList.add(
        UserDataModal(images: "assets/chat/download2.png", names: "Francis",time: tm,msg: "Hi!"));
    dataList.add(
        UserDataModal(images: "assets/chat/download1.png", names: "Cobra",time: tm,msg: "Hi!"));
    setState(() {});
  }
  @override
  void initState() {
    // TODO: implement initState
    initDataList();
    super.initState();
  }
  @override
  Widget build(BuildContext context) {
    return  ScreenUtilInit(
      designSize: const Size(430, 942),
      minTextAdapt: true,
      splitScreenMode: true,
      child: SafeArea(child: Scaffold(
        resizeToAvoidBottomInset : false,
        body: Padding(
          padding: EdgeInsets.only(top:25.h,left:18.w),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              CustomAppBar(title: "Chat",index: 2,),
              SizedBox(height: 20.h,),
              Container(
                height: 700,
                child: Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      _customSearchBarWidget,
                      SizedBox(height: 10.h,),
                      _customUserDataWidget
                    ],
                  ),
                ),
              )
            ],
          ),
        ),
      )),
    );
  }
}
Widget get _customSearchBarWidget => Container(
  margin: EdgeInsets.only(right: 18.w),
  decoration: BoxDecoration(
      color: Colors.black.withOpacity(0.035),
      borderRadius: BorderRadius.circular(10)
  ),
  child: TextFormField(
    textInputAction: TextInputAction.done,
    keyboardType: TextInputType.text,
    decoration:  InputDecoration(
      fillColor: Colors.black.withOpacity(0.025),
      contentPadding: const EdgeInsets.only(left: 20,right: 10,top: 10,bottom: 10),
      border: InputBorder.none,
      prefixIcon: const Icon(Icons.search),
      hintText: 'Search',
      hintStyle: const TextStyle(
          color: Colors.grey,
          overflow: TextOverflow.ellipsis),
    ),
    maxLines: 1,
  ),
);

Widget get _customUserDataWidget => Expanded(
  child: Container(
    margin: const EdgeInsets.all(10),
    height: 40,
    child: ListView.builder(
      controller: ScrollController(),
      itemCount: dataList.length,
      itemBuilder: (context, index) {
        return GestureDetector(
          onTap: () {},
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
                  Container(
                height: 50,
                width: 52,
                margin: const EdgeInsets.only(bottom: 15),
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  image: DecorationImage(
                      image: AssetImage(dataList[index].images),
                      fit: BoxFit.cover),
                ),
              ),
              Expanded(
                child: Container(
                  margin: const EdgeInsets.only(left: 10),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        dataList[index].names,
                        style: GoogleFonts.gabarito(
                            fontSize: 18, fontWeight: FontWeight.w700),
                      ),
                      //  Text("Joker",style: TextStyle(fontSize: 20,fontWeight: FontWeight.bold),),
                       Text(
                        dataList[index].msg,
                        overflow: TextOverflow.ellipsis,
                        style: GoogleFonts.gabarito(
                            fontSize: 16, fontWeight: FontWeight.w500,),
                      )
                    ],
                  ),
                ),
              ),
              Column(
                children: [
                  Text(dataList[index].time,
                      style: const TextStyle(
                          color: Colors.grey,
                          fontWeight: FontWeight.bold)),
                ],
              )
            ],
          ),
        );
      },
      shrinkWrap: true,
    ),
  ),
);

class UserDataModal {
  late String images, names, time, msg;

  UserDataModal({required this.images, required this.names,required this.time,required this.msg});
}
