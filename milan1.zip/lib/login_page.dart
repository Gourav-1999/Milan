import 'package:country_code_picker/country_code_picker.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:milan/otp_page.dart';

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  @override
  Widget build(BuildContext context) {
    return ScreenUtilInit(
      designSize: const Size(430, 942),
      minTextAdapt: true,
      splitScreenMode: true,
      child: SafeArea(
        child: Scaffold(
          body: SingleChildScrollView(
            child: Stack(
              children: [
                Container(
                    height: 932.h,
                    width: 455.w,
                    decoration: const BoxDecoration(
                      image: DecorationImage(
                        image: AssetImage("assets/images/login.png"),fit: BoxFit.fill
                      )
                    ),),
                Positioned(
                    top: 550,
                    child: Container(
                  height: 400.h,
                  width: 430.w,
                  decoration: const BoxDecoration(
                    color: Colors.white,
                    shape: BoxShape.rectangle,
                    borderRadius: BorderRadius.only(topLeft: Radius.circular(20),topRight: Radius.circular(20)),
                  ),
                  child: Padding(
                    padding: const EdgeInsets.only(left: 20,right: 20),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text("Enter Your\nPhone Number",style:GoogleFonts.gabarito(
                        fontSize: 30.sp,
                        fontWeight: FontWeight.w600
                    ),),
                        Text("Unlock your experience.",style:GoogleFonts.gabarito(
                            fontSize: 18,
                            fontWeight: FontWeight.w400
                        ),),
                        SizedBox(height: 12.h,),
                        _textField,
                        SizedBox(height: 12.h,),
                        _checkBoxButton
                      ],
                    ),
                  ),
                ))
              ],
            ),
          )
        ),
      ),
    );
  }
}
Widget get _checkBoxButton => SizedBox(
  height: 58.h,
  width: 400.w,
  child: Builder(builder: (context) {
    return ElevatedButton(
        style: ElevatedButton.styleFrom(
          backgroundColor: Colors.black,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(25.0),
          ), // Background color
        ),
        onPressed: () {
          Navigator
              .of(context)
              .pushReplacement(new MaterialPageRoute(builder: (BuildContext context) {
            return new OTP();
          }));
        },
        child: const Text(
          "Continue",
          style: TextStyle(
              color: Colors.white, fontSize: 20, overflow: TextOverflow.ellipsis),
          maxLines: 1,
        ));
  }),
);
Widget get _textField =>  Container(
  decoration: BoxDecoration(
      color: Colors.grey.withOpacity(0.2),
    borderRadius: BorderRadius.circular(20)
  ),
  child: TextFormField(
    textInputAction: TextInputAction.done,
    keyboardType: TextInputType.number,
    decoration:  InputDecoration(
      fillColor: Colors.grey,
      contentPadding: const EdgeInsets.all(10),
      prefixIcon: SizedBox(
        height: 30.h,
        width: 110.w,
        child:  Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            CountryCodePicker(
              onChanged: print,
              // Initial selection and favorite can be one of code ('IT') OR dial_code('+39')
              initialSelection: 'US',
              favorite: const ['+39', 'FR'],
              // countryFilter: const ['IT', 'FR'],
              flagWidth: 20.w,
              showFlag: true,
              showOnlyCountryWhenClosed: false,
              showCountryOnly: false,
              // flag can be styled with BoxDecoration's `borderRadius` and `shape` fields
            ),
          ],
        ),
      ),
      border: InputBorder.none,
      hintText: '| Enter Phone Number',
      hintStyle: const TextStyle(
          color: Colors.grey,
          overflow: TextOverflow.ellipsis),
    ),
    maxLines: 1,
  ),
);
