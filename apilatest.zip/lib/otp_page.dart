import 'dart:async';
import 'dart:convert';
import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:flutter_otp_text_field/flutter_otp_text_field.dart';
import 'package:milan/models/user_model.dart';
import 'package:milan/detail_name_page.dart';
import 'package:milan/login_page.dart';

import 'commons/local_storage.dart';

class OTP extends StatefulWidget {
  final String phoneNumber;
  final String isoCode;
  final String countryCode;

  OTP({
    required this.countryCode,
    required this.isoCode,
    required this.phoneNumber,
    super.key,
  });

  @override
  State<OTP> createState() => _OTPState();
}

class _OTPState extends State<OTP> {
  final TextEditingController otpController = TextEditingController();
  bool _isLoading = false;
  Dio dio = Dio();

  Timer? _timer;
  void configLoading() {
    EasyLoading.instance
      ..displayDuration = const Duration(milliseconds: 2000)
      ..indicatorType = EasyLoadingIndicatorType.fadingCircle
      ..loadingStyle = EasyLoadingStyle.dark
      ..indicatorSize = 45.0
      ..radius = 10.0
      ..progressColor = Colors.yellow
      ..backgroundColor = Colors.green
      ..indicatorColor = Colors.yellow
      ..textColor = Colors.yellow
      ..maskColor = Colors.blue.withOpacity(0.5)
      ..userInteractions = true
      ..dismissOnTap = false
      ..customAnimation = CustomAnimation();
  }

  void showSnackBar(String message) {
    ScaffoldMessenger.of(context)
        .showSnackBar(SnackBar(content: Text(message)));
  }

  Future<void> postPhoneData() async {
    if (otpController.text.isEmpty) {
      showSnackBar('Please enter a valid OTP');
      return;
    }

    Map<String, dynamic> map = {
      'iso_code': widget.isoCode.toLowerCase(),
      'phone_code': widget.countryCode,
      'phone': widget.phoneNumber,
      'otp': otpController.text,
      // 'fcm_token': '12345',
    };

    String url = 'http://192.168.2.42:8004/api/v1/verify-firebase';
    try {
      setState(() {
        _isLoading = true;
      });

      final response = await dio.post(
        url,
        data: jsonEncode(map),
        options: Options(
          headers: {
            'Content-Type': 'application/json',
          },
        ),
      );

      print(response.data);
      UserModal userModal = UserModal.fromJson(response.data);
      print("User--${userModal.message}");

      if (response.statusCode == 200) {
        await LocalStorage.storeToken(userModal.data?.rememberToken ?? "");
       print( "Token----- ${await LocalStorage.getToken()}");
        Navigator.of(context).pushReplacement(
          MaterialPageRoute(builder: (BuildContext context) => EnterName()),
        );
      } else {
        showSnackBar('Error: ${response.statusCode}');
        print(response.statusCode);
      }
    } catch (e) {
      showSnackBar('Failed to send data: $e');
      print(e);
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  // Resend OTP
  Future<void> resendOTP() async {
    String url = 'http://192.168.2.34:8004/api/v1/resend-otp';
    Map<String, dynamic> map = {
      'iso_code': widget.isoCode.toLowerCase(),
      'phone_code': widget.countryCode,
      'phone': widget.phoneNumber,
    };

    try {
      final response = await dio.post(url, data: jsonEncode(map));

      if (response.statusCode == 200) {
        showSnackBar('OTP resent successfully!');
      } else {
        showSnackBar('Failed to resend OTP');
      }
    } catch (e) {
      showSnackBar('Failed to resend OTP: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    return ScreenUtilInit(
      designSize: const Size(430, 942),
      minTextAdapt: true,
      splitScreenMode: true,
      child: SafeArea(
        child: Scaffold(
          body: Padding(
            padding: EdgeInsets.only(left: 18.w, top: 50.h, right: 18.w),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                GestureDetector(
                  onTap: () {
                    Navigator.of(context).pushReplacement(
                      MaterialPageRoute(builder: (BuildContext context) {
                        return LoginPage();
                      }),
                    );
                  },
                  child: Container(
                    margin: EdgeInsets.only(bottom: 18),
                    height: 50.h,
                    width: 50.w,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: Colors.black.withOpacity(0.025),
                    ),
                    child: const Center(child: Icon(Icons.arrow_back)),
                  ),
                ),
                Text(
                  "Enter Your\nVerification Code",
                  style: GoogleFonts.gabarito(
                      fontSize: 30.sp, fontWeight: FontWeight.w600),
                ),
                SizedBox(height: 15.h),
                Text(
                  "Please enter the code we just sent to number",
                  style: GoogleFonts.gabarito(
                      fontSize: 16.sp, fontWeight: FontWeight.w500),
                ),
                SizedBox(height: 5.h),
                Row(
                  children: [
                    Text(
                      widget.phoneNumber,
                      style: GoogleFonts.gabarito(
                          fontSize: 16.sp, fontWeight: FontWeight.w500),
                    ),
                    SizedBox(width: 5.w),
                    Container(
                      height: 30.h,
                      width: 65.w,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(20),
                        shape: BoxShape.rectangle,
                        border: Border.all(width: 1, color: Colors.blue),
                      ),
                      child: const Center(
                        child: Text(
                          "Change",
                          style: TextStyle(color: Colors.blue),
                        ),
                      ),
                    ),
                  ],
                ),
                SizedBox(height: 10.h),
                OtpTextField(
                  fieldHeight: 60.h,
                  fieldWidth: 45.w,
                  keyboardType: TextInputType.number,
                  showFieldAsBox: true,
                  focusedBorderColor: Colors.white,
                  enabledBorderColor: Colors.white,
                  borderColor: Colors.black.withOpacity(0.0),
                  fillColor: Colors.black.withOpacity(0.075),
                  filled: true,
                  borderRadius: BorderRadius.circular(30),
                  numberOfFields: 6,
                  decoration: const InputDecoration(
                    border: InputBorder.none,
                  ),
                  onSubmit: (String code) {
                    otpController.text = code;
                    setState(() {});
                  },
                ),
                SizedBox(height: 20.h),
                Center(
                  child: Text(
                    "Didn’t receive verification code?",
                    style: GoogleFonts.gabarito(
                        fontSize: 14.sp, fontWeight: FontWeight.w400),
                  ),
                ),
                Center(
                  child: GestureDetector(
                    onTap: () {
                      resendOTP();
                    },
                    child: Text(
                      "Resend Code",
                      style: GoogleFonts.gabarito(
                          fontSize: 14.sp,
                          color: Colors.blue,
                          fontWeight: FontWeight.w400),
                    ),
                  ),
                ),
                // SizedBox(height: 420.h),
                Spacer(),
                Center(
                  child: SizedBox(
                    height: 58.h,
                    width: 400.w,
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.black,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(25.0),
                        ),
                      ),
                      onPressed: ()  {
                        if (otpController.text.isEmpty) {
                          showSnackBar("Please enter OTP");
                        } else {
                          postPhoneData();
                        }
                      },
                      child: const Text(
                        "Verify",
                        style: TextStyle(
                            color: Colors.white,
                            fontSize: 20,
                            overflow: TextOverflow.ellipsis),
                        maxLines: 1,
                      ),
                    ),
                  ),
                ),
                SizedBox(height: 10.h),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
class CustomAnimation extends EasyLoadingAnimation {
  CustomAnimation();

  @override
  Widget buildWidget(
      Widget child,
      AnimationController controller,
      AlignmentGeometry alignment,
      ) {
    return Opacity(
      opacity: controller.value,
      child: RotationTransition(
        turns: controller,
        child: child,
      ),
    );
  }
}