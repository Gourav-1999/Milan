import 'package:milan/chat_page.dart';

class UserModal {
  int? status;
  String? message;
  UserDataModal? data;

  UserModal({this.status, this.message, this.data});

  UserModal.fromJson(Map<String, dynamic> json) {
    status = json['status'];
    message = json['message'];
    data = json['data'] != null ? UserDataModal.fromJson(json['data']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['status'] = status;
    data['message'] = message;
    if (this.data != null) {
      data['data'] = this.data!.toJson();
    }
    return data;
  }
}

class UserDataModal {
  var id;
  var name;
  var email;
  var emailVerifyToken;
  var emailVerifiedAt;
  var isoCode;
  var phoneCode;
  var phone;
  var phoneVerifiedAt;
  var dob;
  var age;
  var address;
  var latitude;
  var longitude;
  var about;
  var preferedDistance;
  var minAge;
  var maxAge;
  var enableDiscovery;
  var isChat;
  var matchId;
  var activeStatus;
  var roleId;
  var gender;
  var showGender;
  var interestedIn;
  var showInterestedIn;
  var relationStatus;
  var showRelationStatus;
  var lookingFor;
  var showLookingFor;
  var ethnicity;
  var showEthnicity;
  var childrenType;
  var showChildrenType;
  var steps;
  var fcmToken;
  var rememberToken;
  var isNotify;
  var deviceType;
  var typeId;
  var stateId;
  var createdAt;
  var updatedAt;
  var genderRel;
  List<String>? interests;
  List<String>? userImages;

  UserDataModal(
      {this.id,
        this.name,
        this.email,
        this.emailVerifyToken,
        this.emailVerifiedAt,
        this.isoCode,
        this.phoneCode,
        this.phone,
        this.phoneVerifiedAt,
        this.dob,
        this.age,
        this.address,
        this.latitude,
        this.longitude,
        this.about,
        this.preferedDistance,
        this.minAge,
        this.maxAge,
        this.enableDiscovery,
        this.isChat,
        this.matchId,
        this.activeStatus,
        this.roleId,
        this.gender,
        this.showGender,
        this.interestedIn,
        this.showInterestedIn,
        this.relationStatus,
        this.showRelationStatus,
        this.lookingFor,
        this.showLookingFor,
        this.ethnicity,
        this.showEthnicity,
        this.childrenType,
        this.showChildrenType,
        this.steps,
        this.fcmToken,
        this.rememberToken,
        this.isNotify,
        this.deviceType,
        this.typeId,
        this.stateId,
        this.createdAt,
        this.updatedAt,
        this.genderRel,
        this.interests,
        this.userImages});

  UserDataModal.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    name = json['name'];
    email = json['email'];
    emailVerifyToken = json['email_verify_token'];
    emailVerifiedAt = json['email_verified_at'];
    isoCode = json['iso_code'];
    phoneCode = json['phone_code'];
    phone = json['phone'];
    phoneVerifiedAt = json['phone_verified_at'];
    dob = json['dob'];
    age = json['age'];
    address = json['address'];
    latitude = json['latitude'];
    longitude = json['longitude'];
    about = json['about'];
    preferedDistance = json['prefered_distance'];
    minAge = json['min_age'];
    maxAge = json['max_age'];
    enableDiscovery = json['enable_discovery'];
    isChat = json['isChat'];
    matchId = json['match_id'];
    activeStatus = json['active_status'];
    roleId = json['role_id'];
    gender = json['gender'];
    showGender = json['show_gender'];
    interestedIn = json['interested_in'];
    showInterestedIn = json['show_interested_in'];
    relationStatus = json['relation_status'];
    showRelationStatus = json['show_relation_status'];
    lookingFor = json['looking_for'];
    showLookingFor = json['show_looking_for'];
    ethnicity = json['ethnicity'];
    showEthnicity = json['show_ethnicity'];
    childrenType = json['children_type'];
    showChildrenType = json['show_children_type'];
    steps = json['steps'];
    fcmToken = json['fcm_token'];
    rememberToken = json['remember_token'];
    isNotify = json['is_notify'];
    deviceType = json['device_type'];
    typeId = json['type_id'];
    stateId = json['state_id'];
    createdAt = json['created_at'];
    updatedAt = json['updated_at'];
    genderRel = json['gender_rel'];
    interests = json['interests'] != null ? List<String>.from(json['interests']) : null;
    userImages = json['user_images'] != null ? List<String>.from(json['user_images']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['id'] = id;
    data['name'] = name;
    data['email'] = email;
    data['email_verify_token'] = emailVerifyToken;
    data['email_verified_at'] = emailVerifiedAt;
    data['iso_code'] = isoCode;
    data['phone_code'] = phoneCode;
    data['phone'] = phone;
    data['phone_verified_at'] = phoneVerifiedAt;
    data['dob'] = dob;
    data['age'] = age;
    data['address'] = address;
    data['latitude'] = latitude;
    data['longitude'] = longitude;
    data['about'] = about;
    data['prefered_distance'] = preferedDistance;
    data['min_age'] = minAge;
    data['max_age'] = maxAge;
    data['enable_discovery'] = enableDiscovery;
    data['isChat'] = isChat;
    data['match_id'] = matchId;
    data['active_status'] = activeStatus;
    data['role_id'] = roleId;
    data['gender'] = gender;
    data['show_gender'] = showGender;
    data['interested_in'] = interestedIn;
    data['show_interested_in'] = showInterestedIn;
    data['relation_status'] = relationStatus;
    data['show_relation_status'] = showRelationStatus;
    data['looking_for'] = lookingFor;
    data['show_looking_for'] = showLookingFor;
    data['ethnicity'] = ethnicity;
    data['show_ethnicity'] = showEthnicity;
    data['children_type'] = childrenType;
    data['show_children_type'] = showChildrenType;
    data['steps'] = steps;
    data['fcm_token'] = fcmToken;
    data['remember_token'] = rememberToken;
    data['is_notify'] = isNotify;
    data['device_type'] = deviceType;
    data['type_id'] = typeId;
    data['state_id'] = stateId;
    data['created_at'] = createdAt;
    data['updated_at'] = updatedAt;
    data['gender_rel'] = genderRel;
    if (interests != null) {
      data['interests'] = interests;
    }
    if (userImages != null) {
      data['user_images'] = userImages;
    }
    return data;
  }
}