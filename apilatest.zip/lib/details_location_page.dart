import 'dart:convert';

import 'package:dio/dio.dart';

import 'package:flutter/cupertino.dart';

import 'package:flutter/material.dart';

import 'package:flutter_screenutil/flutter_screenutil.dart';

import 'package:google_fonts/google_fonts.dart';

// import 'package:geolocator/geolocator.dart';

import 'package:milan/detail_manual_locatio_page.dart';

import 'package:milan/detail_photograph_page.dart';

import 'package:milan/commons/local_storage.dart';

import 'package:milan/detail_interest_page.dart';

import 'models/user_model.dart';

class Location extends StatefulWidget {
  const Location({super.key});

  @override
  State<Location> createState() => _LocationState();
}

class _LocationState extends State<Location> {
  DateTime? selectedDate;

  int currentIndex = 0;

  final Dio _dio = Dio();

  final String apiUrl = 'http://192.168.2.42:8004/api/v1/update-details';

  String _currentAddress = "Fetching location...";

  double? _latitude;

  double? _longitude;

  @override
  void initState() {
    super.initState();

   // _getCurrentLocation();
  }

  // Future<void> _getCurrentLocation() async {
  //   bool serviceEnabled;
  //
  //   LocationPermission permission;
  //
  //
  //
  //   serviceEnabled = await Geolocator.isLocationServiceEnabled();
  //
  //   if (!serviceEnabled) {
  //     ScaffoldMessenger.of(context).showSnackBar(
  //       const SnackBar(content: Text('Location services are disabled')),
  //     );
  //
  //     return;
  //   }
  //
  //
  //
  //   permission = await Geolocator.checkPermission();
  //
  //   if (permission == LocationPermission.denied) {
  //     permission = await Geolocator.requestPermission();
  //
  //     if (permission == LocationPermission.denied) {
  //       ScaffoldMessenger.of(context).showSnackBar(
  //         const SnackBar(content: Text('Location permission denied')),
  //       );
  //
  //       return;
  //     }
  //   }
  //
  //
  //
  //   Position position = await Geolocator.getCurrentPosition(
  //       desiredAccuracy: LocationAccuracy.high);
  //
  //   setState(() {
  //     _latitude = position.latitude;
  //
  //     _longitude = position.longitude;
  //
  //     _currentAddress =
  //         "Latitude: ${position.latitude}, Longitude: ${position.longitude}";
  //   });
  // }



  Future<void> postLocation(String address) async {
    if (_latitude == null || _longitude == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Location not available')),
      );

      return;
    }

    Map<String, dynamic> map = {
      "address": address,

      "latitude": _latitude,

      "longitude": _longitude,

      "steps": 10,
    };

    try {
      final response = await _dio.post(
        apiUrl,
        data: jsonEncode(map),
        options: Options(
          headers: {
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ${await LocalStorage.getToken()}'
          },
        ),
      );

      print(response.data);

      print(map);

      UserModal userModal = UserModal.fromJson(response.data);

      print("Status--${userModal?.data?.gender}");

      if (response.statusCode == 200) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Successfully added location')),
        );

        Navigator.of(context)
            .pushReplacement(MaterialPageRoute(builder: (BuildContext context) {
          return YourPhotographs(); // Navigate to the next screen
        }));
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Error: Failed to add location')),
        );
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Failed to add location')),
      );

      print(e);
    }
  }

  @override
  Widget build(BuildContext context) {
    return ScreenUtilInit(
      designSize: const Size(430, 942),
      minTextAdapt: true,
      splitScreenMode: true,
      child: SafeArea(
        child: Scaffold(
          body: Padding(
            padding: EdgeInsets.only(left: 18.w, top: 50.h, right: 18.w),
            child: SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  GestureDetector(
                    onTap: () {
                      Navigator.of(context).pushReplacement(
                        MaterialPageRoute(builder: (BuildContext context) {
                          return SelectInterestsPage();
                        }),
                      );
                    },
                    child: Container(
                      margin: EdgeInsets.only(bottom: 18),
                      height: 50.h,
                      width: 50.w,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: Colors.black.withOpacity(0.025),
                      ),
                      child: const Center(child: Icon(Icons.arrow_back)),
                    ),
                  ),
                  Text(
                    "What is Your\nLocation?",
                    style: GoogleFonts.gabarito(
                        fontSize: 30.sp, fontWeight: FontWeight.w600),
                  ),
                  SizedBox(
                    height: 15.h,
                  ),
                  Text(
                    "Close the distance, connect with friends.",
                    style: GoogleFonts.gabarito(
                        fontSize: 16.sp, fontWeight: FontWeight.w500),
                  ),
                  SizedBox(
                    height: 60.h,
                  ),
                  Center(
                    child: Column(
                      children: [
                        Container(
                          margin: EdgeInsets.only(right: 18.w),
                          height: 277.h,
                          width: 226.w,
                          decoration: const BoxDecoration(
                              image: DecorationImage(
                                  image:
                                      AssetImage("assets/images/location.png"),
                                  fit: BoxFit.cover)),
                        ),
                        Container(
                          margin: EdgeInsets.only(right: 18.w),
                          height: 220.h,
                          width: 226.w,
                          child: Text(
                            _currentAddress,
                            // Display the fetched location coordinates

                            style: GoogleFonts.gabarito(
                                fontSize: 16.sp, fontWeight: FontWeight.w400),

                            maxLines: 3,

                            textAlign: TextAlign.center,
                          ),
                        ),
                        GestureDetector(
                          onTap: () {
                            Navigator.of(context).pushReplacement(
                                MaterialPageRoute(
                                    builder: (BuildContext context) {
                              return EnterLocation();
                            }));
                          },
                          child: Text(
                            "Enter Location Manually",
                            style: GoogleFonts.gabarito(
                              fontSize: 16.sp,
                              fontWeight: FontWeight.w500,
                              color: Colors.blue,
                            ),
                            textAlign: TextAlign.center,
                          ),
                        ),
                      ],
                    ),
                  ),
                  SizedBox(
                    height: 10.h,
                  ),
                  Center(
                    child: SizedBox(
                      height: 58.h,
                      width: 400.w,
                      child: ElevatedButton(
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.black,

                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(25.0),
                            ), // Background color
                          ),
                          onPressed: () {
                            postLocation(
                                _currentAddress); // Send current location to API
                          },
                          child: const Text(
                            "Next",
                            style: TextStyle(
                                color: Colors.white,
                                fontSize: 20,
                                overflow: TextOverflow.ellipsis),
                            maxLines: 1,
                          )),
                    ),
                  ),
                  SizedBox(
                    height: 10.h,
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
