import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:milan/request_button_page.dart';
class CustomAppBar extends StatelessWidget implements PreferredSizeWidget {
  int index;
  String title;
  CustomAppBar({super.key, required this.index, required this.title});

  @override
  Widget build(BuildContext context) {
    return index == 0
        ? Row(
          children: [
            Expanded(
                child: Text(
              title,
                  style: GoogleFonts.gabarito(
                      fontSize: 18, fontWeight: FontWeight.w600),
                ),
            ),
          ],
        )
        : index == 1
            ? Row(
              children: [
                Expanded(
                    child: Text(
                  title,
                      style: GoogleFonts.gabarito(
                          fontSize: 18, fontWeight: FontWeight.w600),
                )),
                Container(
                  height: 25,
                  width: 85,
                  margin: const EdgeInsets.only(right: 18),
                  alignment: Alignment.center,
                  decoration: BoxDecoration(
                    color: Colors.black,
                    shape: BoxShape.rectangle,
                    borderRadius: BorderRadius.circular(20)
                  ),
                  child: GestureDetector(
                      onTap: (){
                        Navigator.of(context).pushReplacement(
                          MaterialPageRoute(builder: (BuildContext context) {
                            return const Requests();
                          }),
                        );
                      },
                      child: const Text("Request (3)",style: TextStyle(color: Colors.white,fontSize: 10),)),
                )
              ],
            )
            : index == 2
                ? Row(
                  children: [
                    Expanded(
                        child: Text(
                      title,
                          style: GoogleFonts.gabarito(
                              fontSize: 20, fontWeight: FontWeight.w700),
                    )),
                  ],
                )
                :index==3? Row(
                    children: [
                      Expanded(
                          child: Text(
                            title,
                            style: GoogleFonts.gabarito(
                                fontSize: 20, fontWeight: FontWeight.w700),
                          )),
                    ],
                  ):Row(
      children: [
        Expanded(
            child: Text(
              title,
              style: GoogleFonts.gabarito(
                  fontSize: 20, fontWeight: FontWeight.w700),
            )),
      ],
    );
  }

  @override
  // TODO: implement preferredSize
  Size get preferredSize => const Size.fromHeight(60);
}
