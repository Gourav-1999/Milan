import 'dart:convert';

import 'package:dio/dio.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:milan/detail_gender_page.dart';
import 'package:milan/detail_relationship_page.dart';

import 'commons/local_storage.dart';
import 'models/user_model.dart';

class LookingPage extends StatefulWidget {
  const LookingPage({super.key});

  @override
  State<LookingPage> createState() => _LookingPageState();
}

class _LookingPageState extends State<LookingPage> {

  int? currentIndex;
  List<OptionList> itemList = [];
  final Dio _dio = Dio();
  final String apiUrl = 'http://192.168.2.42:8004/api/v1/update-details';

  optionList() {
    itemList.clear();
    itemList.add(OptionList(text: "Male", icon: Icons.male));
    itemList.add(OptionList(text: "Female", icon: Icons.female));
    itemList.add(OptionList(text: "Other", icon: Icons.transgender));
    setState(() {});
  }

  @override
  void initState() {
    // TODO: implement initState
    optionList();
    super.initState();
  }

  Future<void> postGender() async {
    int id = currentIndex! +1;
    Map<String, dynamic> map = {
          "interested_in": id,
          "steps": 3,
    };

    try {
      final response = await _dio.post(
        apiUrl,
        data: jsonEncode(map),
        options: Options(
          headers: {
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ${await LocalStorage.getToken()}'
          },
        ),
      );
      print(response.data);
      print(map);
      UserModal userModal = UserModal.fromJson(response.data);
      print("Looking For--${userModal?.data?.gender}");
      if (response.statusCode == 200) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Successfully add what you looking')),
        );
        Navigator.of(context).pushReplacement(
          MaterialPageRoute(
            builder: (BuildContext context) {
              return const RelationPage();
            },
          ),
        );
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Failed add what you looking')),
        );
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Failed add what you looking')),
      );
      print(e);
    }
  }


  @override
  Widget build(BuildContext context) {
    return ScreenUtilInit(
      designSize: const Size(430, 942),
      minTextAdapt: true,
      splitScreenMode: true,
      child: SafeArea(
          child: Scaffold(
              body: Padding(
                padding: EdgeInsets.only(left: 18.w, top: 50.h,right: 18.w),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    GestureDetector(
                      onTap: () {
                        Navigator.of(context).pushReplacement(
                            new MaterialPageRoute(builder: (BuildContext context) {
                              return new GenderPage();
                            }));
                      },
                      child: Container(
                        margin: EdgeInsets.only(bottom: 18),
                        height: 50.h,
                        width: 50.w,
                        decoration: BoxDecoration(

                          shape: BoxShape.circle,
                          color: Colors.black.withOpacity(0.025),
                        ),
                        child: const Center(child: Icon(Icons.arrow_back)),
                      ),
                    ),
                    Text(
                      "I'm\nLooking For",
                      style: GoogleFonts.gabarito(
                          fontSize: 30.sp, fontWeight: FontWeight.w600),
                    ),
                    SizedBox(
                      height: 15.h,
                    ),
                    Text(
                      "Laughter, memories, and lifelong connections.",
                      style: GoogleFonts.gabarito(
                          fontSize: 16.sp, fontWeight: FontWeight.w500),
                    ),
                    Container(
                      margin: EdgeInsets.only(right: 18.w, top: 20.h),
                      child: ListView.builder(
                          itemCount: itemList.length,
                          physics: NeverScrollableScrollPhysics(),
                          shrinkWrap: true,
                          itemBuilder: (context, index) {
                            return GestureDetector(
                              onTap: () {
                                setState(() {
                                  currentIndex = index;
                                });
                              },
                              child: currentIndex == index
                                  ? Container(
                                height: 80.h,
                                width: 400.w,
                                margin: EdgeInsets.only(top: 5.h, bottom: 5.h),
                                padding: EdgeInsets.all(20),
                                decoration: BoxDecoration(
                                  border:
                                  Border.all(width: 1.5, color: Colors.blue),
                                  color: Colors.black.withOpacity(0.025),
                                  borderRadius: BorderRadius.circular(10),
                                ),
                                child: Row(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Expanded(
                                        child: Text(
                                          itemList[index].text,
                                          style: GoogleFonts.gabarito(
                                              color: Colors.blue,
                                              fontSize: 16.sp, fontWeight: FontWeight.w600
                                          ),
                                          maxLines: 1,
                                        )),
                                    Icon(
                                      itemList[index].icon,
                                      color: Colors.blue,
                                    )
                                  ],
                                ),
                              )
                                  : Container(
                                height: 80.h,
                                width: 400.w,
                                decoration: BoxDecoration(
                                  color: Colors.black.withOpacity(0.025),
                                  borderRadius: BorderRadius.circular(10),
                                ),
                                margin: EdgeInsets.only(top: 5.h, bottom: 5.h),
                                padding: EdgeInsets.all(20),
                                child: Row(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Expanded(
                                        child: Text(
                                          itemList[index].text,
                                          style: GoogleFonts.gabarito(
                                              fontSize: 16.sp, fontWeight: FontWeight.w600
                                          ),
                                          maxLines: 1,
                                        )),
                                    Icon(itemList[index].icon)
                                  ],
                                ),
                              ),
                            );
                          }),
                    ),
                    Spacer(),
                    Center(child: SizedBox(
                      height: 58.h,
                      width: 400.w,
                      child: ElevatedButton(
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.black,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(25.0),
                            ), // Background color
                          ),
                          onPressed: () {
                            if (currentIndex == null) {
                              ScaffoldMessenger.of(context).showSnackBar(
                                const SnackBar(
                                    content: Text('Please select a what you looking')),
                              );
                            } else {
                              postGender();
                            }
                          },
                          child: const Text(
                            "Next",
                            style: TextStyle(
                                color: Colors.white, fontSize: 20, overflow: TextOverflow.ellipsis),
                            maxLines: 1,
                          )),
                    )),
                    SizedBox(height: 10.h,),
                  ],
                ),
              ))),
    );
  }
}
class OptionList {
  String text;
  IconData icon;

  OptionList({required this.text, required this.icon});
}