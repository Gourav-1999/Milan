import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';

import 'detail_children_page.dart';
import 'detail_interest_page.dart';  // Assuming this is your next screen

class BirthDate extends StatefulWidget {
  const BirthDate({super.key});

  @override
  State<BirthDate> createState() => _BirthDateState();
}

class _BirthDateState extends State<BirthDate> {
  DateTime? selectedDate;

  @override
  Widget build(BuildContext context) {
    return ScreenUtilInit(
      designSize: const Size(430, 942),
      minTextAdapt: true,
      splitScreenMode: true,
      child: SafeArea(
        child: Scaffold(
          body: Padding(
            padding: EdgeInsets.only(left: 18.w, top: 50.h,right: 18.w),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                GestureDetector(
                  onTap: () {
                    Navigator.of(context).pushReplacement(
                      MaterialPageRoute(builder: (BuildContext context) {
                        return const ChildrenPage();
                      }),
                    );
                  },
                  child: Container(
                    margin: EdgeInsets.only(bottom: 18),
                    height: 50.h,
                    width: 50.w,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: Colors.black.withOpacity(0.025),
                    ),
                    child: const Center(child: Icon(Icons.arrow_back)),
                  ),
                ),
                Text(
                  "Your\nBirthday",
                  style: GoogleFonts.gabarito(
                      fontSize: 30.sp, fontWeight: FontWeight.w600),
                ),
                SizedBox(
                  height: 15.h,
                ),
                Text(
                  "Making birthdays brighter, together.",
                  style: GoogleFonts.gabarito(
                      fontSize: 16.sp, fontWeight: FontWeight.w500),
                ),
                SizedBox(
                  height: 40.h,
                ),
                DateSelectionScreen(
                  selectedDate: selectedDate,
                  onDateSelected: (DateTime date) {
                    setState(() {
                      selectedDate = date;
                    });
                  },
                ),
                SizedBox(height: 470.h,),
                Center(child: _submitBoxButton)
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class DateSelectionScreen extends StatelessWidget {
  final DateTime? selectedDate;
  final ValueChanged<DateTime> onDateSelected;

  const DateSelectionScreen({
    super.key,
    required this.selectedDate,
    required this.onDateSelected,
  });

  // Function to open the date picker
  Future<void> _selectDate(BuildContext context) async {
    final DateTime currentDate = DateTime.now();
    final DateTime initialDate = selectedDate ?? currentDate;

    // Open the date picker
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: initialDate,
      firstDate: DateTime(1900), // Set the minimum year
      lastDate: DateTime(2101), // Set the maximum year
    );

    // If a date is picked, pass it back to the parent
    if (picked != null) {
      onDateSelected(picked);
    }
  }

  @override
  Widget build(BuildContext context) {
    // Format the selected date using intl
    String formattedDate = selectedDate != null
        ? DateFormat('dd MMMM yyyy').format(selectedDate!) // Example format: 26 December 2024
        : 'DD/MM/YYYY';

    return GestureDetector(
      onTap: () {
        _selectDate(context);
      },
      child: Container(
        height: 70.h,
        width: double.infinity, // Make it take the full width
        padding: EdgeInsets.symmetric(horizontal: 18.w),
        margin: EdgeInsets.only(bottom: 18.h),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(10),
          color: Colors.black.withOpacity(0.025),
        ),
        child: Row(
          children: [
            Icon(Icons.calendar_month),
            SizedBox(width: 10.w),
            Expanded(
              child: Text(
                formattedDate,
                style: TextStyle(
                    fontSize: 16.sp, fontWeight: FontWeight.bold),
                overflow: TextOverflow.ellipsis, // Ensure text doesn't overflow
              ),
            ),
            Container(
              height: 20.h,
              width: 20.w,
              decoration: const BoxDecoration(
                image: DecorationImage(
                    image: AssetImage("assets/images/unfold.png"),
                    fit: BoxFit.contain),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
Widget get _submitBoxButton => SizedBox(
  height: 58.h,
  width: 400.w,
  child: Builder(builder: (context) {
    return ElevatedButton(
        style: ElevatedButton.styleFrom(
          backgroundColor: Colors.black,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(25.0),
          ), // Background color
        ),
        onPressed: () {
          Navigator.of(context).pushReplacement(
              new MaterialPageRoute(builder: (BuildContext context) {
                return new SelectInterestsPage();
              }));
        },
        child: const Text(
          "Next",
          style: TextStyle(
              color: Colors.white,
              fontSize: 20,
              overflow: TextOverflow.ellipsis),
          maxLines: 1,
        ));
  }),
);