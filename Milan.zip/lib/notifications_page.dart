import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';

import 'custom_app_bar.dart';

class NotificationPage extends StatefulWidget {
  const NotificationPage({super.key});

  @override
  State<NotificationPage> createState() => _NotificationState();
}
List<DataList> msgList = [];
DateTime _date = DateTime.now();
String date = DateFormat('dd/MM/y').format(_date);

String tm = DateFormat('hh:mm ').format(_date);

String day = DateFormat('EEEE').format(_date);

String hours = DateFormat('jz').format(_date);
class _NotificationState extends State<NotificationPage> {

  DataItemList(){
    msgList.clear();
    msgList.add(DataList(image: "assets/images/profile.png", time: tm, msg: "You both sent request: Anime", name: "John Uncle"));
    msgList.add(DataList(image: "assets/images/profile.png", time: tm, msg: "You both sent request: Anime", name: "John Uncle"));
    msgList.add(DataList(image: "assets/images/profile.png", time: tm, msg: "You both sent request: Anime", name: "John Uncle"));
    msgList.add(DataList(image: "assets/images/profile.png", time: tm, msg: "You both sent request: Anime", name: "John Uncle"));
    msgList.add(DataList(image: "assets/images/profile.png", time: tm, msg: "You both sent request: Anime", name: "John Uncle"));
    msgList.add(DataList(image: "assets/images/profile.png", time: tm, msg: "You both sent request: Anime", name: "John Uncle"));


    setState(() {

    });
  }
  @override
  void initState() {
    // TODO: implement initState
    DataItemList();
    super.initState();
  }
  @override
  Widget build(BuildContext context) {
    return ScreenUtilInit(
      designSize: const Size(430, 942),
      minTextAdapt: true,
      splitScreenMode: true,
      child: SafeArea(child: Scaffold(
        resizeToAvoidBottomInset: false,
        body: Padding(
          padding: EdgeInsets.only(top: 25.h, left: 18.w),
          child: Column(
            children: [
              CustomAppBar(
                title: "Notification",
                index: 3,
              ),
              SizedBox(
                height: 20.h,
              ),
              SingleChildScrollView(
                child: SizedBox(
                  height: 350.h,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      _customSearchBarWidget,
                      SizedBox(
                        height: 10.h,
                      ),
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Text(
                          "Today",
                          overflow: TextOverflow.ellipsis,
                          style: GoogleFonts.gabarito(
                            fontSize: 16,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ),
                      _customUserDataWidget,
                  
                    ],
                  ),
                ),
              ),
              SingleChildScrollView(
                child: SizedBox(
                  height: 370.h,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      SizedBox(
                        height: 10.h,
                      ),
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Text(
                          "Last 7 days",
                          overflow: TextOverflow.ellipsis,
                          style: GoogleFonts.gabarito(
                            fontSize: 16,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ),
                      _customUserDataWidget,

                    ],
                  ),
                ),
              ),

            ],
          ),
        ),
      )),
    );
  }
}
class DataList{
  String image;
  String msg;
  String time;
  String name;
  DataList({required this.image,required this.time,required this.msg,required this.name});
}
Widget get _customUserDataWidget => Flexible(
  child: ListView.builder(
    controller: ScrollController(),
    physics: NeverScrollableScrollPhysics(),
    itemCount: msgList.length,
    itemBuilder: (context, index) {
      return InkWell(
        autofocus: false,splashColor: Colors.white,
        onTap: () {
          // Navigator.push(
          //     context,
          //     MaterialPageRoute(
          //       builder: (context) => ChatScreen(pages: dataList[index]),
          //     ));
        },
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              height: 50,
              width: 52,
              margin: const EdgeInsets.only(bottom: 15),
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                image: DecorationImage(
                    image: AssetImage(msgList[index].image),
                    fit: BoxFit.cover),
              ),
            ),
            Expanded(
              child: Container(
                margin: const EdgeInsets.only(left: 10),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    RichText(
                      text: TextSpan(
                        children:  <TextSpan>[
                          TextSpan(text: "${msgList[index].name} ", style: GoogleFonts.gabarito(
                          fontSize: 16, fontWeight: FontWeight.w700,color:Colors.black),),
                          TextSpan(text: msgList[index].msg, style: GoogleFonts.gabarito(
                              fontSize: 16, fontWeight: FontWeight.w400,color:Colors.black),),

                        ],
                      ),
                    )
                    //  Text("Joker",style: TextStyle(fontSize: 20,fontWeight: FontWeight.bold),),
                  ],
                ),
              ),
            ),
            Column(
              children: [
                Text(msgList[index].time,
                    style: const TextStyle(
                        color: Colors.grey, fontWeight: FontWeight.bold)),
              ],
            )
          ],
        ),
      );
    },
    shrinkWrap: true,
  ),
);
Widget get _customSearchBarWidget => Container(
  margin: EdgeInsets.only(right: 18.w),
  decoration: BoxDecoration(
      color: Colors.black.withOpacity(0.035),
      borderRadius: BorderRadius.circular(10)),
  child: TextFormField(
    textInputAction: TextInputAction.done,
    keyboardType: TextInputType.text,
    decoration: InputDecoration(
      fillColor: Colors.black.withOpacity(0.025),
      contentPadding:
      const EdgeInsets.only(left: 20, right: 10, top: 10, bottom: 10),
      border: InputBorder.none,
      prefixIcon: const Icon(Icons.search),
      hintText: 'Search',
      hintStyle: const TextStyle(
          color: Colors.grey, overflow: TextOverflow.ellipsis),
    ),
    maxLines: 1,
  ),
);