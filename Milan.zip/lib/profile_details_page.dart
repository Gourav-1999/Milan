import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:google_fonts/google_fonts.dart';

class ProfileDetail extends StatefulWidget {
  const ProfileDetail({super.key});

  @override
  State<ProfileDetail> createState() => _ProfileDetailState();
}
List<DataList> items=[];
List<PersonDetail> infoList = [];
class _ProfileDetailState extends State<ProfileDetail> {
  InfoList() {
    infoList.clear();
    infoList.add(PersonDetail(
        age: 25,
        status: "Single",
        gender: "Female",
        location: "Florida",
        lastName: "Alice",
        firstName: "Aliza",
        description:
            "My name is Elizabeth. you can call me. I’m 25 years old nd live in Florida. Want to get acquainted with me? Foodie by day, adventurer by night. Looking for someone to keep up!",
        dob: "20 November 1996",
        interests: ["Music", "Dance","Coffee","Badminton"],
        looking: "Situational Friends"));
    setState(() {});
  }
  itemList(){
    items.clear();
    items.add(DataList(image: "assets/images/Rectangle 55.png"));
    items.add(DataList(image: "assets/images/Rectangle 56.png"));
    items.add(DataList(image: "assets/images/Rectangle 57.png"));
    items.add(DataList(image: "assets/images/Rectangle 58.png"));
    items.add(DataList(image: "assets/images/Rectangle 59.png"));
    items.add(DataList(image: "assets/images/Rectangle 61.png"));
    setState(() {

    });
  }

  @override
  void initState() {
    // TODO: implement initState
    InfoList();
    itemList();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
            body: SingleChildScrollView(
              child: Stack(
                    children: [
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
              Container(
                height: 450.h,
                width: 500.w,
                decoration: BoxDecoration(
                    image: const DecorationImage(
                        image: AssetImage("assets/images/Rectangle 711.png"),
                        fit: BoxFit.fill),
                    shape: BoxShape.rectangle),
              ),
              ListView.builder(
                  itemCount: infoList.length,
                  shrinkWrap: true,
                  physics: NeverScrollableScrollPhysics(),
                  itemBuilder: (context, index) {
                    return Padding(
                      padding: EdgeInsets.only(left: 18.w, right: 18.w),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          SizedBox(height: 35.h,),
                          Text(
                            "${infoList[index].firstName}\n${infoList[index].lastName}, ${infoList[index].age}",
                            overflow: TextOverflow.ellipsis,
                            style: GoogleFonts.gabarito(
                              fontSize: 40,
                              height: 1,
                              fontWeight: FontWeight.w600,
                            ),
                            maxLines: 2,
                          ),
                          SizedBox(height: 15.h,),
                          Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              const Icon(
                                Icons.location_on_outlined,
                                size: 25,
                              ),
                              Text(
                                infoList[index].location,
                                overflow: TextOverflow.ellipsis,
                                style: GoogleFonts.gabarito(
                                  fontSize: 20,
                                  fontWeight: FontWeight.w600,
                                ),
                                maxLines: 1,
                              ),
                            ],
                          ),
                          SizedBox(height: 15.h,),
                          Text(
                            "Description",
                            overflow: TextOverflow.ellipsis,
                            style: GoogleFonts.gabarito(
                              fontSize: 18,
                              fontWeight: FontWeight.w600,
                            ),
                            maxLines: 1,
                          ),
                          SizedBox(height: 10.h,),
                          Text(
                            infoList[index].description,
                            overflow: TextOverflow.ellipsis,
                            style: GoogleFonts.gabarito(
                              fontSize: 20,
                              fontWeight: FontWeight.w400,

                            ),
                            maxLines: 5,textAlign: TextAlign.start,
                          ),
                          SizedBox(height: 15.h,),
                          Text(
                            "Interests",
                            overflow: TextOverflow.ellipsis,
                            style: GoogleFonts.gabarito(
                              fontSize: 18,
                              fontWeight: FontWeight.w600,
                            ),
                            maxLines: 1,
                          ),
                          SizedBox(height: 15.h,),
                          SizedBox(
                            height:100.h,
                            child: GridView.builder(
                              physics: NeverScrollableScrollPhysics(),
                              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                                  crossAxisCount: 3, // 2 columns in the grid
                                  crossAxisSpacing: 8.0,
                                  mainAxisSpacing: 8.0,
                                  childAspectRatio: 3,
                              ),
                              itemCount: infoList[index].interests.length,
                              itemBuilder: (context, Index) {
                                return Container(
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(15.0),
                                    color: Colors.black.withOpacity(0.035),

                                  ),
                                  alignment: Alignment.center,
                                  child: Text(
                                   infoList[index].interests[Index],
                                    textAlign: TextAlign.center,
                                  ),
                                );
                              },
                            ),
                          ),

                          Text(
                            "Information",
                            overflow: TextOverflow.ellipsis,
                            style: GoogleFonts.gabarito(
                              fontSize: 18,
                              fontWeight: FontWeight.w600,
                            ),
                            maxLines: 1,
                          ),
                          SizedBox(height: 15.h,),
                          Container(
                           padding: EdgeInsets.all(20),
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(15.0),
                              color: Colors.black.withOpacity(0.035),

                            ),
                            child: Column(
                              children: [
                                Row(
                                  children: [
                                    Text(
                                      "Gender",
                                      overflow: TextOverflow.ellipsis,
                                      style: GoogleFonts.gabarito(
                                        fontSize: 20,
                                        fontWeight: FontWeight.w400,
                                      ),
                                      maxLines: 1,
                                    ),
                                    Spacer(),
                                    Text(
                                      infoList[index].gender,
                                      overflow: TextOverflow.ellipsis,
                                      style: GoogleFonts.gabarito(
                                        fontSize: 20,
                                        fontWeight: FontWeight.w400,
                                      ),
                                      maxLines: 1,
                                    ),
                                  ],
                                ),
                                SizedBox(height: 10.h,),
                                Row(
                                  children: [
                                    Text(
                                      "Looking for",
                                      overflow: TextOverflow.ellipsis,
                                      style: GoogleFonts.gabarito(
                                        fontSize: 20,
                                        fontWeight: FontWeight.w400,
                                      ),
                                      maxLines: 1,
                                    ),
                                    Spacer(),
                                    Text(
                                      infoList[index].looking,
                                      overflow: TextOverflow.ellipsis,
                                      style: GoogleFonts.gabarito(
                                        fontSize: 20,
                                        fontWeight: FontWeight.w400,
                                      ),
                                      maxLines: 1,
                                    ),
                                  ],
                                ),
                                SizedBox(height: 10.h,),
                                Row(
                                  children: [
                                    Text(
                                      "Relationship Status",
                                      overflow: TextOverflow.ellipsis,
                                      style: GoogleFonts.gabarito(
                                        fontSize: 20,
                                        fontWeight: FontWeight.w400,
                                      ),
                                      maxLines: 1,
                                    ),
                                    Spacer(),
                                    Text(
                                      infoList[index].status,
                                      overflow: TextOverflow.ellipsis,
                                      style: GoogleFonts.gabarito(
                                        fontSize: 20,
                                        fontWeight: FontWeight.w400,
                                      ),
                                      maxLines: 1,
                                    ),
                                  ],
                                ),
                                SizedBox(height: 10.h,),
                                Row(
                                  children: [
                                    Text(
                                      "Date of Birth",
                                      overflow: TextOverflow.ellipsis,
                                      style: GoogleFonts.gabarito(
                                        fontSize: 20,
                                        fontWeight: FontWeight.w400,
                                      ),
                                      maxLines: 1,
                                    ),
                                    Spacer(),
                                    Text(
                                      infoList[index].dob,
                                      overflow: TextOverflow.ellipsis,
                                      style: GoogleFonts.gabarito(
                                        fontSize: 20,
                                        fontWeight: FontWeight.w400,
                                      ),
                                      maxLines: 1,
                                    ),
                                  ],
                                )
                              ],
                            ),
                          )
                        ],
                      ),
                    );
                  }),

                          SizedBox(height: 15.h,),
                          Padding(
                            padding: EdgeInsets.only(left: 18.w, right: 18.w),
                            child: Text(
                              "Photo's",
                              overflow: TextOverflow.ellipsis,
                              style: GoogleFonts.gabarito(
                                fontSize: 18,
                                fontWeight: FontWeight.w600,
                              ),
                              maxLines: 1,
                            ),
                          ),

              GridView.builder(
                shrinkWrap: true,
                physics: NeverScrollableScrollPhysics(),
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2, // number of items in each row
                  mainAxisSpacing: 8.0, // spacing between rows
                  crossAxisSpacing: 8.0,
                  childAspectRatio: 0.8
                  // spacing between columns
                ),
                padding: EdgeInsets.only(top: 15.h,left: 18.w, right: 18.w),
                // padding around the grid
                itemCount: items.length,
                // total number of items
                itemBuilder: (context, index) {
                  return Container(
                    decoration: BoxDecoration(
                      shape: BoxShape.rectangle,
                      borderRadius: BorderRadius.circular(15),
                      image: DecorationImage(
                          image: AssetImage(items[index].image),
                          fit: BoxFit.cover),
                    ),
                  );
                },
              ),
                          SizedBox(height: 15.h,),
                          _reportBoxButton,
                          SizedBox(height: 10.h,),
                          _blockBoxButton,
                          SizedBox(height: 15.h,),
                        ],
                      ),
                      Positioned(
                        top: 420.h,
                        left: 120.w,
                        right: 250.w,
                        child: Container(
              height: 60.h,
              width: 60.w,
              alignment: Alignment.center,
              decoration: BoxDecoration(
                  color: Colors.white,
                  shape: BoxShape.circle,
                  boxShadow: [
                    BoxShadow(
                        blurRadius: 40,
                        spreadRadius: 60,
                        color: Colors.black.withOpacity(0.025))
                  ]),
              child: IconButton(
                icon: Icon(
                  Icons.replay,
                  color: Colors.red,
                  size: 30,
                ),
                onPressed: () {},
              ),
                        ),
                      ),
                      Positioned(
                        top: 420.h,
                        left: 260.w,
                        right: 110.w,
                        child: Container(
              height: 60.h,
              width: 60.w,
              alignment: Alignment.center,
              decoration: BoxDecoration(
                  color: Colors.white,
                  shape: BoxShape.circle,
                  boxShadow: [
                    BoxShadow(
                        blurRadius: 40,
                        spreadRadius: 60,
                        color: Colors.black.withOpacity(0.025))
                  ]),
              child: IconButton(
                icon: Icon(
                  Icons.message_outlined,
                  color: Colors.orangeAccent,
                  size: 30,
                ),
                onPressed: () {},
              ),
                        ),
                      ),
                      Positioned(
                        top: 420.h,
                        left: 190.w,
                        child: Container(
              height: 60.h,
              width: 60.w,
              alignment: Alignment.center,
              decoration:
                  BoxDecoration(color: Colors.pinkAccent, shape: BoxShape.circle),
              child: IconButton(
                icon: Icon(
                  Icons.add,
                  color: Colors.white,
                  size: 30,
                ),
                onPressed: () {},
              ),
                        ),
                      ),
                      Positioned(
                        top: 40.h,
                        left: 20.w,
                        right: 340.w,
                        child: Container(
                          height: 60.h,
                          width: 60.w,
                          alignment: Alignment.center,
                          decoration: BoxDecoration(
                              color: Colors.white12,
                              shape: BoxShape.circle,
                              boxShadow: [
                                BoxShadow(
                                    blurRadius: 40,
                                    spreadRadius: 60,
                                    color: Colors.black.withOpacity(0.025))
                              ]
                            ),
                          child: IconButton(
                            icon: Icon(
                              Icons.arrow_back,
                              color: Colors.white,
                              size: 30,
                            ),
                            onPressed: () {
                              Navigator.pop(context);
                            },
                          ),
                        ),
                      ),
                      Positioned(
                       left: 340.w,
                        top: 40.h,
                        right: 20.w,
                        child: Container(
                          height: 60.h,
                          width: 60.w,
                          alignment: Alignment.center,
                          decoration: BoxDecoration(
                              color: Colors.white12,
                              shape: BoxShape.circle,
                              boxShadow: [
                                BoxShadow(
                                    blurRadius: 40,
                                    spreadRadius: 60,
                                    color: Colors.black.withOpacity(0.025))
                              ]),
                          child: IconButton(
                            icon: Icon(
                              Icons.mobile_screen_share,
                              color: Colors.white,
                              size: 30,
                            ),
                            onPressed: () {},
                          ),
                        ),
                      ),
                    ],
                  ),
            )));
  }
}

Widget get _reportBoxButton => Container(
  height: 40.h,
    width: 400.w,
    margin: EdgeInsets.only(left: 18.w, right: 18.w),
    decoration: BoxDecoration(
      color: Colors.black.withOpacity(0.05),
      borderRadius: BorderRadius.circular(20)
    ),
    child: InkWell(
      onTap: (){},
      splashColor: Colors.black.withOpacity(0.05),
      child: const Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(Icons.flag,color: Colors.black,),
          SizedBox(width: 5,),
          Text(
            "Report Profile",
            style: TextStyle(fontSize: 20, overflow: TextOverflow.ellipsis),
            maxLines: 1,
          ),
        ],
      ),
    ));

Widget get _blockBoxButton => Container(
    height: 40.h,
    width: 400.w,
    margin: EdgeInsets.only(left: 18.w, right: 18.w),
    decoration: BoxDecoration(
        color: Colors.black.withOpacity(0.05),
        borderRadius: BorderRadius.circular(20)
    ),
    child: InkWell(
      onTap: (){},
      splashColor: Colors.black.withOpacity(0.05),
      child: const Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(Icons.block,color: Colors.black,),
          SizedBox(width: 5,),
          Text(
            "Block Profile",
            style: TextStyle(fontSize: 20, overflow: TextOverflow.ellipsis),
            maxLines: 1,
          ),
        ],
      ),
    ));

class PersonDetail {
  String firstName;
  String lastName;
  int age;
  String description;
  String gender;
  String looking;
  String status;
  String dob;
  String location;
  List<String> interests;

  PersonDetail(
      {required this.age,
      required this.status,
      required this.gender,
      required this.lastName,
      required this.firstName,
      required this.description,
      required this.dob,
      required this.interests,
      required this.looking,
      required this.location});
}


class DataList{
  String image;
  DataList({required this.image});
}
