import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:milan/chat_page.dart';
import 'package:milan/notifications_page.dart';
import 'package:milan/profile_page.dart';
import 'package:milan/send_request.dart';
import 'home_page.dart';

class Milan extends StatefulWidget{
  int Index;
  Milan({required this.Index});
  @override
  _Milan createState()=>_Milan(currentIndex: Index);
}

class _Milan extends State<Milan>{
  int currentIndex;
_Milan({required this.currentIndex});
  final _screens =[
    HomePage(),
    SendRequest(),
    Chat(),
    NotificationPage(),
    Profile()
  ];

  Widget build(BuildContext context){
    return ScreenUtilInit(
      designSize: const Size(430, 942),
      minTextAdapt: true,
      splitScreenMode: true,
      child: SafeArea(
        child: Scaffold(
          resizeToAvoidBottomInset : false,
          body: Stack(
            alignment: Alignment.bottomCenter,
            children: [
              _screens[currentIndex],
              CustomBottomNavigationBar(
              currentIndex:currentIndex,
              onTap:(index){
                setState(() {
                  currentIndex=index;
                });
              }
                            )
            ],
          ),
        ),
      ),
    );
  }
}
class CustomBottomNavigationBar extends StatelessWidget{
  int currentIndex;
  late final Function(int)
  onTap;

  CustomBottomNavigationBar(
      {super.key, required this.currentIndex,required this.onTap});

  Widget build(BuildContext context){
    return Container(
      height: 90.h,
      width: 400.w,
      margin: EdgeInsets.only(left: 18.w,right: 18.w,bottom: 18.h,),
      decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(40),
          boxShadow: [BoxShadow(color: Colors.black12,spreadRadius: 1,blurRadius: 10),

          ]
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: [
          CustomNavigationBarItem(
            icon:Icons.home,
            isSelected:currentIndex==0,
            onTap:(){
              onTap(0);
            },
          ),
          CustomNavigationBarItem(
            icon:Icons.send,
            isSelected:currentIndex==1,
            onTap:(){
              onTap(1);
            },
          ),
          CustomNavigationBarItem(
            icon:Icons.chat,
            isSelected:currentIndex==2,
            onTap:(){
              onTap(2);
            },
          ),
          CustomNavigationBarItem(
            icon:Icons.notifications_none,
            isSelected:currentIndex==3,
            onTap:(){
              onTap(3);
            },
          ),
          CustomNavigationBarItem(
            icon:Icons.person_outline,
            isSelected:currentIndex==4,
            onTap:(){
              onTap(4);
            },
          ),

        ],
      ),

    );
  }

}
class CustomNavigationBarItem extends StatelessWidget{
  late final IconData icon;
  late final bool isSelected;
  late final Function onTap;

  CustomNavigationBarItem({required this.icon,required this.isSelected,required this.onTap});

  Widget build(BuildContext context){
    return GestureDetector(
      onTap: (){
        onTap();
      },
      child: Container(
        height: 50.h,
        width: 60.w,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: isSelected?Colors.black:Colors.white,
        ),
        child: Center(
          child: Icon(icon,size: 25,color: isSelected?Colors.white:Colors.grey,),
        ),
      // ) Column(
      //   mainAxisAlignment: MainAxisAlignment.center,
      //   children: [
      //     Icon(icon,size: 20,color:isSelected?Colors.orange:Colors.grey),
      //     Text(label,style: TextStyle(color: isSelected?Colors.orange:Colors.grey),)
      //   ],
      // ),
    ));
  }
}






