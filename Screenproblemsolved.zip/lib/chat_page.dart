import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import 'package:milan/custom_app_bar.dart';

class Chat extends StatefulWidget {
  const Chat({super.key});

  @override
  State<Chat> createState() => _ChatState();
}

DateTime _date = DateTime.now();
String date = DateFormat('dd/MM/y').format(_date);

String tm = DateFormat('hh:mm ').format(_date);

String day = DateFormat('EEEE').format(_date);

String hours = DateFormat('jz').format(_date);

int index = 2;
List<UserDataModal> dataList = [];

class _ChatState extends State<Chat> {
  initDataList() {
    dataList.clear();

    dataList.add(UserDataModal(
        images: "assets/chat/download.png",
        names: "Joker",
        time: tm,
        msg: "Hi!"));
    dataList.add(UserDataModal(
        images: "assets/chat/download1.png",
        names: "Adam",
        time: hours,
        msg: "Good Morning!"));
    dataList.add(UserDataModal(
        images: "assets/chat/download2.png",
        names: "Kate",
        time: tm,
        msg: "Who like me."));
    dataList.add(UserDataModal(
        images: "assets/chat/download.png",
        names: "Robin",
        time: day,
        msg: "Hi,everyone!"));
    dataList.add(UserDataModal(
        images: "assets/chat/download1.png",
        names: "Sara",
        time: day,
        msg: "Come talk to me!"));
    dataList.add(UserDataModal(
        images: "assets/chat/download2.png",
        names: "Victor",
        time: hours,
        msg: "Hello."));
    dataList.add(UserDataModal(
        images: "assets/chat/download.png",
        names: "Thomas",
        time: tm,
        msg: "Can we friends?"));
    dataList.add(UserDataModal(
        images: "assets/chat/download1.png",
        names: "Jack",
        time: date,
        msg: "Are you single?"));
    dataList.add(UserDataModal(
        images: "assets/chat/download2.png",
        names: "Francis",
        time: tm,
        msg: "Hi!"));
    dataList.add(UserDataModal(
        images: "assets/chat/download1.png",
        names: "Cobra",
        time: tm,
        msg: "Hi!"));
    dataList.add(UserDataModal(
        images: "assets/chat/download1.png",
        names: "Jack",
        time: date,
        msg: "Are you single?"));
    dataList.add(UserDataModal(
        images: "assets/chat/download2.png",
        names: "Francis",
        time: tm,
        msg: "Hi!"));
    dataList.add(UserDataModal(
        images: "assets/chat/download1.png",
        names: "Cobra",
        time: tm,
        msg: "Hi!"));
    setState(() {});
  }

  @override
  void initState() {
    // TODO: implement initState
    initDataList();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return ScreenUtilInit(
      designSize: const Size(430, 942),
      minTextAdapt: true,
      splitScreenMode: true,
      child: SafeArea(
          child: Scaffold(
        resizeToAvoidBottomInset: false,
        body: Padding(
          padding: EdgeInsets.only(top: 25.h, left: 18.w),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              CustomAppBar(
                title: "Chat",
                index: 2,
              ),
              SizedBox(
                height: 20.h,
              ),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _customSearchBarWidget,
                    SizedBox(
                      height: 10.h,
                    ),
                    _customUserDataWidget
                  ],
                ),
              )
            ],
          ),
        ),
      )),
    );
  }
}

Widget get _customSearchBarWidget => Container(
      margin: EdgeInsets.only(right: 18.w),
      decoration: BoxDecoration(
          color: Colors.black.withOpacity(0.035),
          borderRadius: BorderRadius.circular(10)),
      child: TextFormField(
        textInputAction: TextInputAction.done,
        keyboardType: TextInputType.text,
        decoration: InputDecoration(
          fillColor: Colors.black.withOpacity(0.025),
          contentPadding:
              const EdgeInsets.only(left: 20, right: 10, top: 10, bottom: 10),
          border: InputBorder.none,
          prefixIcon: const Icon(Icons.search),
          hintText: 'Search',
          hintStyle: const TextStyle(
              color: Colors.grey, overflow: TextOverflow.ellipsis),
        ),
        maxLines: 1,
      ),
    );

Widget get _customUserDataWidget => Expanded(
      child: Container(
        margin:  EdgeInsets.only(left: 10.w,right: 10.w),
        height: 40,
        child: ListView.builder(
          controller: ScrollController(),
          itemCount: dataList.length,
          padding:EdgeInsets.only(bottom: 100.h),
          itemBuilder: (context, index) {
            return InkWell(
              autofocus: false,splashColor: Colors.white,
              onTap: () {
                Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => ChatScreen(pages: dataList[index]),
                    ));
              },
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    height: 50,
                    width: 52,
                    margin: const EdgeInsets.only(bottom: 15),
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      image: DecorationImage(
                          image: AssetImage(dataList[index].images),
                          fit: BoxFit.cover),
                    ),
                  ),
                  Expanded(
                    child: Container(
                      margin: const EdgeInsets.only(left: 10),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            dataList[index].names,
                            style: GoogleFonts.gabarito(
                                fontSize: 18, fontWeight: FontWeight.w700),
                          ),
                          //  Text("Joker",style: TextStyle(fontSize: 20,fontWeight: FontWeight.bold),),
                          Text(
                            dataList[index].msg,
                            overflow: TextOverflow.ellipsis,
                            style: GoogleFonts.gabarito(
                              fontSize: 16,
                              fontWeight: FontWeight.w500,
                            ),
                          )
                        ],
                      ),
                    ),
                  ),
                  Column(
                    children: [
                      Text(dataList[index].time,
                          style: const TextStyle(
                              color: Colors.grey, fontWeight: FontWeight.bold)),
                    ],
                  )
                ],
              ),
            );
          },
          shrinkWrap: true,
        ),
      ),
    );

class UserDataModal {
  late String images, names, time, msg;

  UserDataModal(
      {required this.images,
      required this.names,
      required this.time,
      required this.msg});
}

class ChatScreen extends StatelessWidget {
  final UserDataModal pages;

  const ChatScreen({super.key, required this.pages});

  @override
  Widget build(BuildContext context) {
    return ScreenUtilInit(
      designSize: const Size(430, 942),
      minTextAdapt: true,
      splitScreenMode: true,
      child: SafeArea(
          child: Scaffold(
        //resizeToAvoidBottomInset: false,
        body: Stack(
          children: [
            Column(
              children: [
                Padding(
                  padding: EdgeInsets.only(top: 18.h, left: 18.w),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      IconButton(
                          onPressed: () {
                            Navigator.pop(context);
                          },
                          icon: const Icon(Icons.arrow_back_ios)),
                      Stack(
                        alignment: Alignment.centerRight,
                        children: [
                          Container(
                            height: 50,
                            width: 52,
                            margin: const EdgeInsets.only(bottom: 15),
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              image: DecorationImage(
                                  image: AssetImage(pages.images), fit: BoxFit.cover),
                            ),
                          ),
                          Positioned(child: Container(
                            width: 15.w,
                            height: 15.h,
                            decoration: BoxDecoration(
                              color: Colors.lightGreenAccent,
                              shape: BoxShape.circle,
                              border: Border.all(width: 2,color: Colors.white)
                            )
                          ))
                        ],
                      ),
                      SizedBox(
                        width: 12.w,
                      ),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            pages.names,
                            overflow: TextOverflow.ellipsis,
                            style: GoogleFonts.gabarito(
                              fontSize: 16,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                          Text(
                            "online",
                            overflow: TextOverflow.ellipsis,
                            style: GoogleFonts.gabarito(
                              fontSize: 12,
                              fontWeight: FontWeight.w300,
                            ),
                          ),
                        ],
                      ),
                      Spacer(),
                      IconButton(
                          onPressed: () {}, icon: const Icon(Icons.call_outlined)),
                      IconButton(
                          onPressed: () {},
                          icon: const Icon(Icons.videocam_outlined)),
                      IconButton(
                          onPressed: () {},
                          icon: const Icon(Icons.more_vert_outlined)),
                    ],
                  ),
                ),
                Expanded(
                  child: ListView.builder(
                      itemCount: 7,
                      shrinkWrap: true,
                      padding: EdgeInsets.only(bottom: 80.h),
                      itemBuilder: (context, index) {
                        return Padding(
                            padding: EdgeInsets.only(
                                right: 18.w, left: 18.w, top: 18.h),
                            child: index == 0
                                ? Column(
                              crossAxisAlignment: CrossAxisAlignment.end,
                              children: [
                                Center(
                                  child: Container(
                                    height: 20.h,
                                    width: 50.w,
                                    alignment: Alignment.center,
                                    decoration: BoxDecoration(
                                        color: Colors.black.withOpacity(0.025),
                                        shape: BoxShape.rectangle,
                                        borderRadius: BorderRadius.circular(10)),
                                    child: Text(
                                      "Today",
                                      overflow: TextOverflow.ellipsis,
                                      style: GoogleFonts.gabarito(
                                        fontSize: 12,
                                        fontWeight: FontWeight.w300,
                                      ),
                                    ),
                                  ),
                                ),
                                SizedBox(height: 5.h,),
                                Container(
                                  width: 200.w,
                                  height: 70.h,
                                  alignment: Alignment.center,
                                  decoration: BoxDecoration(
                                      color: Colors.black,
                                      shape: BoxShape.rectangle,
                                      borderRadius:
                                      BorderRadius.circular(10)),
                                  child: Text(
                                    "Hello, Good Morning ${pages.names}\nhow are you?",
                                    overflow: TextOverflow.ellipsis,
                                    style: GoogleFonts.gabarito(
                                      fontSize: 12,
                                      color: Colors.white,
                                      fontWeight: FontWeight.w400,
                                    ),
                                  ),
                                ),
                                SizedBox(
                                  height: 5.h,
                                ),
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.end,
                                  children: [
                                    Container(
                                        height: 15.h,
                                        width: 20.w,
                                        decoration: const BoxDecoration(
                                          color: Colors.green,
                                          shape: BoxShape.circle,
                                        ),
                                        child: const Icon(
                                          Icons.done,
                                          color: Colors.white,
                                          size: 10,
                                        )),
                                    Text(
                                      tm,
                                      style: const TextStyle(
                                          color: Colors.grey),
                                    )
                                  ],
                                )
                              ],
                            )
                                : index == 1
                                ? Column(
                              crossAxisAlignment:
                              CrossAxisAlignment.start,
                              children: [
                                Container(
                                  width: 200.w,
                                  height: 70.h,
                                  alignment: Alignment.center,
                                  decoration: BoxDecoration(
                                      color: Colors.black
                                          .withOpacity(0.035),
                                      shape: BoxShape.rectangle,
                                      borderRadius:
                                      BorderRadius.circular(10)),
                                  child: Text(
                                    "Hello, Good Morning too\n${pages.names}",
                                    overflow: TextOverflow.ellipsis,
                                    style: GoogleFonts.gabarito(
                                      fontSize: 12,
                                      fontWeight: FontWeight.w400,
                                    ),
                                  ),
                                ),
                                SizedBox(
                                  height: 5.h,
                                ),
                                Row(
                                  mainAxisAlignment:
                                  MainAxisAlignment.start,
                                  children: [
                                    Text(
                                      tm,
                                      style: const TextStyle(
                                          color: Colors.grey),
                                    )
                                  ],
                                )
                              ],
                            )
                                : index == 2
                                ? Column(
                              crossAxisAlignment:
                              CrossAxisAlignment.start,
                              children: [
                                Container(
                                  width: 200.w,
                                  height: 70.h,
                                  alignment: Alignment.center,
                                  decoration: BoxDecoration(
                                      color: Colors.black
                                          .withOpacity(0.035),
                                      shape: BoxShape.rectangle,
                                      borderRadius:
                                      BorderRadius.circular(
                                          10)),
                                  child: Text(
                                    "Haha, Yes i’ve seen your profile\nand I’m perfect match",
                                    overflow: TextOverflow.ellipsis,
                                    style: GoogleFonts.gabarito(
                                      fontSize: 12,
                                      fontWeight: FontWeight.w400,
                                    ),
                                  ),
                                ),
                                SizedBox(
                                  height: 5.h,
                                ),
                                Row(
                                  mainAxisAlignment:
                                  MainAxisAlignment.start,
                                  children: [
                                    Text(
                                      tm,
                                      style: const TextStyle(
                                          color: Colors.grey),
                                    )
                                  ],
                                )
                              ],
                            )
                                : index == 3
                                ? Column(
                              crossAxisAlignment:
                              CrossAxisAlignment.end,
                              children: [
                                Container(
                                  width: 200.w,
                                  height: 70.h,
                                  alignment: Alignment.center,
                                  decoration: BoxDecoration(
                                      color: Colors.black,
                                      shape: BoxShape.rectangle,
                                      borderRadius:
                                      BorderRadius.circular(
                                          10)),
                                  child: Text(
                                    "Can you make my partner\n${pages.names}?",
                                    overflow:
                                    TextOverflow.ellipsis,
                                    style: GoogleFonts.gabarito(
                                      fontSize: 12,
                                      color: Colors.white,
                                      fontWeight:
                                      FontWeight.w400,
                                    ),
                                  ),
                                ),
                                SizedBox(
                                  height: 5.h,
                                ),
                                Row(
                                  mainAxisAlignment:
                                  MainAxisAlignment.end,
                                  children: [
                                    Container(
                                        height: 15.h,
                                        width: 20.w,
                                        decoration:
                                        const BoxDecoration(
                                          color: Colors.green,
                                          shape:
                                          BoxShape.circle,
                                        ),
                                        child: const Icon(
                                          Icons.done,
                                          color: Colors.white,
                                          size: 10,
                                        )),
                                    Text(
                                      tm,
                                      style: const TextStyle(
                                          color: Colors.grey),
                                    )
                                  ],
                                )
                              ],
                            )
                                : index == 4
                                ? Column(
                              crossAxisAlignment:
                              CrossAxisAlignment.start,
                              children: [
                                Container(
                                  width: 200.w,
                                  height: 70.h,
                                  alignment:
                                  Alignment.center,
                                  decoration: BoxDecoration(
                                      color: Colors.black
                                          .withOpacity(
                                          0.035),
                                      shape: BoxShape
                                          .rectangle,
                                      borderRadius:
                                      BorderRadius
                                          .circular(
                                          10)),
                                  child: Text(
                                    "Haha, Yes\nyou are amazing guy!",
                                    overflow: TextOverflow
                                        .ellipsis,
                                    style: GoogleFonts
                                        .gabarito(
                                      fontSize: 12,
                                      fontWeight:
                                      FontWeight.w400,
                                    ),
                                  ),
                                ),
                                SizedBox(
                                  height: 5.h,
                                ),
                                Row(
                                  mainAxisAlignment:
                                  MainAxisAlignment
                                      .start,
                                  children: [
                                    Text(
                                      tm,
                                      style:
                                      const TextStyle(
                                          color: Colors
                                              .grey),
                                    )
                                  ],
                                )
                              ],
                            )
                                : index == 5
                                ? Column(
                              crossAxisAlignment:
                              CrossAxisAlignment
                                  .start,
                              children: [
                                Container(
                                  width: 200.w,
                                  height: 70.h,
                                  alignment:
                                  Alignment.center,
                                  decoration: BoxDecoration(
                                      color: Colors
                                          .black
                                          .withOpacity(
                                          0.035),
                                      shape: BoxShape
                                          .rectangle,
                                      borderRadius:
                                      BorderRadius
                                          .circular(
                                          10)),
                                  child: Text(
                                    "When we meet ${pages.names},\nand send me the details of place.",
                                    overflow:
                                    TextOverflow
                                        .ellipsis,
                                    style: GoogleFonts
                                        .gabarito(
                                      fontSize: 12,
                                      fontWeight:
                                      FontWeight
                                          .w400,
                                    ),
                                  ),
                                ),
                                SizedBox(
                                  height: 5.h,
                                ),
                                Row(
                                  mainAxisAlignment:
                                  MainAxisAlignment
                                      .start,
                                  children: [
                                    Text(
                                      tm,
                                      style: const TextStyle(
                                          color: Colors
                                              .grey),
                                    )
                                  ],
                                )
                              ],
                            )
                                : Column(
                              crossAxisAlignment:
                              CrossAxisAlignment
                                  .end,
                              children: [
                                Container(
                                  width: 200.w,
                                  height: 70.h,
                                  alignment:
                                  Alignment.center,
                                  decoration: BoxDecoration(
                                      color:
                                      Colors.black,
                                      shape: BoxShape
                                          .rectangle,
                                      borderRadius:
                                      BorderRadius
                                          .circular(
                                          10)),
                                  child: Text(
                                    "We will meet at my home\non Saturday,I live alone!",
                                    overflow:
                                    TextOverflow
                                        .ellipsis,
                                    style: GoogleFonts
                                        .gabarito(
                                      fontSize: 12,
                                      color:
                                      Colors.white,
                                      fontWeight:
                                      FontWeight
                                          .w400,
                                    ),
                                  ),
                                ),
                                SizedBox(
                                  height: 5.h,
                                ),
                                Row(
                                  mainAxisAlignment:
                                  MainAxisAlignment
                                      .end,
                                  children: [
                                    Container(
                                        height: 15.h,
                                        width: 20.w,
                                        decoration:
                                        const BoxDecoration(
                                          color: Colors
                                              .green,
                                          shape: BoxShape
                                              .circle,
                                        ),
                                        child:
                                        const Icon(
                                          Icons.done,
                                          color: Colors
                                              .white,
                                          size: 10,
                                        )),
                                    Text(
                                      tm,
                                      style: const TextStyle(
                                          color: Colors
                                              .grey),
                                    )
                                  ],
                                )
                              ],
                            ));
                      }),
                ),
              ],
            ),
            Align(
              alignment: Alignment.bottomCenter,
              child: Row(
              children: [
                Container(
                  width: 320.w,
                  height: 50.h,
                  margin: EdgeInsets.only(right: 18.w,left: 18.w,bottom: 18.h),
                  decoration: BoxDecoration(
                      color: Colors.white,
                      boxShadow: [
                        BoxShadow(
                            color: Colors.black.withOpacity(0.05),
                            offset: const Offset(0, 15),
                            blurRadius: 30
                        )
                      ],
                      borderRadius: BorderRadius.circular(20)),
                  child: TextFormField(
                    textInputAction: TextInputAction.done,
                    keyboardType: TextInputType.text,
                    decoration: InputDecoration(
                      prefixIcon: const Icon(Icons.emoji_emotions_outlined),
                      suffixIcon: SizedBox(
                        width: 115.w,
                        child: Row(
                          children: [
                            Transform.rotate(angle: 1.1,
                                child: IconButton(icon:const Icon(Icons.attach_file_outlined), onPressed: () {  },)),
                            IconButton(onPressed: (){}, icon: const Icon(Icons.camera_alt_rounded))
                          ],
                        ),
                      ),
                      fillColor: Colors.black.withOpacity(0.025),
                      contentPadding: const EdgeInsets.only(
                          left: 25, right: 25, top: 10, bottom: 10),
                      border: InputBorder.none,
                      hintText: 'Type a message..',
                      hintStyle: const TextStyle(
                          color: Colors.grey, overflow: TextOverflow.ellipsis),
                    ),
                    maxLines: 1,
                  ),
                ),
                Container(
                  height: 40,
                  width: 40,
                  margin: EdgeInsets.only(bottom: 18.h),
                  alignment: Alignment.center,
                  decoration: BoxDecoration(
                      color: Colors.black,
                      shape: BoxShape.circle
                  ),
                  child: Icon(
                    Icons.mic,color: Colors.white,
                  ),
                )
              ],
              ),
            ),
          ],
        ),
      )),
    );
  }
}
