import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:milan/get_premium.dart';
import 'package:milan/help_center.dart';
import 'package:milan/invites_friends.dart';
import 'package:milan/payment_methods.dart';
import 'package:milan/privacy_policy.dart';
import 'package:milan/settings.dart';
import 'package:milan/your_profile.dart';

import 'custom_app_bar.dart';
import 'login_page.dart';

class Profile extends StatefulWidget {
  const Profile({super.key});

  @override
  State<Profile> createState() => _ProfileState();
}

List<Widget> pagesList = [
  YourProfile(),
  PaymentMethods(),
  Settings(),
  HelpCenter(),
  PrivacyPolicy(),
  InvitesFriends()
];

List<ProfileModal> listdata = [];
int currentIndex = 4;

class _ProfileState extends State<Profile> {
  initprofiledata() {
    listdata.clear();
    listdata.add(ProfileModal(
        name: "Your Profile",
        menuIcon: Icons.arrow_forward_ios,
        icon: Icons.person_outline));
    listdata.add(ProfileModal(
        name: "Payment Methods",
        menuIcon: Icons.arrow_forward_ios,
        icon: Icons.payment_outlined));
    listdata.add(ProfileModal(
        name: "Settings",
        menuIcon: Icons.arrow_forward_ios,
        icon: Icons.settings));
    listdata.add(ProfileModal(
        name: "Help Center",
        menuIcon: Icons.arrow_forward_ios,
        icon: Icons.help_outline));
    listdata.add(ProfileModal(
        name: "Privacy Policy",
        menuIcon: Icons.arrow_forward_ios,
        icon: Icons.lock_outline));
    listdata.add(ProfileModal(
        name: "Invites Friends",
        menuIcon: Icons.arrow_forward_ios,
        icon: Icons.person_add_alt));
    setState(() {});
  }

  @override
  void initState() {
    // TODO: implement initState
    initprofiledata();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return ScreenUtilInit(
      designSize: const Size(430, 942),
      minTextAdapt: true,
      splitScreenMode: true,
      child: SafeArea(
          child: Scaffold(
        body: Padding(
          padding: EdgeInsets.only(top: 25.h, left: 18.w, right: 18.w),
          child: Column(
            children: [
              CustomAppBar(index: currentIndex, title: "Profile"),
              _profilePhoto,
              SizedBox(
                height: 15.h,
              ),
              _premium(context),
              SizedBox(
                height: 15.h,
              ),
              _profileDataModal(context),
            ],
          ),
        ),
      )),
    );
  }
}

Widget get _profilePhoto => Column(
      children: [
        Stack(
          alignment: Alignment.bottomCenter,
          children: [
            Container(
              height: 140.h,
              width: 140.w,
              decoration: BoxDecoration(
                  image: const DecorationImage(
                      image: AssetImage("assets/images/profile.png"),
                      fit: BoxFit.cover),
                  shape: BoxShape.circle,

                  border: Border.all(
                    width: 4.w,
                    color: Colors.white,
                  )),
            ),
            Container(
              height: 30.h,
              width: 50.w,
              alignment: Alignment.center,
              decoration: BoxDecoration(
                  color: Colors.white,
                  shape: BoxShape.rectangle,
                  border: Border.all(width: 2,color: Colors.white),
                  borderRadius: BorderRadius.circular(20)),
              child: GestureDetector(
                  onTap: () {},
                  child: const Text(
                    "Edit",
                    style: TextStyle(fontSize: 12),
                  )),
            )
          ],
        ),
        SizedBox(
          height: 15.h,
        ),
        Text(
          "Kate",
          overflow: TextOverflow.ellipsis,
          style: GoogleFonts.gabarito(
            fontSize: 16,
            fontWeight: FontWeight.w600,
          ),
          maxLines: 1,
        )
      ],
    );

Widget _premium(BuildContext context)=>GestureDetector(
  onTap: (){
    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => const Membership()),
    );
  },
  child: Container(
    decoration: BoxDecoration(
      color: Colors.black,
      shape: BoxShape.rectangle,
      borderRadius: BorderRadius.circular(20),
    ),
    child: Container(
      margin: EdgeInsets.all(10),
      height: 60.h,
      width: 300.w,
      child: Row(
        children: [
          Container(
            height: 40.h,
            width: 40.w,
            decoration: BoxDecoration(
              image: DecorationImage(
                image: AssetImage("assets/images/fi_3649801.png"),
                fit: BoxFit.contain
              )
            ),
          ),
          SizedBox(width: 10.w,),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text("Get Premium Plan",style: TextStyle(color: Colors.white,fontSize: 13,fontWeight: FontWeight.bold),),
              Text("Find Your Perfet Match Faster",style: TextStyle(color: Colors.white,fontSize: 12),)
            ],
          )
        ],
      ),
    ),
  ),
);

Widget _profileDataModal(BuildContext context) => Column(
      children: [
        ListView.builder(
            itemCount: listdata.length,
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            itemBuilder: (context, index) {
              return Padding(
                padding: const EdgeInsets.all(10),
                child: InkWell(
                  splashColor: Colors.white,
                  onTap: () {
                    // Navigator.of(context).pushAndRemoveUntil(
                    //   MaterialPageRoute(
                    //     builder: (context) => pagesList[index],
                    //   ),
                    //   (Route<dynamic> route) => false,
                    // );
                    Navigator.push(context, MaterialPageRoute(builder: (context) => pagesList[index],));
                  },
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Icon(listdata[index].icon),
                      SizedBox(
                        width: 10.w,
                      ),
                      Expanded(
                          child: Text(
                        listdata[index].name,
                        overflow: TextOverflow.ellipsis,
                        style: GoogleFonts.gabarito(
                          fontSize: 16,
                          fontWeight: FontWeight.w500,
                        ),
                      )),
                      Icon(
                        listdata[index].menuIcon,
                        size: 15,
                      )
                    ],
                  ),
                ),
              );
            }),
        SizedBox(
          height: 10.h,
        ),
        Padding(
          padding: const EdgeInsets.all(10),
          child: GestureDetector(
            onTap: () {
              Navigator.of(context).pushAndRemoveUntil(
                MaterialPageRoute(
                  builder: (context) => LoginPage(),
                ),
                    (Route<dynamic> route) => false,
              );
            },
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Icon(
                  Icons.logout,
                  color: Colors.red,
                ),
                SizedBox(
                  width: 10.w,
                ),
                Text(
                  "Logout",
                  overflow: TextOverflow.ellipsis,
                  style: GoogleFonts.gabarito(
                    fontSize: 16,
                    color: Colors.red,
                    fontWeight: FontWeight.w600,
                  ),
                )
              ],
            ),
          ),
        )
      ],
    );

class ProfileModal {
  String name;
  IconData menuIcon;
  IconData icon;

  ProfileModal(
      {required this.name, required this.menuIcon, required this.icon});
}
