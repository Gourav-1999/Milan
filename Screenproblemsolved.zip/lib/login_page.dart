

import 'package:country_code_picker/country_code_picker.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter/services.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:milan/otp_page.dart';
import 'package:dio/dio.dart';  // Import dio
import 'dart:convert';

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final TextEditingController _phoneController = TextEditingController();
  String? selectedCountryCode;
  String? isoCode;
  bool _isLoading = false;
  var country;

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body: Stack(
          alignment: Alignment.bottomCenter,
          children: [
            Container(
              alignment: Alignment.bottomCenter,
              decoration: const BoxDecoration(
                image: DecorationImage(
                  image: AssetImage("assets/images/login.png"),
                  fit: BoxFit.cover,
                ),
              ),
            ),
            IntrinsicHeight(
              child: Container(
                decoration: BoxDecoration(
                    color: Colors.white,
                  borderRadius: BorderRadius.only(topRight: Radius.circular(30.r),topLeft: Radius.circular(30.r))
                ),
                padding: EdgeInsets.only(left: 20.w, right: 20.w, top: 20.h),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      "Enter Your\nPhone Number",
                      style: GoogleFonts.gabarito(
                        fontSize: 30.sp,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    Text(
                      "Unlock your experience.",
                      style: GoogleFonts.gabarito(
                        fontSize: 18.sp,
                        fontWeight: FontWeight.w400,
                      ),
                    ),
                    SizedBox(height: 10.h),
                    _phoneNumberTextField(),
                    SizedBox(height: 10.h),
                    _checkBoxButton(),
                    SizedBox(height: 10.h),
                  ],
                ),
              ),
            )
          ],
        ),
      ),
    );
  }

  Widget _phoneNumberTextField() {
    return Container(
      decoration: BoxDecoration(
        color: Colors.grey.withOpacity(0.2),
        borderRadius: BorderRadius.circular(20.r),
      ),
      child: TextFormField(
        controller: _phoneController,
        textInputAction: TextInputAction.done,
        keyboardType: TextInputType.number,
        inputFormatters: [
          LengthLimitingTextInputFormatter(10),
        ],
        decoration: InputDecoration(
          fillColor: Colors.grey,
          contentPadding: const EdgeInsets.all(10),
          prefixIcon: SizedBox(
            height: 30.h,
            width: 115.w,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                CountryCodePicker(
                  onChanged: (country) {
                    setState(() {
                      selectedCountryCode = country.dialCode;
                      isoCode = country.code;  // Save the iso code too
                    });
                    print('Selected country: ${country.dialCode}');
                    print(isoCode);
                  },
                  initialSelection: 'US',
                  favorite: const ['+61', '+1','+91'],
                  showFlag: true,
                  showOnlyCountryWhenClosed: false,
                  showCountryOnly: false,
                  flagWidth: 20.w,
                ),
              ],
            ),
          ),
          border: InputBorder.none,
          hintText: '| Enter Phone Number',
          hintStyle: const TextStyle(
            color: Colors.grey,
            overflow: TextOverflow.ellipsis,
          ),
        ),
        maxLines: 1,
        validator: (value) {
          if (value == null || value.isEmpty) {
            return 'Please enter your phone number';
          }
          return null;
        },
      ),
    );
  }
  Widget _checkBoxButton() {
    return SizedBox(
      height: 40.h,
      width: 400.w,
      child: ElevatedButton(
        style: ElevatedButton.styleFrom(
          backgroundColor: Colors.black,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(25.0.r),
          ),
        ),
        onPressed: () {
          if (_phoneController.text.isEmpty || selectedCountryCode == null || _phoneController.text.length < 10) {
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(content: Text("Please enter a valid phone number")),
            );
          } else {

            Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (BuildContext context) => OTP(phoneNumber: _phoneController.text, isoCode: isoCode!, countryCode: selectedCountryCode!,)));
          }
        },
        child: _isLoading
            ? CircularProgressIndicator(color: Colors.white)
            : const Text(
          "Continue",
          style: TextStyle(color: Colors.white, fontSize: 20),
        ),
      ),
    );
  }
}

// import 'package:country_code_picker/country_code_picker.dart';
// import 'package:flutter/cupertino.dart';
// import 'package:flutter/material.dart';
// import 'package:flutter/services.dart';
// import 'package:flutter_screenutil/flutter_screenutil.dart';
// import 'package:google_fonts/google_fonts.dart';
// import 'package:milan/otp_page.dart';
// import 'package:dio/dio.dart';  // Import dio package
// import 'dart:convert';
//
// class LoginPage extends StatefulWidget {
//   const LoginPage({super.key});
//
//   @override
//   State<LoginPage> createState() => _LoginPageState();
// }
//
// class _LoginPageState extends State<LoginPage> {
//   final TextEditingController _phoneController = TextEditingController();
//   String? selectedCountryCode;
//   String? isoCode;
//   bool _isLoading = false;
//
//   @override
//   Widget build(BuildContext context) {
//     return SafeArea(
//       child: Scaffold(
//         body: SingleChildScrollView(
//           child: Column(
//             children: [
//               Container(
//                 height: 780.h,
//                 alignment: Alignment.bottomCenter,
//                 decoration: const BoxDecoration(
//                   image: DecorationImage(
//                     image: AssetImage("assets/images/login.png"),
//                     fit: BoxFit.cover,
//                   ),
//                 ),
//                 child: Container(
//                   margin: EdgeInsets.only(top: 480.h),
//                   decoration: BoxDecoration(
//                     color: Colors.white,
//                     borderRadius: BorderRadius.only(
//                       topLeft: Radius.circular(20.r),
//                       topRight: Radius.circular(20),
//                     ),
//                   ),
//                   child: Padding(
//                     padding: EdgeInsets.only(left: 20.w, right: 20.w, top: 20.h),
//                     child: Column(
//                       crossAxisAlignment: CrossAxisAlignment.start,
//                       children: [
//                         Text(
//                           "Enter Your\nPhone Number",
//                           style: GoogleFonts.gabarito(
//                             fontSize: 30.sp,
//                             fontWeight: FontWeight.w600,
//                           ),
//                         ),
//                         Text(
//                           "Unlock your experience.",
//                           style: GoogleFonts.gabarito(
//                             fontSize: 18,
//                             fontWeight: FontWeight.w400,
//                           ),
//                         ),
//                         SizedBox(height: 10.h),
//                         _phoneNumberTextField(),
//                         SizedBox(height: 10.h),
//                         _checkBoxButton(),
//                       ],
//                     ),
//                   ),
//                 ),
//               ),
//             ],
//           ),
//         ),
//       ),
//     );
//   }
//
//   Widget _phoneNumberTextField() {
//     return Container(
//       decoration: BoxDecoration(
//         color: Colors.grey.withOpacity(0.2),
//         borderRadius: BorderRadius.circular(20),
//       ),
//       child: TextFormField(
//         controller: _phoneController,
//         textInputAction: TextInputAction.done,
//         keyboardType: TextInputType.number,
//         inputFormatters: [
//           LengthLimitingTextInputFormatter(10),
//         ],
//         decoration: InputDecoration(
//           fillColor: Colors.grey,
//           contentPadding: const EdgeInsets.all(10),
//           prefixIcon: SizedBox(
//             height: 30.h,
//             width: 110.w,
//             child: Row(
//               mainAxisAlignment: MainAxisAlignment.spaceEvenly,
//               children: [
//                 CountryCodePicker(
//                   onChanged: (country) {
//                     setState(() {
//                       selectedCountryCode = country.dialCode;
//                       isoCode = country.code;  // Save the iso code too
//                     });
//                     print('Selected country: ${country.dialCode}');
//                     print(isoCode);
//                   },
//                   initialSelection: 'US',
//                   favorite: const ['+39', 'FR'],
//                   showFlag: true,
//                   showOnlyCountryWhenClosed: false,
//                   showCountryOnly: false,
//                   flagWidth: 20.w,
//                 ),
//               ],
//             ),
//           ),
//           border: InputBorder.none,
//           hintText: '| Enter Phone Number',
//           hintStyle: const TextStyle(
//             color: Colors.grey,
//             overflow: TextOverflow.ellipsis,
//           ),
//         ),
//         maxLines: 1,
//         validator: (value) {
//           if (value == null || value.isEmpty) {
//             return 'Please enter your phone number';
//           }
//           return null;
//         },
//       ),
//     );
//   }
//
//   Widget _checkBoxButton() {
//     return SizedBox(
//       height: 57.h,
//       width: 400.w,
//       child: ElevatedButton(
//         style: ElevatedButton.styleFrom(
//           backgroundColor: Colors.black,
//           shape: RoundedRectangleBorder(
//             borderRadius: BorderRadius.circular(25.0),
//           ),
//         ),
//         onPressed: () {
//           if (_phoneController.text.isEmpty || selectedCountryCode == null || _phoneController.text.length < 10) {
//             ScaffoldMessenger.of(context).showSnackBar(
//               SnackBar(content: Text("Please enter a valid phone number")),
//             );
//           } else {
//             // Navigate to OTP screen after validation
//             Navigator.of(context).pushReplacement(
//               MaterialPageRoute(
//                 builder: (BuildContext context) => OTP(
//                   phoneNumber: _phoneController.text,
//                   isoCode: isoCode!,
//                   countryCode: selectedCountryCode!,
//                 ),
//               ),
//             );
//           }
//         },
//         child: _isLoading
//             ? CircularProgressIndicator(color: Colors.white)
//             : const Text(
//           "Continue",
//           style: TextStyle(color: Colors.white, fontSize: 20),
//         ),
//       ),
//     );
//   }
//
//   Future<void> postPhoneData() async {
//     if (_phoneController.text.isEmpty || selectedCountryCode == null || _phoneController.text.length < 10) {
//       ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Please enter valid details')));
//       return;
//     }
//
//     var data = {
//       'iso_code': isoCode?.toLowerCase(),
//       'phone_code': selectedCountryCode,
//       'phone': _phoneController.text,
//     };
//
//     String url = 'http://192.168.2.34:8004/api/v1/verify-firebase';
//
//     try {
//       setState(() {
//         _isLoading = true;
//       });
//
//       Dio dio = Dio();
//       Response response = await dio.post(url, data: data);
//
//       if (response.statusCode == 200) {
//         Navigator.of(context).pushReplacement(
//           MaterialPageRoute(
//             builder: (BuildContext context) => OTP(
//               phoneNumber: _phoneController.text,
//               isoCode: isoCode!,
//               countryCode: selectedCountryCode!,
//             ),
//           ),
//         );
//       } else {
//         ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Error: ${response.statusCode}')));
//       }
//     } catch (e) {
//       ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Failed to send data')));
//     } finally {
//       setState(() {
//         _isLoading = false;
//       });
//     }
//   }
// }


