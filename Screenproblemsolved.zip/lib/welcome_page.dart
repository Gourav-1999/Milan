import 'dart:async';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_onboarding_slider/background_final_button.dart';
import 'package:flutter_onboarding_slider/flutter_onboarding_slider.dart';
import 'package:flutter_overboard/flutter_overboard.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:milan/login_page.dart';

class WelcomePage extends StatefulWidget {
  const WelcomePage({super.key});
  @override
  State<WelcomePage> createState() => _WelcomePage();
}

class _WelcomePage extends State<WelcomePage> {

  @override
  void initState() {
    super.initState();
    Timer(const Duration(seconds: 2),
            () =>
            Navigator.pushReplacement(context,
                MaterialPageRoute(builder:
                    (context) =>
                        Welcome()
                )
            )
    );
  }

  @override
  Widget build(BuildContext context) {
    return Container(
        alignment: Alignment.center,
        color: Colors.white,
        child: Image(image: AssetImage("assets/overboard/heartimg.png"),)
    );
  }
}
class Welcome extends StatelessWidget {
  Welcome({super.key});

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body: OnBoardingSlider(
          finishButtonTextStyle: TextStyle(color: Colors.white,fontSize: 20),
          controllerColor: Colors.black,
          headerBackgroundColor: Colors.white,
          skipIcon: const Icon(Icons.arrow_forward,color: Colors.white,),
          finishButtonText: 'Get Started',
          onFinish: () {
            Navigator
                .of(context)
                .pushReplacement(new MaterialPageRoute(builder: (BuildContext context) {
              return new LoginPage();
            }));
          },
          finishButtonStyle: const FinishButtonStyle(
            backgroundColor: Colors.black,
          ),
          skipTextButton: const Text(
            "Skip",
            maxLines: 1,
            style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
                decoration: TextDecoration.underline,
                color: Colors.black,
                decorationColor: Colors.black,
                decorationThickness: 1),
          ),
          background: [
            Padding(
              padding:  EdgeInsets.only(top: 120.h),
              child: Image.asset(
                  'assets/overboard/Group1.png',
                  width: 350.w, height: 506.h
              ),
            ),
            Padding(
              padding: EdgeInsets.only(top: 120.h,left: 30.w),
              child: Image.asset(
                  'assets/overboard/Group2.png',
                  width: 310.w, height: 543.h
              ),
            ),
            Padding(
              padding:  EdgeInsets.only(top: 120.h),
              child: Image.asset(
                  'assets/overboard/Group3.png',
                  width: 360.w, height: 464.h
              ),
            ),
          ],
          totalPage: 3,
          speed: 1.8,
          pageBodies: [
          Column(crossAxisAlignment: CrossAxisAlignment.start,
           children: [
             Padding(
               padding:  EdgeInsets.only(left: 34.w,top: 10.h),
               child: Text("Find Amazing",
                  style: GoogleFonts.gabarito(
                  fontSize: 35,
                  fontWeight: FontWeight.w400,
                  ),
                  ),
             ),
             Padding(
               padding:  EdgeInsets.only(left: 34.w),
               child: Text("People Around You",
                 style:GoogleFonts.gabarito(
                   fontSize: 35,
                   fontWeight: FontWeight.w800
                 ),
               ),
             ),
           ],
           ),
            Column(crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Padding(
                  padding: EdgeInsets.only(left: 34.w,top: 10.h),
                  child: Text("Connect With",
                    style: GoogleFonts.gabarito(
                      fontSize: 35,
                      fontWeight: FontWeight.w400,
                    ),
                  ),
                ),
                Padding(
                  padding: EdgeInsets.only(left: 34.w),
                  child: Text("Friends Nearby",
                    style:GoogleFonts.gabarito(
                        fontSize: 35,
                        fontWeight: FontWeight.w800
                    ),
                  ),
                ),
              ],
            ),
            Column(crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Padding(
                  padding:  EdgeInsets.only(left: 34.w,top: 10.h),
                  child: Text("Start Building",
                    style: GoogleFonts.gabarito(
                      fontSize: 35,
                      fontWeight: FontWeight.w400,
                    ),
                  ),
                ),
                Padding(
                  padding:  EdgeInsets.only(left: 34.w),
                  child: Text("Your Local Network",
                    style:GoogleFonts.gabarito(
                        fontSize: 35,
                        fontWeight: FontWeight.w800
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
