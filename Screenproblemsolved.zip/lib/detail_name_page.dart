import 'dart:async';
import 'dart:convert';
import 'package:dio/dio.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:milan/commons/local_storage.dart';
import 'package:milan/detail_gender_page.dart';
import 'login_page.dart';

class EnterName extends StatefulWidget {
  EnterName({super.key});

  @override
  State<EnterName> createState() => _EnterNameState();
}

final TextEditingController fullName = TextEditingController();
final TextEditingController bio = TextEditingController();

class _EnterNameState extends State<EnterName> {
  final Dio _dio = Dio();

  //Future<String?> token = getToken();

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
  }

  void showSnackBar(String message) {
    ScaffoldMessenger.of(context)
        .showSnackBar(SnackBar(content: Text(message)));
  }

  Future<void> postAboutData() async {
    if (fullName.text.isEmpty && bio.text.isEmpty) {
      showSnackBar('Please enter a Name or Bio');
      return;
    }

    // Future<String?> setToken = getToken();
    // String? token1;
    // setToken.then((value) {
    //  token1=value;
    // });
    Map<String, dynamic> map = {
      "name": fullName.text,
      "about": bio.text,
      "steps": 1,
    };

    String url = 'http://192.168.2.42:8004/api/v1/update-details';
    try {
      final response = await _dio.post(
        url,
        data: jsonEncode(map),
        options: Options(
          headers: {
            'Content-Type': 'application/json',
            // 'Accept': 'application/json',
            'Authorization': 'Bearer ${await LocalStorage.getToken()}'
          },
        ),
      );

      print(response.data);
      if (response.statusCode == 200) {
        Navigator.of(context).pushReplacement(
            new MaterialPageRoute(builder: (BuildContext context) {
          return new GenderPage();
        }));
      } else {
        showSnackBar('Error: ${response.statusCode}');
        print(response.statusCode);
      }
    } catch (e) {
      showSnackBar('Failed to send data: $e');
      print(e);
      //String? token = await getToken();
    }
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
      body: Padding(
        padding: EdgeInsets.only(left: 18.w, top: 50.h, right: 18.w),
        child: SingleChildScrollView(
          child: Container(
            height: MediaQuery.of(context).size.height,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                GestureDetector(
                  onTap: () {
                    Navigator.of(context).pushReplacement(
                        new MaterialPageRoute(builder: (BuildContext context) {
                      return new LoginPage();
                    }));
                  },
                  child: Container(
                    margin: EdgeInsets.only(bottom: 18.h),
                    height: 50.h,
                    width: 50.w,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: Colors.black.withOpacity(0.025),
                    ),
                    child: const Center(child: Icon(Icons.arrow_back)),
                  ),
                ),
                Text(
                  "Your\nName",
                  style: GoogleFonts.gabarito(
                      fontSize: 30.sp, fontWeight: FontWeight.w600),
                ),
                SizedBox(
                  height: 10.h,
                ),
                Text(
                  "Never miss a moment, reconnect with ease.",
                  style: GoogleFonts.gabarito(
                      fontSize: 16.sp, fontWeight: FontWeight.w500),
                ),
                SizedBox(
                  height: 10.h,
                ),
                _nameTextField,
                SizedBox(
                  height: 20.h,
                ),
                _bioTextField,
                const Spacer(),
                Center(
                    child: SizedBox(
                  height: 40.h,
                  width: 400.w,
                  child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.black,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(25.0.r),
                        ), // Background color
                      ),
                      onPressed: () {
                        if (fullName.text.isEmpty || bio.text.isEmpty) {
                          showSnackBar("Please enter Details");
                        } else {
                          postAboutData();
                        }
                      },
                      child:  Text(
                        "Next",
                        style: TextStyle(
                            color: Colors.white,
                            fontSize: 20.sp,
                            overflow: TextOverflow.ellipsis),
                        maxLines: 1,
                      )),
                )),
                SizedBox(
                  height: 10.h,
                ),
              ],
            ),
          ),
        ),
      ),
    ));
  }
}

Widget get _nameTextField => Container(
      margin: EdgeInsets.only(right: 18.w),
      decoration: BoxDecoration(
          color: Colors.black.withOpacity(0.055),
          borderRadius: BorderRadius.circular(10.r)),
      child: TextFormField(
        controller: fullName,
        textInputAction: TextInputAction.done,
        keyboardType: TextInputType.text,
        decoration: InputDecoration(
          fillColor: Colors.black.withOpacity(0.025),
          contentPadding:
          EdgeInsets.only(left: 20.w, right: 10.w, top: 10.h, bottom: 10.h),
          border: InputBorder.none,
          hintText: 'Enter Full Name',
          hintStyle: const TextStyle(
              color: Colors.grey, overflow: TextOverflow.ellipsis),
        ),
        maxLines: 1,
      ),
    );

Widget get _bioTextField => Container(
      height: 200.h,
      width: 400.w,
      margin: EdgeInsets.only(right: 18.w),
      decoration: BoxDecoration(
          color: Colors.black.withOpacity(0.055),
          borderRadius: BorderRadius.circular(10.r)),
      child: TextFormField(
        controller: bio,
        textInputAction: TextInputAction.done,
        keyboardType: TextInputType.text,
        decoration: InputDecoration(
          fillColor: Colors.black.withOpacity(0.025),
          contentPadding:
             EdgeInsets.only(left: 20.w, right: 10.w, top: 10.h, bottom: 10.h),
          border: InputBorder.none,
          hintText: 'My Bio',
          hintStyle: const TextStyle(
              color: Colors.grey, overflow: TextOverflow.ellipsis),
        ),
        maxLines: 1,
      ),
    );
