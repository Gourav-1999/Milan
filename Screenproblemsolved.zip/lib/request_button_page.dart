import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:milan/milan.dart';
import 'package:milan/send_request.dart';

import 'custom_app_bar.dart';

class Requests extends StatefulWidget {
  const Requests({super.key});

  @override
  State<Requests> createState() => _RequestsState();
}
List<DataList> items=[];

class _RequestsState extends State<Requests> {

  itemList(){
    items.clear();
    items.add(DataList(name: "Aliza Davis",image: "assets/send/Rectangle 725.png"));
    items.add(DataList(name: "Aliza Davis",image: "assets/send/Rectangle 727.png"));
    items.add(DataList(name: "Aliza Davis",image: "assets/send/image 6.png"));
    items.add(DataList(name: "Aliza Davis",image: "assets/send/Rectangle 728.png"));
    items.add(DataList(name: "Aliza Davis",image: "assets/send/Rectangle 731.png"));
    items.add(DataList(name: "Aliza Davis",image: "assets/send/Rectangle 732.png"));
    items.add(DataList(name: "Aliza Davis",image: "assets/send/Rectangle 725.png"));
    items.add(DataList(name: "Aliza Davis",image: "assets/send/Rectangle 727.png"));
    items.add(DataList(name: "Aliza Davis",image: "assets/send/image 6.png"));
    items.add(DataList(name: "Aliza Davis",image: "assets/send/Rectangle 728.png"));
    items.add(DataList(name: "Aliza Davis",image: "assets/send/Rectangle 731.png"));
    items.add(DataList(name: "Aliza Davis",image: "assets/send/Rectangle 732.png"));
    setState(() {

    });
  }
  @override
  void initState() {
    // TODO: implement initState
    itemList();
    super.initState();
  }
  @override
  Widget build(BuildContext context) {
    return ScreenUtilInit(
      designSize: const Size(430, 942),
      minTextAdapt: true,
      splitScreenMode: true,
      child: SafeArea(child: Scaffold(
        body: Padding(
          padding: EdgeInsets.only(top: 25.h, left: 18.w),
          child: Column(
            children: [
             Row(
               crossAxisAlignment: CrossAxisAlignment.center,
               children: [
                 IconButton(onPressed: (){
                   Navigator.of(context).pushReplacement(
                     MaterialPageRoute(builder: (BuildContext context) {
                       return  Milan(Index: 1,);
                     }),
                   );
                 }, icon: Icon(Icons.arrow_back)),
                 SizedBox(width: 10.w,),
                 Text(
                   "Request",
                   style: GoogleFonts.gabarito(
                       fontSize: 18, fontWeight: FontWeight.w600,
                   ), overflow: TextOverflow.ellipsis,maxLines: 2,
                 ),
               ],
             ),
              _MenuItemsWidget
            ],
          ),
        ),
      )),
    );
  }
}
Widget get _MenuItemsWidget => Expanded(
  child: GridView.builder(
    shrinkWrap: true,
    gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2, // number of items in each row
        mainAxisSpacing: 12.0, // spacing between rows
        crossAxisSpacing: 12.0,
        childAspectRatio: 0.8,

      // spacing between columns
    ),
    padding: EdgeInsets.only(right: 18.w,top: 18.h),
    // padding around the grid
    itemCount: items.length,
    // total number of items
    itemBuilder: (context, index) {
      return Stack(
        children: [
          Container(
            decoration: BoxDecoration(
              shape: BoxShape.rectangle,
              borderRadius: BorderRadius.circular(15.r),
              image: DecorationImage(
                  image: AssetImage(items[index].image),
                  fit: BoxFit.fill),
            ),
          ),
          Positioned(
            top: 160.h,
            child: Padding(
              padding:  EdgeInsets.only(left: 10.w),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    items[index].name,
                    style: GoogleFonts.gabarito(
                        fontSize: 18, fontWeight: FontWeight.w400,
                        color:Colors.white
                    ), overflow: TextOverflow.ellipsis,maxLines: 2,
                  ),
                  Row(
                    children: [
                      Icon(Icons.location_on,color: Colors.white,size: 16.sp,),
                      Text(
                        "Florida",
                        style: GoogleFonts.gabarito(
                            fontSize: 14, fontWeight: FontWeight.w400,
                            color:Colors.white
                        ), overflow: TextOverflow.ellipsis,maxLines: 2,
                      ),
                    ],
                  )
                ],
              ),
            ),
          ),
        ],
      );
    },
  ),
);

class DataList{
  String name;
  String image;
  DataList({required this.name,required this.image});

}