import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:switcher_button/switcher_button.dart';

class Settings extends StatefulWidget {
  const Settings({super.key});

  @override
  State<Settings> createState() => _SettingsState();
}

class _SettingsState extends State<Settings> {
  @override
  Widget build(BuildContext context) {
    return ScreenUtilInit(
      designSize: const Size(430, 942),
      minTextAdapt: true,
      splitScreenMode: true,
      child: SafeArea(child: Scaffold(
        body: Padding(
          padding: EdgeInsets.only(left: 18.w, top: 50.h,right: 18.w),
          child: Column(
            children: [
              Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  GestureDetector(
                    onTap: () {
                      Navigator.pop(context);
                    },
                    child: Container(

                      height: 60.h,
                      width: 60.w,
                      decoration: BoxDecoration(

                        shape: BoxShape.circle,
                        color: Colors.black.withOpacity(0.025),
                      ),
                      child: const Center(child: Icon(Icons.arrow_back)),
                    ),
                  ),
                  SizedBox(width: 20.w,),
                  Text(
                    "Settings",
                    style: GoogleFonts.gabarito(
                        fontSize: 20.sp, fontWeight: FontWeight.w600),
                  ),
                ],
              ),
              SizedBox(height: 20.h,),
              Row(
                children: [
                  Icon(Icons.notifications_none_rounded),
                  Expanded(
                    child: Text(
                      "Notification",
                      style: GoogleFonts.gabarito(
                          fontSize: 16.sp, fontWeight: FontWeight.w500),
                    ),
                  ),
                  SwitcherButton(
                    value: true,
                    offColor: Colors.white70,
                    onColor: Colors.black.withOpacity(0.09),
                    onChange: (value) {
                      print(value);
                    },
                  )
                ],
              ),
              SizedBox(height: 10.h,),
              Row(
                children: [
                  Icon(Icons.delete_outline_rounded),
                  Expanded(
                    child: Text(
                      "Delete Account",
                      style: GoogleFonts.gabarito(
                          fontSize: 16.sp, fontWeight: FontWeight.w500),
                    ),
                  ),
                  IconButton(onPressed: () {

                    showModalBottomSheet<void>(
                      backgroundColor: Colors.white,
                      context: context,
                      useRootNavigator: true,
                      builder: (BuildContext context) {
                        final bottomNavHeight = MediaQuery.of(context).padding.bottom;
                        return Container(
                          padding: EdgeInsets.only(bottom: bottomNavHeight + 20),
                          margin: const EdgeInsets.symmetric(horizontal: 20),
                          height: 320,
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.start,
                            mainAxisSize: MainAxisSize.min,
                            children: <Widget>[
                              SizedBox(height: 5,),
                              Center(
                                child: Container(
                                  height: 5,
                                  width: 40,
                                  decoration: BoxDecoration(
                                      shape: BoxShape.rectangle,
                                      color: Colors.grey[400],
                                      borderRadius: BorderRadius.circular(10)
                                  ),
                                ),
                              ),
                              SizedBox(height: 30,),
                              Container(
                                height: 100.h,
                                width: 100.w,
                                decoration: BoxDecoration(
                                  shape: BoxShape.rectangle,
                                    image: DecorationImage(
                                      image: AssetImage("assets/images/Group 94.png"),
                                      fit: BoxFit.contain,
                                    )
                                ),
                              ),
                              SizedBox(height: 10.h,),
                              Text(
                                "Delete Account",
                                style: GoogleFonts.gabarito(
                                    fontSize: 24.sp, fontWeight: FontWeight.w500),
                              ),
                              SizedBox(height: 10.h,),
                              Text(
                                "Deleting your account will permanently remove all of your data associated with that account.",
                                style: GoogleFonts.gabarito(
                                    fontSize: 16.sp, fontWeight: FontWeight.w400),textAlign: TextAlign.center,
                              ),
                              SizedBox(height: 20.h,),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Container(
                                    height:50.h,
                                    width: 150.w,
                                    decoration: BoxDecoration(
                                      color: Colors.black.withOpacity(0.025),
                                      shape: BoxShape.rectangle,
                                      borderRadius: BorderRadius.circular(30),

                                    ),
                                    child: Center(
                                      child: Text(
                                        "Cancel",
                                        style: GoogleFonts.gabarito(
                                            fontSize: 18.sp, fontWeight: FontWeight.w500,color:Colors.grey),
                                      ),
                                    ),
                                  ),
                                  SizedBox(width: 50.w,),
                                  Container(
                                    height:50.h,
                                    width: 150.w,
                                    decoration: BoxDecoration(
                                      color: Colors.red.withOpacity(0.025),
                                      shape: BoxShape.rectangle,
                                      borderRadius: BorderRadius.circular(30),

                                    ),
                                    child: Center(
                                      child: Text(
                                        "Confirm",
                                        style: GoogleFonts.gabarito(
                                            fontSize: 18.sp, fontWeight: FontWeight.w500,color:Colors.red),
                                      ),
                                    ),
                                  )
                                ],
                              )

                            ],
                          ),
                        );
                      },
                    );

                  }, icon: Icon(Icons.arrow_forward_ios_rounded,size: 14,),)
                ],
              )
            ],
          ),
        )
      )),
    );
  }
}
