import 'dart:convert';

import 'package:dio/dio.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:milan/detail_ethnicity_page.dart';
import 'package:milan/detail_looking_page.dart';
import 'package:milan/seeking_page.dart';
import 'package:roundcheckbox/roundcheckbox.dart';

import 'commons/local_storage.dart';
import 'models/user_model.dart';

class RelationPage extends StatefulWidget {
  const RelationPage({super.key});

  @override
  State<RelationPage> createState() => _RelationPageState();
}

int? currentIndex;

class _RelationPageState extends State<RelationPage> {
  int? currentIndex;
  List<OptionList> itemList = [];
  final Dio _dio = Dio();
  bool isSelected = false;
  final String apiUrl = 'http://192.168.2.42:8004/api/v1/update-details';

  optionList() {
    itemList.clear();
    itemList.add(OptionList(text: "Single"));
    itemList.add(OptionList(text: "Married"));
    itemList.add(OptionList(text: "Divorced"));
    itemList.add(OptionList(text: "Widow"));
    itemList.add(OptionList(text: "In a Relationship"));
    itemList.add(OptionList(text: "Prefer not to say"));
    setState(() {});
  }

  @override
  void initState() {
    // TODO: implement initState
    optionList();
    super.initState();
  }

  Future<void> postStatus() async {
    int id = currentIndex! + 1;
    Map<String, dynamic> map = {
      "relation_status": id,
      "steps": 4,
      "show_relation_status": isSelected ? 1 : 0
    };

    try {
      final response = await _dio.post(
        apiUrl,
        data: jsonEncode(map),
        options: Options(
          headers: {
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ${await LocalStorage.getToken()}'
          },
        ),
      );
      print(response.data);
      print(map);
      UserModal userModal = UserModal.fromJson(response.data);
      print("Status--${userModal?.data?.gender}");
      if (response.statusCode == 200) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Successfully add status')),
        );
        Navigator.of(context).pushReplacement(
          MaterialPageRoute(
            builder: (BuildContext context) {
              return const SeekingPage();
            },
          ),
        );
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Erorr: Failed add status')),
        );
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Failed add status')),
      );
      print(e);
    }
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
            body: Padding(
      padding: EdgeInsets.only(left: 18.w, top: 50.h, right: 18.w),
      child: SingleChildScrollView(
        child: Container(
          height: MediaQuery.of(context).size.height,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              GestureDetector(
                onTap: () {
                  Navigator.of(context).pushReplacement(
                      new MaterialPageRoute(builder: (BuildContext context) {
                    return new LookingPage();
                  }));
                },
                child: Container(
                  margin: EdgeInsets.only(bottom: 18),
                  height: 50.h,
                  width: 50.w,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: Colors.black.withOpacity(0.025),
                  ),
                  child: const Center(child: Icon(Icons.arrow_back)),
                ),
              ),
              Text(
                "Your\nRelationship Status",
                style: GoogleFonts.gabarito(
                    fontSize: 30.sp, fontWeight: FontWeight.w600),
              ),
              SizedBox(
                height: 15.h,
              ),
              Text(
                "Find your next adventure buddy.",
                style: GoogleFonts.gabarito(
                    fontSize: 16.sp, fontWeight: FontWeight.w500),
              ),
              Container(
                margin: EdgeInsets.only(top: 20.h),
                child: ListView.builder(
                    itemCount: itemList.length,
                    physics: NeverScrollableScrollPhysics(),
                    shrinkWrap: true,
                    itemBuilder: (context, index) {
                      return GestureDetector(
                        onTap: () {
                          setState(() {
                            currentIndex = index;
                          });
                        },
                        child: currentIndex == index
                            ? Container(
                                height: 50.h,
                                width: 400.w,
                                margin: EdgeInsets.only(top: 5.h, bottom: 5.h),
                                padding: EdgeInsets.all(20),
                                decoration: BoxDecoration(
                                  border: Border.all(
                                      width: 1.5, color: Colors.blue),
                                  color: Colors.black.withOpacity(0.025),
                                  borderRadius: BorderRadius.circular(10.r),
                                ),
                                child: Row(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Expanded(
                                        child: Text(
                                      itemList[index].text,
                                      style: GoogleFonts.gabarito(
                                          color: Colors.blue,
                                          fontSize: 16.sp,
                                          fontWeight: FontWeight.w600),
                                      maxLines: 1,
                                    )),
                                    Container(
                                      height: 20.h,
                                      width: 20.h,
                                      decoration: BoxDecoration(
                                        shape: BoxShape.circle,
                                        border: Border.all(
                                            width: 6, color: Colors.black),
                                      ),
                                    )
                                  ],
                                ),
                              )
                            : Container(
                                height: 50.h,
                                width: 400.w,
                                decoration: BoxDecoration(
                                  color: Colors.black.withOpacity(0.025),
                                  borderRadius: BorderRadius.circular(10.r),
                                ),
                                margin: EdgeInsets.only(top: 5.h, bottom: 5.h),
                                padding: EdgeInsets.all(20),
                                child: Row(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Expanded(
                                        child: Text(
                                      itemList[index].text,
                                      style: GoogleFonts.gabarito(
                                          fontSize: 16.sp,
                                          fontWeight: FontWeight.w600),
                                      maxLines: 1,
                                    )),
                                    Container(
                                      height: 20.h,
                                      width: 20.h,
                                      decoration: BoxDecoration(
                                        shape: BoxShape.circle,
                                        color: Colors.black.withOpacity(0.045),
                                      ),
                                    )
                                  ],
                                ),
                              ),
                      );
                    }),
              ),
              SizedBox(
                height: 10.h,
              ),
              Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Row(
                    children: [
                      GestureDetector(
                          onTap: () {
                            setState(() {
                              isSelected = !isSelected;
                            });
                            // postGender();
                          },
                          child: isSelected
                              ? const Icon(
                                  Icons.check_circle,
                                )
                              : const Icon(
                                  Icons.check_circle_outlined,
                                )),
                      SizedBox(
                        width: 5.sp,
                      ),
                      Text(
                        "Show on my profile",
                        style: GoogleFonts.gabarito(
                            fontSize: 17.sp, fontWeight: FontWeight.w500),
                      ),
                    ],
                  ),
                ],
              ),
              Spacer(),
              Center(
                  child: SizedBox(
                height: 40.h,
                width: 400.w,
                child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.black,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(25.0.r),
                      ), // Background color
                    ),
                    onPressed: () {
                      if (currentIndex == null) {
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(
                              content:
                                  Text('Please select Relationship Status')),
                        );
                      } else {
                        postStatus();
                      }
                    },
                    child: const Text(
                      "Next",
                      style: TextStyle(
                          color: Colors.white,
                          fontSize: 20,
                          overflow: TextOverflow.ellipsis),
                      maxLines: 1,
                    )),
              )),
              SizedBox(height: 10.h,),
            ],
          ),
        ),
      ),
    )));
  }
}

class OptionList {
  String text;

  OptionList({
    required this.text,
  });
}
