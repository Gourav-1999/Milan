// import 'package:milan/chat_page.dart';
//
// class UserModal {
//   int? status;
//   String? message;
//   UserDataModal? data;
//
//   UserModal({this.status, this.message, this.data});
//
//   UserModal.fromJson(Map<String, dynamic> json) {
//     status = json['status'];
//     message = json['message'];
//     data = json['data'] != null ? UserDataModal.fromJson(json['data']) : null;
//   }
//
//   Map<String, dynamic> toJson() {
//     final Map<String, dynamic> data = <String, dynamic>{};
//     data['status'] = status;
//     data['message'] = message;
//     if (this.data != null) {
//       data['data'] = this.data!.toJson();
//     }
//     return data;
//   }
// }
//
// class UserDataModal {
//   var id;
//   var name;
//   var email;
//   var emailVerifyToken;
//   var emailVerifiedAt;
//   var isoCode;
//   var phoneCode;
//   var phone;
//   var phoneVerifiedAt;
//   var dob;
//   var age;
//   var address;
//   var latitude;
//   var longitude;
//   var about;
//   var preferedDistance;
//   var minAge;
//   var maxAge;
//   var enableDiscovery;
//   var isChat;
//   var matchId;
//   var activeStatus;
//   var roleId;
//   var gender;
//   var showGender;
//   var interestedIn;
//   var showInterestedIn;
//   var relationStatus;
//   var showRelationStatus;
//   var lookingFor;
//   var showLookingFor;
//   var ethnicity;
//   var showEthnicity;
//   var childrenType;
//   var showChildrenType;
//   var steps;
//   var fcmToken;
//   var rememberToken;
//   var isNotify;
//   var deviceType;
//   var typeId;
//   var stateId;
//   var createdAt;
//   var updatedAt;
//   var genderRel;
//   List<String>? interests;
//   List<String>? userImages;
//
//   UserDataModal(
//       {this.id,
//         this.name,
//         this.email,
//         this.emailVerifyToken,
//         this.emailVerifiedAt,
//         this.isoCode,
//         this.phoneCode,
//         this.phone,
//         this.phoneVerifiedAt,
//         this.dob,
//         this.age,
//         this.address,
//         this.latitude,
//         this.longitude,
//         this.about,
//         this.preferedDistance,
//         this.minAge,
//         this.maxAge,
//         this.enableDiscovery,
//         this.isChat,
//         this.matchId,
//         this.activeStatus,
//         this.roleId,
//         this.gender,
//         this.showGender,
//         this.interestedIn,
//         this.showInterestedIn,
//         this.relationStatus,
//         this.showRelationStatus,
//         this.lookingFor,
//         this.showLookingFor,
//         this.ethnicity,
//         this.showEthnicity,
//         this.childrenType,
//         this.showChildrenType,
//         this.steps,
//         this.fcmToken,
//         this.rememberToken,
//         this.isNotify,
//         this.deviceType,
//         this.typeId,
//         this.stateId,
//         this.createdAt,
//         this.updatedAt,
//         this.genderRel,
//         this.interests,
//         this.userImages});
//
//   UserDataModal.fromJson(Map<String, dynamic> json) {
//     id = json['id'];
//     name = json['name'];
//     email = json['email'];
//     emailVerifyToken = json['email_verify_token'];
//     emailVerifiedAt = json['email_verified_at'];
//     isoCode = json['iso_code'];
//     phoneCode = json['phone_code'];
//     phone = json['phone'];
//     phoneVerifiedAt = json['phone_verified_at'];
//     dob = json['dob'];
//     age = json['age'];
//     address = json['address'];
//     latitude = json['latitude'];
//     longitude = json['longitude'];
//     about = json['about'];
//     preferedDistance = json['prefered_distance'];
//     minAge = json['min_age'];
//     maxAge = json['max_age'];
//     enableDiscovery = json['enable_discovery'];
//     isChat = json['isChat'];
//     matchId = json['match_id'];
//     activeStatus = json['active_status'];
//     roleId = json['role_id'];
//     gender = json['gender'];
//     showGender = json['show_gender'];
//     interestedIn = json['interested_in'];
//     showInterestedIn = json['show_interested_in'];
//     relationStatus = json['relation_status'];
//     showRelationStatus = json['show_relation_status'];
//     lookingFor = json['looking_for'];
//     showLookingFor = json['show_looking_for'];
//     ethnicity = json['ethnicity'];
//     showEthnicity = json['show_ethnicity'];
//     childrenType = json['children_type'];
//     showChildrenType = json['show_children_type'];
//     steps = json['steps'];
//     fcmToken = json['fcm_token'];
//     rememberToken = json['remember_token'];
//     isNotify = json['is_notify'];
//     deviceType = json['device_type'];
//     typeId = json['type_id'];
//     stateId = json['state_id'];
//     createdAt = json['created_at'];
//     updatedAt = json['updated_at'];
//     genderRel = json['gender_rel'];
//     interests = json['interests'] != null ? List<String>.from(json['interests']) : null;
//     userImages = json['user_images'] != null ? List<String>.from(json['user_images']) : null;
//   }
//
//   Map<String, dynamic> toJson() {
//     final Map<String, dynamic> data = <String, dynamic>{};
//     data['id'] = id;
//     data['name'] = name;
//     data['email'] = email;
//     data['email_verify_token'] = emailVerifyToken;
//     data['email_verified_at'] = emailVerifiedAt;
//     data['iso_code'] = isoCode;
//     data['phone_code'] = phoneCode;
//     data['phone'] = phone;
//     data['phone_verified_at'] = phoneVerifiedAt;
//     data['dob'] = dob;
//     data['age'] = age;
//     data['address'] = address;
//     data['latitude'] = latitude;
//     data['longitude'] = longitude;
//     data['about'] = about;
//     data['prefered_distance'] = preferedDistance;
//     data['min_age'] = minAge;
//     data['max_age'] = maxAge;
//     data['enable_discovery'] = enableDiscovery;
//     data['isChat'] = isChat;
//     data['match_id'] = matchId;
//     data['active_status'] = activeStatus;
//     data['role_id'] = roleId;
//     data['gender'] = gender;
//     data['show_gender'] = showGender;
//     data['interested_in'] = interestedIn;
//     data['show_interested_in'] = showInterestedIn;
//     data['relation_status'] = relationStatus;
//     data['show_relation_status'] = showRelationStatus;
//     data['looking_for'] = lookingFor;
//     data['show_looking_for'] = showLookingFor;
//     data['ethnicity'] = ethnicity;
//     data['show_ethnicity'] = showEthnicity;
//     data['children_type'] = childrenType;
//     data['show_children_type'] = showChildrenType;
//     data['steps'] = steps;
//     data['fcm_token'] = fcmToken;
//     data['remember_token'] = rememberToken;
//     data['is_notify'] = isNotify;
//     data['device_type'] = deviceType;
//     data['type_id'] = typeId;
//     data['state_id'] = stateId;
//     data['created_at'] = createdAt;
//     data['updated_at'] = updatedAt;
//     data['gender_rel'] = genderRel;
//     if (interests != null) {
//       data['interests'] = interests;
//     }
//     if (userImages != null) {
//       data['user_images'] = userImages;
//     }
//     return data;
//   }
// }
class UserModal {
  var status;
  var message;
  var data;

  UserModal({this.status, this.message, this.data});

  UserModal.fromJson(Map<String, dynamic> json) {
    status = json['status'];
    message = json['message'];
    data = json['data'] != null ? new Data.fromJson(json['data']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['status'] = this.status;
    data['message'] = this.message;
    if (this.data != null) {
      data['data'] = this.data!.toJson();
    }
    return data;
  }
}

class Data {
  var id;
  var name;
  var email;
  var emailVerifyToken;
  var emailVerifiedAt;
  var isoCode;
  var phoneCode;
  var phone;
  var phoneVerifiedAt;
  var dob;
  var age;
  var address;
  var latitude;
  var longitude;
  var about;
  var preferedDistance;
  var minAge;
  var maxAge;
  var enableDiscovery;
  var isChat;
  var matchId;
  var activeStatus;
  var roleId;
  var steps;
  var gender;
  var showGender;
  var interestedIn;
  var showInterestedIn;
  var relationStatus;
  var showRelationStatus;
  var lookingFor;
  var showLookingFor;
  var ethnicity;
  var showEthnicity;
  var childrenType;
  var showChildrenType;
  var fcmToken;
  var rememberToken;
  var isNotify;
  var deviceType;
  var typeId;
  var stateId;
  var createdAt;
  var updatedAt;
  var genderRel;
  List<Interests>? interests;
  List<UserImages>? userImages;

  Data(
      {this.id,
        this.name,
        this.email,
        this.emailVerifyToken,
        this.emailVerifiedAt,
        this.isoCode,
        this.phoneCode,
        this.phone,
        this.phoneVerifiedAt,
        this.dob,
        this.age,
        this.address,
        this.steps,
        this.latitude,
        this.longitude,
        this.about,
        this.preferedDistance,
        this.minAge,
        this.maxAge,
        this.enableDiscovery,
        this.isChat,
        this.matchId,
        this.activeStatus,
        this.roleId,
        this.gender,
        this.showGender,
        this.interestedIn,
        this.showInterestedIn,
        this.relationStatus,
        this.showRelationStatus,
        this.lookingFor,
        this.showLookingFor,
        this.ethnicity,
        this.showEthnicity,
        this.childrenType,
        this.showChildrenType,
        this.fcmToken,
        this.rememberToken,
        this.isNotify,
        this.deviceType,
        this.typeId,
        this.stateId,
        this.createdAt,
        this.updatedAt,
        this.genderRel,
        this.interests,
        this.userImages});

  Data.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    name = json['name'];
    email = json['email'];
    steps = json['steps'];
    emailVerifyToken = json['email_verify_token'];
    emailVerifiedAt = json['email_verified_at'];
    isoCode = json['iso_code'];
    phoneCode = json['phone_code'];
    phone = json['phone'];
    phoneVerifiedAt = json['phone_verified_at'];
    dob = json['dob'];
    age = json['age'];
    address = json['address'];
    latitude = json['latitude'];
    longitude = json['longitude'];
    about = json['about'];
    preferedDistance = json['prefered_distance'];
    minAge = json['min_age'];
    maxAge = json['max_age'];
    enableDiscovery = json['enable_discovery'];
    isChat = json['isChat'];
    matchId = json['match_id'];
    activeStatus = json['active_status'];
    roleId = json['role_id'];
    gender = json['gender'];
    showGender = json['show_gender'];
    interestedIn = json['interested_in'] != null
        ? new InterestedIn.fromJson(json['interested_in'])
        : null;
    showInterestedIn = json['show_interested_in'];
    relationStatus = json['relation_status'] != null
        ? new RelationStatus.fromJson(json['relation_status'])
        : null;
    showRelationStatus = json['show_relation_status'];
    lookingFor = json['looking_for'] != null
        ? new RelationStatus.fromJson(json['looking_for'])
        : null;
    showLookingFor = json['show_looking_for'];
    ethnicity = json['ethnicity'];
    showEthnicity = json['show_ethnicity'];
    childrenType = json['children_type'];
    showChildrenType = json['show_children_type'];
    steps = json['steps'];
    fcmToken = json['fcm_token'];
    rememberToken = json['remember_token'];
    isNotify = json['is_notify'];
    deviceType = json['device_type'];
    typeId = json['type_id'];
    stateId = json['state_id'];
    createdAt = json['created_at'];
    updatedAt = json['updated_at'];
    genderRel = json['gender_rel'] != null
        ? new InterestedIn.fromJson(json['gender_rel'])
        : null;
    if (json['interests'] != null) {
      interests = <Interests>[];
      json['interests'].forEach((v) {
        interests!.add(new Interests.fromJson(v));
      });
    }
    if (json['user_images'] != null) {
      userImages = <UserImages>[];
      json['user_images'].forEach((v) {
        userImages!.add(new UserImages.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['name'] = this.name;
    data['email'] = this.email;
    data['email_verify_token'] = this.emailVerifyToken;
    data['email_verified_at'] = this.emailVerifiedAt;
    data['iso_code'] = this.isoCode;
    data['phone_code'] = this.phoneCode;
    data['phone'] = this.phone;
    data['phone_verified_at'] = this.phoneVerifiedAt;
    data['dob'] = this.dob;
    data['age'] = this.age;
    data['address'] = this.address;
    data['latitude'] = this.latitude;
    data['longitude'] = this.longitude;
    data['about'] = this.about;
    data['prefered_distance'] = this.preferedDistance;
    data['min_age'] = this.minAge;
    data['steps'] = this.steps;

    data['max_age'] = this.maxAge;
    data['enable_discovery'] = this.enableDiscovery;
    data['isChat'] = this.isChat;
    data['match_id'] = this.matchId;
    data['active_status'] = this.activeStatus;
    data['role_id'] = this.roleId;
    data['gender'] = this.gender;
    data['show_gender'] = this.showGender;
    if (this.interestedIn != null) {
      data['interested_in'] = this.interestedIn!.toJson();
    }
    data['show_interested_in'] = this.showInterestedIn;
    if (this.relationStatus != null) {
      data['relation_status'] = this.relationStatus!.toJson();
    }
    data['show_relation_status'] = this.showRelationStatus;
    if (this.lookingFor != null) {
      data['looking_for'] = this.lookingFor!.toJson();
    }
    data['show_looking_for'] = this.showLookingFor;
    data['ethnicity'] = this.ethnicity;
    data['show_ethnicity'] = this.showEthnicity;
    data['children_type'] = this.childrenType;
    data['show_children_type'] = this.showChildrenType;
    data['steps'] = this.steps;
    data['fcm_token'] = this.fcmToken;
    data['remember_token'] = this.rememberToken;
    data['is_notify'] = this.isNotify;
    data['device_type'] = this.deviceType;
    data['type_id'] = this.typeId;
    data['state_id'] = this.stateId;
    data['created_at'] = this.createdAt;
    data['updated_at'] = this.updatedAt;
    if (this.genderRel != null) {
      data['gender_rel'] = this.genderRel!.toJson();
    }
    if (this.interests != null) {
      data['interests'] = this.interests!.map((v) => v.toJson()).toList();
    }
    if (this.userImages != null) {
      data['user_images'] = this.userImages!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class InterestedIn {
  int? id;
  String? title;
  String? image;
  String? typeId;
  int? stateId;
  String? createdAt;
  String? updatedAt;
  int? createdBy;

  InterestedIn(
      {this.id,
        this.title,
        this.image,
        this.typeId,
        this.stateId,
        this.createdAt,
        this.updatedAt,
        this.createdBy});

  InterestedIn.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    title = json['title'];
    image = json['image'];
    typeId = json['type_id'];
    stateId = json['state_id'];
    createdAt = json['created_at'];
    updatedAt = json['updated_at'];
    createdBy = json['created_by'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['title'] = this.title;
    data['image'] = this.image;
    data['type_id'] = this.typeId;
    data['state_id'] = this.stateId;
    data['created_at'] = this.createdAt;
    data['updated_at'] = this.updatedAt;
    data['created_by'] = this.createdBy;
    return data;
  }
}

class RelationStatus {
  int? id;
  String? title;
  String? typeId;
  int? stateId;
  String? createdAt;
  String? updatedAt;
  int? createdBy;

  RelationStatus(
      {this.id,
        this.title,
        this.typeId,
        this.stateId,
        this.createdAt,
        this.updatedAt,
        this.createdBy});

  RelationStatus.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    title = json['title'];
    typeId = json['type_id'];
    stateId = json['state_id'];
    createdAt = json['created_at'];
    updatedAt = json['updated_at'];
    createdBy = json['created_by'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['title'] = this.title;
    data['type_id'] = this.typeId;
    data['state_id'] = this.stateId;
    data['created_at'] = this.createdAt;
    data['updated_at'] = this.updatedAt;
    data['created_by'] = this.createdBy;
    return data;
  }
}

class Interests {
  int? id;
  String? title;
  String? image;
  String? typeId;
  int? stateId;
  String? createdAt;
  String? updatedAt;
  int? createdBy;
  int? laravelThroughKey;

  Interests(
      {this.id,
        this.title,
        this.image,
        this.typeId,
        this.stateId,
        this.createdAt,
        this.updatedAt,
        this.createdBy,
        this.laravelThroughKey});

  Interests.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    title = json['title'];
    image = json['image'];
    typeId = json['type_id'];
    stateId = json['state_id'];
    createdAt = json['created_at'];
    updatedAt = json['updated_at'];
    createdBy = json['created_by'];
    laravelThroughKey = json['laravel_through_key'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['title'] = this.title;
    data['image'] = this.image;
    data['type_id'] = this.typeId;
    data['state_id'] = this.stateId;
    data['created_at'] = this.createdAt;
    data['updated_at'] = this.updatedAt;
    data['created_by'] = this.createdBy;
    data['laravel_through_key'] = this.laravelThroughKey;
    return data;
  }
}

class UserImages {
  var id;
  var image;
  var imageIndex;
  // var typeId;
  // var stateId;
  // var createdAt;
  // var updatedAt;
  // var createdBy;
  // var laravelThroughKey;

  UserImages(
      {this.id,
        this.image,
        this.imageIndex,
        // this.stateId,
        // this.createdAt,
        // this.updatedAt,
        // this.createdBy,
        // this.laravelThroughKey
      });

  UserImages.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    imageIndex = json['image_index'];
    image = json['image'];
    // typeId = json['type_id'];
    // stateId = json['state_id'];
    // createdAt = json['created_at'];
    // updatedAt = json['updated_at'];
    // createdBy = json['created_by'];
    // laravelThroughKey = json['laravel_through_key'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['image_index'] = this.imageIndex;
    data['image'] = this.image;
    // data['type_id'] = this.typeId;
    // data['state_id'] = this.stateId;
    // data['created_at'] = this.createdAt;
    // data['updated_at'] = this.updatedAt;
    // data['created_by'] = this.createdBy;
    // data['laravel_through_key'] = this.laravelThroughKey;
    return data;
  }
}