import 'package:dotted_border/dotted_border.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import 'package:milan/detail_birthdate_page.dart';
import 'package:milan/detail_gender_page.dart';
import 'package:milan/detail_relationship_page.dart';
import 'package:roundcheckbox/roundcheckbox.dart';

class YourProfile extends StatefulWidget {
  const YourProfile({super.key});

  @override
  State<YourProfile> createState() => _ProfileDetailState();
}
List<PersonDetail> infoList = [];
class _ProfileDetailState extends State<YourProfile> {
  InfoList() {
    infoList.clear();
    infoList.add(PersonDetail(
        age: 25,
        number: "+1 69785 24693",
        status: "Single",
        gender: "Female",
        location: "Florida",
        lastName: "Alice",
        firstName: "Aliza",
        description:
        "My name is Elizabeth. you can call me. I’m 25 years old nd live in Florida. Want to get acquainted with me? Foodie by day, adventurer by night. Looking for someone to keep up!",
        dob: "20 November 1996",
        interests: ["Music", "Dance","Coffee","Badminton"],
        looking: "Situational Friends"));
    setState(() {});
  }

  @override
  void initState() {
    // TODO: implement initState
    InfoList();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return ScreenUtilInit(
      designSize: const Size(430, 942),
      minTextAdapt: true,
      splitScreenMode: true,
      child: SafeArea(
          child: Scaffold(
              body: SingleChildScrollView(
                child: Stack(
                  children: [
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          height: 450.h,
                          width: 500.w,
                          decoration: BoxDecoration(
                              image: const DecorationImage(
                                  image: AssetImage("assets/images/your.png"),
                                  fit: BoxFit.fill),
                              shape: BoxShape.rectangle),
                        ),
                        ListView.builder(
                            itemCount: infoList.length,
                            shrinkWrap: true,
                            physics: NeverScrollableScrollPhysics(),
                            itemBuilder: (context, index) {
                              return Padding(
                                padding: EdgeInsets.only(left: 18.w, right: 18.w),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    SizedBox(height: 35.h,),
                                    Row(
                                      children: [
                                        Text(
                                          "${infoList[index].firstName}\n${infoList[index].lastName}, ${infoList[index].age}",
                                          overflow: TextOverflow.ellipsis,
                                          style: GoogleFonts.gabarito(
                                            fontSize: 40,
                                            height: 1,
                                            fontWeight: FontWeight.w600,
                                          ),
                                          maxLines: 2,
                                        ),
                                        SizedBox(width: 80.w,),
                                        GestureDetector(
                                          onTap: (){
                                            Navigator.push(
                                              context,
                                              MaterialPageRoute(builder: (context) => EditProfile()),
                                            );
                                          },
                                          child: Container(
                                            height:50.h,
                                            padding: EdgeInsets.all(10),
                                            decoration: BoxDecoration(
                                              color: Colors.black,
                                              shape: BoxShape.rectangle,
                                              borderRadius: BorderRadius.circular(30.r),

                                            ),
                                            child: Center(
                                              child: Text(
                                                "Edit Profile",
                                                style: GoogleFonts.gabarito(
                                                    fontSize: 18.sp, fontWeight: FontWeight.w500,color:Colors.white),
                                              ),
                                            ),
                                          ),
                                        )
                                      ],
                                    ),
                                    SizedBox(height: 15.h,),
                                    Row(
                                      crossAxisAlignment: CrossAxisAlignment.center,
                                      children: [
                                        const Icon(
                                          Icons.location_on_outlined,
                                          size: 25,
                                        ),
                                        Text(
                                          infoList[index].location,
                                          overflow: TextOverflow.ellipsis,
                                          style: GoogleFonts.gabarito(
                                            fontSize: 20,
                                            fontWeight: FontWeight.w600,
                                          ),
                                          maxLines: 1,
                                        ),
                                      ],
                                    ),
                                    SizedBox(height: 15.h,),
                                    Text(
                                      "Description",
                                      overflow: TextOverflow.ellipsis,
                                      style: GoogleFonts.gabarito(
                                        fontSize: 18.sp,
                                        fontWeight: FontWeight.w600,
                                      ),
                                      maxLines: 1,
                                    ),
                                    SizedBox(height: 10.h,),
                                    Text(
                                      infoList[index].description,
                                      overflow: TextOverflow.ellipsis,
                                      style: GoogleFonts.gabarito(
                                        fontSize: 16.sp,
                                        fontWeight: FontWeight.w400,

                                      ),
                                      maxLines: 5,textAlign: TextAlign.start,
                                    ),
                                    SizedBox(height: 15.h,),
                                    Text(
                                      "Interests",
                                      overflow: TextOverflow.ellipsis,
                                      style: GoogleFonts.gabarito(
                                        fontSize: 18.sp,
                                        fontWeight: FontWeight.w600,
                                      ),
                                      maxLines: 1,
                                    ),
                                    SizedBox(height: 15.h,),
                                    SizedBox(
                                      height:100.h,
                                      child: GridView.builder(
                                        physics: NeverScrollableScrollPhysics(),
                                        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                                          crossAxisCount: 3, // 2 columns in the grid
                                          crossAxisSpacing: 8.0,
                                          mainAxisSpacing: 8.0,
                                          childAspectRatio: 3,
                                        ),
                                        itemCount: infoList[index].interests.length,
                                        itemBuilder: (context, Index) {
                                          return Container(
                                            decoration: BoxDecoration(
                                              borderRadius: BorderRadius.circular(15.0),
                                              color: Colors.black.withOpacity(0.035),

                                            ),
                                            alignment: Alignment.center,
                                            child: Text(
                                              infoList[index].interests[Index],
                                              style: TextStyle(fontSize: 16.sp),
                                              textAlign: TextAlign.center,
                                            ),
                                          );
                                        },
                                      ),
                                    ),
                                    SizedBox(height: 5.h,),
                                    Text(
                                      "Information",
                                      overflow: TextOverflow.ellipsis,
                                      style: GoogleFonts.gabarito(
                                        fontSize: 18.sp,
                                        fontWeight: FontWeight.w600,
                                      ),
                                      maxLines: 1,
                                    ),
                                    SizedBox(height: 15.h,),
                                    Container(
                                      padding: EdgeInsets.all(20),
                                      decoration: BoxDecoration(
                                        borderRadius: BorderRadius.circular(15.0),
                                        color: Colors.black.withOpacity(0.035),

                                      ),
                                      child: Column(
                                        children: [
                                          Row(
                                            children: [
                                              Text(
                                                "Gender",
                                                overflow: TextOverflow.ellipsis,
                                                style: GoogleFonts.gabarito(
                                                  fontSize: 16.sp,
                                                  fontWeight: FontWeight.w400,
                                                ),
                                                maxLines: 1,
                                              ),
                                              Spacer(),
                                              Text(
                                                infoList[index].gender,
                                                overflow: TextOverflow.ellipsis,
                                                style: GoogleFonts.gabarito(
                                                  fontSize: 16.sp,
                                                  fontWeight: FontWeight.w400,
                                                ),
                                                maxLines: 1,
                                              ),
                                            ],
                                          ),
                                          SizedBox(height: 10.h,),
                                          Row(
                                            children: [
                                              Text(
                                                "Looking for",
                                                overflow: TextOverflow.ellipsis,
                                                style: GoogleFonts.gabarito(
                                                  fontSize: 16.sp,
                                                  fontWeight: FontWeight.w400,
                                                ),
                                                maxLines: 1,
                                              ),
                                              Spacer(),
                                              Text(
                                                infoList[index].looking,
                                                overflow: TextOverflow.ellipsis,
                                                style: GoogleFonts.gabarito(
                                                  fontSize: 16.sp,
                                                  fontWeight: FontWeight.w400,
                                                ),
                                                maxLines: 1,
                                              ),
                                            ],
                                          ),
                                          SizedBox(height: 10.h,),
                                          Row(
                                            children: [
                                              Text(
                                                "Relationship Status",
                                                overflow: TextOverflow.ellipsis,
                                                style: GoogleFonts.gabarito(
                                                  fontSize: 16.sp,
                                                  fontWeight: FontWeight.w400,
                                                ),
                                                maxLines: 1,
                                              ),
                                              Spacer(),
                                              Text(
                                                infoList[index].status,
                                                overflow: TextOverflow.ellipsis,
                                                style: GoogleFonts.gabarito(
                                                  fontSize: 16.sp,
                                                  fontWeight: FontWeight.w400,
                                                ),
                                                maxLines: 1,
                                              ),
                                            ],
                                          ),
                                          SizedBox(height: 10.h,),
                                          Row(
                                            children: [
                                              Text(
                                                "Date of Birth",
                                                overflow: TextOverflow.ellipsis,
                                                style: GoogleFonts.gabarito(
                                                  fontSize: 16.sp,
                                                  fontWeight: FontWeight.w400,
                                                ),
                                                maxLines: 1,
                                              ),
                                              Spacer(),
                                              Text(
                                                infoList[index].dob,
                                                overflow: TextOverflow.ellipsis,
                                                style: GoogleFonts.gabarito(
                                                  fontSize: 16.sp,
                                                  fontWeight: FontWeight.w400,
                                                ),
                                                maxLines: 1,
                                              ),
                                            ],
                                          )
                                        ],
                                      ),
                                    )
                                  ],
                                ),
                              );
                            }),
                        SizedBox(height: 15.h,),
                      ],
                    ),
                    Positioned(
                      top: 420.h,
                      left: 120.w,
                      right: 250.w,
                      child: Container(
                        height: 60.h,
                        width: 60.w,
                        alignment: Alignment.center,
                        decoration: BoxDecoration(
                            color: Colors.white,
                            shape: BoxShape.circle,
                            boxShadow: [
                              BoxShadow(
                                  blurRadius: 40,
                                  spreadRadius: 60,
                                  color: Colors.black.withOpacity(0.025))
                            ]),
                        child: IconButton(
                          icon: Icon(
                            Icons.replay,
                            color: Colors.red,
                            size: 30,
                          ),
                          onPressed: () {},
                        ),
                      ),
                    ),
                    Positioned(
                      top: 420.h,
                      left: 260.w,
                      right: 110.w,
                      child: Container(
                        height: 60.h,
                        width: 60.w,
                        alignment: Alignment.center,
                        decoration: BoxDecoration(
                            color: Colors.white,
                            shape: BoxShape.circle,
                            boxShadow: [
                              BoxShadow(
                                  blurRadius: 40,
                                  spreadRadius: 60,
                                  color: Colors.black.withOpacity(0.025))
                            ]),
                        child: IconButton(
                          icon: Icon(
                            Icons.message_outlined,
                            color: Colors.orangeAccent,
                            size: 30,
                          ),
                          onPressed: () {},
                        ),
                      ),
                    ),
                    Positioned(
                      top: 420.h,
                      left: 190.w,
                      child: Container(
                        height: 60.h,
                        width: 60.w,
                        alignment: Alignment.center,
                        decoration:
                        BoxDecoration(color: Colors.pinkAccent, shape: BoxShape.circle),
                        child: IconButton(
                          icon: Icon(
                            Icons.add,
                            color: Colors.white,
                            size: 30,
                          ),
                          onPressed: () {},
                        ),
                      ),
                    ),
                    Positioned(
                      top: 40.h,
                      left: 20.w,
                      right: 340.w,
                      child: Container(
                        height: 60.h,
                        width: 60.w,
                        alignment: Alignment.center,
                        decoration: BoxDecoration(
                            color: Colors.white12,
                            shape: BoxShape.circle,
                            boxShadow: [
                              BoxShadow(
                                  blurRadius: 40,
                                  spreadRadius: 60,
                                  color: Colors.black.withOpacity(0.025))
                            ]
                        ),
                        child: IconButton(
                          icon: Icon(
                            Icons.arrow_back,
                            color: Colors.white,
                            size: 30,
                          ),
                          onPressed: () {
                            Navigator.pop(context);
                          },
                        ),
                      ),
                    ),
                    Positioned(
                      left: 340.w,
                      top: 40.h,
                      right: 20.w,
                      child: Container(
                        height: 60.h,
                        width: 60.w,
                        alignment: Alignment.center,
                        decoration: BoxDecoration(
                            color: Colors.white12,
                            shape: BoxShape.circle,
                            boxShadow: [
                              BoxShadow(
                                  blurRadius: 40,
                                  spreadRadius: 60,
                                  color: Colors.black.withOpacity(0.025))
                            ]),
                        child: IconButton(
                          icon: Icon(
                            Icons.mobile_screen_share,
                            color: Colors.white,
                            size: 30,
                          ),
                          onPressed: () {},
                        ),
                      ),
                    ),
                  ],
                ),
              ))),
    );
  }
}

class PersonDetail {
  String firstName;
  String lastName;
  int age;
  String description;
  String gender;
  String looking;
  String status;
  String dob;
  String location;
  List<String> interests;
  String number;

  PersonDetail(
      {required this.age,
        required this.status,
        required this.gender,
        required this.lastName,
        required this.firstName,
        required this.description,
        required this.dob,
        required this.interests,
        required this.looking,
        required this.location,required this.number});
}
class EditProfile extends StatefulWidget {
  const EditProfile({super.key});

  @override
  State<EditProfile> createState() => _EditProfileState();
}

class _EditProfileState extends State<EditProfile> {
  @override
  Widget build(BuildContext context) {
    return ScreenUtilInit(
      designSize: const Size(430, 942),
      minTextAdapt: true,
      splitScreenMode: true,
      child: SafeArea(
        child: Scaffold(
          body: Padding(
            padding: EdgeInsets.only(left: 18.w, top: 50.h,),
            child: SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      GestureDetector(
                        onTap: () {
                          Navigator.pop(context);
                        },
                        child: Container(
              
                          height: 60.h,
                          width: 60.w,
                          decoration: BoxDecoration(
              
                            shape: BoxShape.circle,
                            color: Colors.black.withOpacity(0.025),
                          ),
                          child: const Center(child: Icon(Icons.arrow_back)),
                        ),
                      ),
                      SizedBox(width: 20.w,),
                      Text(
                        "Edit Profile",
                        style: GoogleFonts.gabarito(
                            fontSize: 20.sp, fontWeight: FontWeight.w600),
                      ),
                    ],
                  ),
                  SizedBox(height: 10.h,),
                  Text(
                    "Add Photo",
                    style: GoogleFonts.gabarito(
                        fontSize: 16.sp, fontWeight: FontWeight.w400),
                  ),
                  GridView.builder(
                    shrinkWrap: true,
                    physics: NeverScrollableScrollPhysics(),
                    gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 2, // number of items in each row
                      mainAxisSpacing: 8.0, // spacing between rows
                      crossAxisSpacing: 8.0,
                      childAspectRatio: 0.9
                      // spacing between columns
                    ),
                    padding: EdgeInsets.only(right: 18.w,top: 18.h),
                    // padding around the grid
                    itemCount: 4,
                    // total number of items
                    itemBuilder: (context, index) {
                      return index==0?Stack(
                        children: [
                          Container(
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(15.r),
                                color: Colors.blue.withOpacity(0.085),
                                image: DecorationImage(
                                    image: AssetImage("assets/images/Rectangle 156.png"),
                                    fit: BoxFit.fill
                                )
                            ),
                          ),
                          Positioned(
                              top: 180.h,
                              left: 140.w,
                              child: Container(
                                height: 25.h,
                                width: 25.w,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  color: Colors.black,
                                ),
                                child: Center(
                                  child: Icon(Icons.edit,color: Colors.white,size: 15,),
                                ),
                              ),),
                          Positioned(
                            left: 140.w,
                            top: 10.h,
                            child: Container(
                              height: 25.h,
                              width: 25.w,
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                color: Colors.black,
                              ),
                              child: Center(
                                child: Icon(Icons.delete_outline_rounded,color: Colors.white,size: 15,),
                              ),
                            ),),
                        ],

                      ):DottedBorder(
                        borderType: BorderType.RRect,
                        radius: Radius.circular(15),
                        strokeWidth: 2,
                        color: Colors.grey.withOpacity(0.155),
                        child: Center(
                          child: Container(
                              margin: EdgeInsets.all(10),
                              width: 40.w,
                              height: 40.h,
                              decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  color: Colors.black.withOpacity(0.025)
                              ),
                              child: Icon(Icons.add,)
                          ),
                        ),
                      );
                    },
                  ),
                  SizedBox(height: 10.h,),
                  ListView.builder(
                      itemCount: infoList.length,
                      shrinkWrap: true,
                      physics: NeverScrollableScrollPhysics(),
                      itemBuilder: (context, index) {
                        return Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              "Name",
                              style: GoogleFonts.gabarito(
                                  fontSize: 18.sp, fontWeight: FontWeight.w600),
                            ),
                            SizedBox(height: 5.h,),
                        Container(
                          margin: EdgeInsets.only(right: 18.w),
                          decoration: BoxDecoration(
                              color: Colors.white,
                              boxShadow: [
                                BoxShadow(
                                    blurRadius: 1,
                                    offset: Offset(0,1),
                                    color: Colors.black12
                                )
                              ],
                              borderRadius: BorderRadius.circular(10)
                          ),
                          child: TextFormField(
                            textInputAction: TextInputAction.done,
                            keyboardType: TextInputType.text,
                            decoration:  InputDecoration(
                              fillColor: Colors.black.withOpacity(0.025),
                              contentPadding: const EdgeInsets.only(left: 20,right: 10,top: 10,bottom: 10),
                              border: InputBorder.none,
                              hintText: infoList[index].firstName,
                              hintStyle: const TextStyle(
                                  color: Colors.black,
                                  overflow: TextOverflow.ellipsis),
                            ),
                            maxLines: 1,
                          ),
                        ),
                            SizedBox(height: 10.h,),
                            Text(
                              "Phone",
                              style: GoogleFonts.gabarito(
                                  fontSize: 18.sp, fontWeight: FontWeight.w600),
                            ),
                            SizedBox(height: 5.h,),
                        Container(
                          margin: EdgeInsets.only(right: 18.w),
                          decoration: BoxDecoration(
                              color: Colors.white,
                              boxShadow: [
                                BoxShadow(
                                    blurRadius: 1,
                                    offset: Offset(0,1),
                                    color: Colors.black12
                                )
                              ],
                              borderRadius: BorderRadius.circular(10)
                          ),
                          child: TextFormField(
                            textInputAction: TextInputAction.done,
                            keyboardType: TextInputType.text,
                            decoration:  InputDecoration(
                              fillColor: Colors.black.withOpacity(0.025),
                              contentPadding: const EdgeInsets.only(left: 20,right: 10,top: 10,bottom: 10),
                              border: InputBorder.none,
                              hintText: infoList[index].number,
                              hintStyle: const TextStyle(
                                  color: Colors.black,
                                  overflow: TextOverflow.ellipsis),
                            ),
                            maxLines: 1,
                          ),
                        ),
                            SizedBox(height: 10.h,),
                            Row(
                              children: [
                                Text(
                                  "Interests",
                                  overflow: TextOverflow.ellipsis,
                                  style: GoogleFonts.gabarito(
                                    fontSize: 18.sp,
                                    fontWeight: FontWeight.w600,
                                  ),
                                  maxLines: 1,
                                ),
                                Spacer(),
                                GestureDetector(
                                  onTap: (){
                                    Navigator
                                        .of(context)
                                        .push(new MaterialPageRoute(builder: (BuildContext context) {
                                      return new EditInterest();
                                    }));
                                  },
                                  child: Container(
                                    height: 35.h,
                                    width: 35.w,
                                    margin: EdgeInsets.only(right: 18.w),
                                    decoration: BoxDecoration(
                                      shape: BoxShape.circle,
                                      color: Colors.black,
                                    ),
                                    child: Center(
                                      child: Icon(Icons.edit,color: Colors.white,size: 15,),
                                    ),
                                  ),
                                )
                              ],
                            ),
                            SizedBox(height: 5.h,),
                            SizedBox(
                              height:100.h,
                              child: GridView.builder(
                                physics: NeverScrollableScrollPhysics(),
                                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                                  crossAxisCount: 3, // 2 columns in the grid
                                  crossAxisSpacing: 8.0,
                                  mainAxisSpacing: 8.0,
                                  childAspectRatio: 3,
                                ),
                                itemCount: infoList[index].interests.length,
                                itemBuilder: (context, Index) {
                                  return Container(
                                    decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(15.0),
                                      color: Colors.black.withOpacity(0.035),
              
                                    ),
                                    alignment: Alignment.center,
                                    child: Text(
                                      infoList[index].interests[Index],
                                      style: TextStyle(fontSize: 16.sp),
                                      textAlign: TextAlign.center,
                                    ),
                                  );
                                },
                              ),
                            ),
                            Text(
                              "Gender",
                              style: GoogleFonts.gabarito(
                                  fontSize: 16.sp, fontWeight: FontWeight.w400),
                            ),
                            SizedBox(height: 5.h,),
                            InkWell(
                              onTap: (){
                                Navigator
                                    .of(context)
                                    .push(new MaterialPageRoute(builder: (BuildContext context) {
                                  return new GenderPageSelect();
                                }));
                              },
                              child: Container(
                                height:50.h,
                                margin: EdgeInsets.only(right: 18.w),
                                padding: EdgeInsets.only(left: 10.w,right: 10.w),
                                decoration: BoxDecoration(
                                    color: Colors.white,
                                    boxShadow: [
                                      BoxShadow(
                                          blurRadius: 1,
                                          offset: Offset(0,1),
                                          color: Colors.black12
                                      )
                                    ],
                                    borderRadius: BorderRadius.circular(10)
                                ),
                                child:
                                Row(children: [
                                  Text(infoList[index].gender,
                                      style:TextStyle(
                                          color: Colors.black,
                                          overflow: TextOverflow.ellipsis),),
                                  Spacer(),
                                  Icon(Icons.arrow_forward_ios_rounded,size: 14,)
                                ],
                        ),
                              ),
                            ),
                            SizedBox(height: 5.h,),
                            Text(
                              "I’m Looking for",
                              style: GoogleFonts.gabarito(
                                  fontSize: 16.sp, fontWeight: FontWeight.w400),
                            ),
                            SizedBox(height: 5.h,),
                            InkWell(
                              onTap: (){
                                Navigator
                                    .of(context)
                                    .push(new MaterialPageRoute(builder: (BuildContext context) {
                                  return new LookingPageSelect();
                                }));
                              },
                              child: Container(
                                height:50.h,
                                margin: EdgeInsets.only(right: 18.w),
                                padding: EdgeInsets.only(left: 10.w,right: 10.w),
                                decoration: BoxDecoration(
                                    color: Colors.white,
                                    boxShadow: [
                                      BoxShadow(
                                          blurRadius: 1,
                                          offset: Offset(0,1),
                                          color: Colors.black12
                                      )
                                    ],
                                    borderRadius: BorderRadius.circular(10)
                                ),
                                child:
                                Row(children: [
                                  Text(infoList[index].looking,
                                    style:TextStyle(
                                        color: Colors.black,
                                        overflow: TextOverflow.ellipsis),),
                                  Spacer(),
                                  Icon(Icons.arrow_forward_ios_rounded,size: 14,)
                                ],
                                ),
                              ),
                            ),
                            SizedBox(height: 5.h,),
                            Text(
                              "Date of Birth",
                              style: GoogleFonts.gabarito(
                                  fontSize: 16.sp, fontWeight: FontWeight.w400),
                            ),
                            SizedBox(height: 5.h,),
                            InkWell(
                              onTap: (){
                                Navigator
                                    .of(context)
                                    .push(new MaterialPageRoute(builder: (BuildContext context) {
                                  return new BirthDateSelect();
                                }));
                              },
                              child: Container(
                                height:50.h,
                                margin: EdgeInsets.only(right: 18.w),
                                padding: EdgeInsets.only(left: 10.w,right: 10.w),
                                decoration: BoxDecoration(
                                    color: Colors.white,
                                    boxShadow: [
                                      BoxShadow(
                                          blurRadius: 1,
                                          offset: Offset(0,1),
                                          color: Colors.black12
                                      )
                                    ],
                                    borderRadius: BorderRadius.circular(10)
                                ),
                                child:
                                Row(children: [
                                  Text(infoList[index].dob,
                                    style:TextStyle(
                                        color: Colors.black,
                                        overflow: TextOverflow.ellipsis),),
                                  Spacer(),
                                  Icon(Icons.arrow_forward_ios_rounded,size: 14,)
                                ],
                                ),
                              ),
                            ),
                          ],
                        );
                      }),
                  SizedBox(height: 10.h,),
                  _submitBoxButton,
                  SizedBox(height: 10.h,),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class EditInterest extends StatefulWidget {
  const EditInterest({super.key});

  @override
  State<EditInterest> createState() => _EditInterestState();
}

class _EditInterestState extends State<EditInterest> {
  List<SelectInterest> listItems = [];
  selectInterest(){
    listItems.clear();
    listItems.add(SelectInterest(icon: Icons.games_rounded, name: 'Gaming'));
    listItems.add(SelectInterest(icon: Icons.science_rounded, name: 'Science'));
    listItems.add(SelectInterest(icon: Icons.music_note_rounded, name: 'Music'));
    listItems.add(SelectInterest(icon: Icons.airplay_rounded, name: 'Technology'));
    listItems.add(SelectInterest(icon: Icons.language_rounded, name: 'Language'));
    listItems.add(SelectInterest(icon: Icons.airplanemode_active_rounded, name: 'Travel'));
    listItems.add(SelectInterest(icon: Icons.sports_cricket_rounded, name: 'Sports'));
    listItems.add(SelectInterest(icon: Icons.self_improvement_outlined, name: 'Meditation'));
    listItems.add(SelectInterest(icon: Icons.sports_gymnastics_rounded, name: 'Gym'));
    listItems.add(SelectInterest(icon: Icons.electric_car_sharp, name: 'Cars'));
    listItems.add(SelectInterest(icon: Icons.menu_book, name: 'Book'));
    listItems.add(SelectInterest(icon: Icons.business, name: 'Business'));
    listItems.add(SelectInterest(icon: Icons.fastfood_rounded, name: 'Food'));


    setState(() {

    });

  }
  @override
  void initState() {
    // TODO: implement initState
    selectInterest();
    super.initState();
  }
  Set<String> selectedInterests = {};
  @override
  Widget build(BuildContext context) {
    return ScreenUtilInit(
      child: SafeArea(
        child: Scaffold(
          body: Padding(
            padding: EdgeInsets.only(left: 18.w, top: 50.h,),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    GestureDetector(
                      onTap: () {
                        Navigator.pop(context);
                      },
                      child: Container(

                        height: 60.h,
                        width: 60.w,
                        decoration: BoxDecoration(

                          shape: BoxShape.circle,
                          color: Colors.black.withOpacity(0.025),
                        ),
                        child: const Center(child: Icon(Icons.arrow_back)),
                      ),
                    ),
                    SizedBox(width: 20.w,),
                    Text(
                      "Interests",
                      style: GoogleFonts.gabarito(
                          fontSize: 20.sp, fontWeight: FontWeight.w600),
                    ),
                  ],
                ),
                SizedBox(height: 10.h,),
                Text(
                  "Millions of interests, endless friendships.",
                  style: GoogleFonts.gabarito(
                      fontSize: 16.sp, fontWeight: FontWeight.w500),
                ),
                SizedBox(height: 10.h,),
                Expanded(
                  child: Container(
                    margin: EdgeInsets.only(right: 18.w),

                    // height: 30.h,
                    // width: 300.w,
                    child: GridView.builder(
                      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                          crossAxisCount: 3, // 2 columns in the grid
                          crossAxisSpacing: 10.0,
                          mainAxisSpacing: 10.0,
                          childAspectRatio: 2.2
                      ),
                      itemCount: listItems.length,
                      physics: NeverScrollableScrollPhysics(),
                      itemBuilder: (context, index) {
                        return GestureDetector(
                          onTap: () {
                            setState(() {
                              if (selectedInterests.contains(listItems[index].name)) {
                                selectedInterests.remove(listItems[index].name);
                              } else {
                                selectedInterests.add(listItems[index].name);
                              }
                            });
                          },
                          child: Container(
                            padding: EdgeInsets.all(5),
                            decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(15.0),
                                color: selectedInterests.contains(listItems[index].name)
                                    ? Colors.white
                                    : Colors.black.withOpacity(0.035),
                                border: selectedInterests.contains(listItems[index].name)?Border.all(width: 1.5,color: Colors.blue)
                                    : Border.all(color: Colors.transparent)
                            ),
                            alignment: Alignment.center,
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Expanded(
                                  child: Text(
                                    listItems[index].name,
                                    textAlign: TextAlign.center,
                                    style: TextStyle(
                                      fontSize: 12.sp,
                                      color: selectedInterests.contains(listItems[index].name)
                                          ? Colors.blue
                                          : Colors.black,
                                    ),
                                  ),
                                ),
                                Icon(listItems[index].icon,size:16.sp,color: selectedInterests.contains(listItems[index].name)
                                    ? Colors.blue
                                    : Colors.black,)
                              ],
                            ),
                          ),
                        );
                      },
                    ),
                  ),
                ),
                Spacer(),
                _submitBoxButton,
                SizedBox(height: 10.h,)
              ],
            ),
          ),
        ),
      ),
    );
  }
}

Widget get _submitBoxButton => SizedBox(
  height: 58.h,
  width: 400.w,
  child: Builder(builder: (context) {
    return ElevatedButton(
        style: ElevatedButton.styleFrom(
          backgroundColor: Colors.black,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(30.0),
          ), // Background color
        ),
        onPressed: () {
          // Navigator
          //     .of(context)
          //     .pushReplacement(new MaterialPageRoute(builder: (BuildContext context) {
          //   return new GenderPage();
          // }));
        },
        child: const Text(
          "Save",
          style: TextStyle(
              color: Colors.white, fontSize: 20, overflow: TextOverflow.ellipsis),
          maxLines: 1,
        ));
  }),
);
class SelectInterest{
  String name;
  IconData icon;
  SelectInterest({required this.icon,required this.name});
}
class BirthDateSelect extends StatefulWidget {
  const BirthDateSelect({super.key});

  @override
  State<BirthDateSelect> createState() => _BirthDateSelectState();
}

class _BirthDateSelectState extends State<BirthDateSelect> {
  DateTime? selectedDate;

  @override
  Widget build(BuildContext context) {
    return ScreenUtilInit(
      designSize: const Size(430, 942),
      minTextAdapt: true,
      splitScreenMode: true,
      child: SafeArea(
        child: Scaffold(
          body: Padding(
            padding: EdgeInsets.only(left: 18.w, top: 50.h),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                GestureDetector(
                  onTap: () {
                  Navigator.pop(context);
                  },
                  child: Container(
                    margin: EdgeInsets.only(bottom: 18),
                    height: 30.h,
                    width: 30.w,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(20),
                      shape: BoxShape.rectangle,
                      color: Colors.black.withOpacity(0.025),
                    ),
                    child: const Center(child: Icon(Icons.arrow_back)),
                  ),
                ),
                Text(
                  "Your\nBirthday",
                  style: GoogleFonts.gabarito(
                      fontSize: 30.sp, fontWeight: FontWeight.w600),
                ),
                SizedBox(
                  height: 15.h,
                ),
                Text(
                  "Making birthdays brighter, together.",
                  style: GoogleFonts.gabarito(
                      fontSize: 16.sp, fontWeight: FontWeight.w500),
                ),
                SizedBox(
                  height: 40.h,
                ),
                DateSelectionScreen(
                  selectedDate: selectedDate,
                  onDateSelected: (DateTime date) {
                    setState(() {
                      selectedDate = date;
                    });
                  },
                ),
                SizedBox(height: 480.h,),
                Center(child: _submitBoxButton)
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class DateSelectionScreen extends StatelessWidget {
  final DateTime? selectedDate;
  final ValueChanged<DateTime> onDateSelected;

  const DateSelectionScreen({
    super.key,
    required this.selectedDate,
    required this.onDateSelected,
  });

  // Function to open the date picker
  Future<void> _selectDate(BuildContext context) async {
    final DateTime currentDate = DateTime.now();
    final DateTime initialDate = selectedDate ?? currentDate;

    // Open the date picker
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: initialDate,
      firstDate: DateTime(1900), // Set the minimum year
      lastDate: DateTime(2101), // Set the maximum year
    );

    // If a date is picked, pass it back to the parent
    if (picked != null) {
      onDateSelected(picked);
    }
  }

  @override
  Widget build(BuildContext context) {
    // Format the selected date using intl
    String formattedDate = selectedDate != null
        ? DateFormat('dd MMMM yyyy').format(selectedDate!) // Example format: 26 December 2024
        : 'DD/MM/YYYY';

    return GestureDetector(
      onTap: () {
        _selectDate(context);
      },
      child: Container(
        height: 70.h,
        width: double.infinity, // Make it take the full width
        padding: EdgeInsets.symmetric(horizontal: 18.w),
        margin: EdgeInsets.only(bottom: 18.h),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(10),
          color: Colors.black.withOpacity(0.025),
        ),
        child: Row(
          children: [
            Icon(Icons.calendar_month),
            SizedBox(width: 10.w),
            Expanded(
              child: Text(
                formattedDate,
                style: TextStyle(
                    fontSize: 16.sp, fontWeight: FontWeight.bold),
                overflow: TextOverflow.ellipsis, // Ensure text doesn't overflow
              ),
            ),
            Container(
              height: 20.h,
              width: 20.w,
              decoration: const BoxDecoration(
                image: DecorationImage(
                    image: AssetImage("assets/images/unfold.png"),
                    fit: BoxFit.contain),
              ),
            ),
          ],
        ),
      ),
    );
  }
}


class GenderPageSelect extends StatefulWidget {
  const GenderPageSelect({super.key});

  @override
  State<GenderPageSelect> createState() => _GenderPageSelectState();
}

@override
class _GenderPageSelectState extends State<GenderPageSelect> {
  int currentIndex = 0;
  List<OptionList> itemList = [];

  optionList() {
    itemList.clear();
    itemList.add(OptionList(text: "Male", icon: Icons.male));
    itemList.add(OptionList(text: "Female", icon: Icons.female));
    itemList.add(OptionList(text: "Other", icon: Icons.transgender));
    setState(() {});
  }

  @override
  void initState() {
    // TODO: implement initState
    optionList();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return ScreenUtilInit(
      designSize: const Size(430, 942),
      minTextAdapt: true,
      splitScreenMode: true,
      child: SafeArea(
          child: Scaffold(
              body: Padding(
                padding: EdgeInsets.only(left: 18.w, top: 50.h),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    GestureDetector(
                      onTap: () {
                        Navigator.pop(context);
                      },
                      child: Container(
                        margin: EdgeInsets.only(bottom: 18),
                        height: 30.h,
                        width: 30.w,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(20),
                          shape: BoxShape.rectangle,
                          color: Colors.black.withOpacity(0.025),
                        ),
                        child: const Center(child: Icon(Icons.arrow_back)),
                      ),
                    ),
                    Text(
                      "Select Your\nGender",
                      style: GoogleFonts.gabarito(
                          fontSize: 30.sp, fontWeight: FontWeight.w600),
                    ),
                    SizedBox(
                      height: 15.h,
                    ),
                    Text(
                      "In order to provide a better experience\nplease share your gender",
                      style: GoogleFonts.gabarito(
                          fontSize: 16.sp, fontWeight: FontWeight.w500),
                    ),
                    Container(
                      margin: EdgeInsets.only(right: 18.w, top: 20.h),
                      child: ListView.builder(
                          itemCount: itemList.length,
                          physics: NeverScrollableScrollPhysics(),
                          shrinkWrap: true,
                          itemBuilder: (context, index) {
                            return GestureDetector(
                              onTap: () {
                                setState(() {
                                  currentIndex = index;
                                });
                              },
                              child: currentIndex == index
                                  ? Container(
                                height: 80.h,
                                width: 400.w,
                                margin: EdgeInsets.only(top: 5.h, bottom: 5.h),
                                padding: EdgeInsets.all(20),
                                decoration: BoxDecoration(
                                  border:
                                  Border.all(width: 1.5, color: Colors.blue),
                                  color: Colors.black.withOpacity(0.025),
                                  borderRadius: BorderRadius.circular(10),
                                ),
                                child: Row(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Expanded(
                                        child: Text(
                                          itemList[index].text,
                                          style: GoogleFonts.gabarito(
                                              color: Colors.blue,
                                              fontSize: 16.sp, fontWeight: FontWeight.w600
                                          ),
                                          maxLines: 1,
                                        )),
                                    Icon(
                                      itemList[index].icon,
                                      color: Colors.blue,
                                    )
                                  ],
                                ),
                              )
                                  : Container(
                                height: 80.h,
                                width: 400.w,
                                decoration: BoxDecoration(
                                  color: Colors.black.withOpacity(0.025),
                                  borderRadius: BorderRadius.circular(10),
                                ),
                                margin: EdgeInsets.only(top: 5.h, bottom: 5.h),
                                padding: EdgeInsets.all(20),
                                child: Row(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Expanded(
                                        child: Text(
                                          itemList[index].text,
                                          style: GoogleFonts.gabarito(
                                              fontSize: 16.sp, fontWeight: FontWeight.w600
                                          ),
                                          maxLines: 1,
                                        )),
                                    Icon(itemList[index].icon)
                                  ],
                                ),
                              ),
                            );
                          }),
                    ),
                    SizedBox(height: 10.h,),
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        RoundCheckBox(
                          onTap: (selected) {},
                          size: 25,
                          checkedColor: Colors.black,
                          uncheckedColor: Colors.black.withOpacity(0.035),
                        ),
                        SizedBox(width: 10.w,),
                        Text(
                          "Show on my profile",
                          style: GoogleFonts.gabarito(
                              fontSize: 17.sp, fontWeight: FontWeight.w500),
                        ),
                      ],
                    ),
                    SizedBox(height: 250.h,),
                    Center(child: _submitBoxButton)
                  ],
                ),
              ))),
    );
  }
}
class OptionList {
  String text;
  IconData icon;

  OptionList({required this.text, required this.icon});
}
class LookingPageSelect extends StatefulWidget {
  const LookingPageSelect({super.key});

  @override
  State<LookingPageSelect> createState() => _LookingPageSelectState();
}

class _LookingPageSelectState extends State<LookingPageSelect> {
  int currentIndex = 0;
  List<SeekingList> itemList = [];

  optionList() {
    itemList.clear();
    itemList.add(SeekingList(text: "Lifelong Friends"));
    itemList.add(SeekingList(text: "Situational Friends"));
    itemList.add(SeekingList(text: "Friend Tribe"));
    itemList.add(SeekingList(text: "Best Friend Forever"));
    itemList.add(SeekingList(text: "New Friends"));
    itemList.add(SeekingList(text: "Network"));
    setState(() {});
  }

  @override
  void initState() {
    // TODO: implement initState
    optionList();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return ScreenUtilInit(
      designSize: const Size(430, 942),
      minTextAdapt: true,
      splitScreenMode: true,
      child: SafeArea(
          child: Scaffold(
              body: Padding(
                padding: EdgeInsets.only(left: 18.w, top: 50.h),
                child: SingleChildScrollView(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      GestureDetector(
                        onTap: () {
                          Navigator.pop(context);
                        },
                        child: Container(
                          margin: EdgeInsets.only(bottom: 18),
                          height: 30.h,
                          width: 30.w,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(20),
                            shape: BoxShape.rectangle,
                            color: Colors.black.withOpacity(0.025),
                          ),
                          child: const Center(child: Icon(Icons.arrow_back)),
                        ),
                      ),
                      Text(
                        "Right Now I’m\nSeeking",
                        style: GoogleFonts.gabarito(
                            fontSize: 30.sp, fontWeight: FontWeight.w600),
                      ),
                      SizedBox(
                        height: 15.h,
                      ),
                      Text(
                        "Make new connections, expand your world.",
                        style: GoogleFonts.gabarito(
                            fontSize: 16.sp, fontWeight: FontWeight.w500),
                      ),
                      Container(
                        margin: EdgeInsets.only(right: 18.w, top: 20.h),
                        child: ListView.builder(
                            itemCount: itemList.length,
                            physics: NeverScrollableScrollPhysics(),
                            shrinkWrap: true,
                            itemBuilder: (context, index) {
                              return GestureDetector(
                                onTap: () {
                                  setState(() {
                                    currentIndex = index;
                                  });
                                },
                                child: currentIndex == index
                                    ? Container(
                                  height: 80.h,
                                  width: 400.w,
                                  margin: EdgeInsets.only(top: 5.h, bottom: 5.h),
                                  padding: EdgeInsets.all(20),
                                  decoration: BoxDecoration(
                                    border:
                                    Border.all(width: 1.5, color: Colors.blue),
                                    color: Colors.black.withOpacity(0.025),
                                    borderRadius: BorderRadius.circular(10),
                                  ),
                                  child: Row(
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    children: [
                                      Expanded(
                                          child: Text(
                                            itemList[index].text,
                                            style: GoogleFonts.gabarito(
                                                color: Colors.blue,
                                                fontSize: 16.sp, fontWeight: FontWeight.w600
                                            ),
                                            maxLines: 1,
                                          )),
                                      Container(
                                        height: 20.h,
                                        width: 20.h,
                                        decoration: BoxDecoration(
                                          shape: BoxShape.circle,
                                          border: Border.all(width: 6,color: Colors.black),
                                        ),
                                      )
                                    ],
                                  ),
                                )
                                    : Container(
                                  height: 80.h,
                                  width: 400.w,
                                  decoration: BoxDecoration(
                                    color: Colors.black.withOpacity(0.025),
                                    borderRadius: BorderRadius.circular(10),
                                  ),
                                  margin: EdgeInsets.only(top: 5.h, bottom: 5.h),
                                  padding: EdgeInsets.all(20),
                                  child: Row(
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    children: [
                                      Expanded(
                                          child: Text(
                                            itemList[index].text,
                                            style: GoogleFonts.gabarito(
                                                fontSize: 16.sp, fontWeight: FontWeight.w600
                                            ),
                                            maxLines: 1,
                                          )),
                                      Container(
                                        height: 20.h,
                                        width: 20.h,
                                        decoration: BoxDecoration(
                                          shape: BoxShape.circle,
                                          color: Colors.black.withOpacity(0.045),
                                        ),
                                      )
                                    ],
                                  ),
                                ),
                              );
                            }),
                      ),
                      SizedBox(height: 10.h,),
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          RoundCheckBox(
                            onTap: (selected) {},
                            size: 25,
                            checkedColor: Colors.black,
                            uncheckedColor: Colors.black.withOpacity(0.035),
                          ),
                          SizedBox(width: 10.w,),
                          Text(
                            "Show on my profile",
                            style: GoogleFonts.gabarito(
                                fontSize: 17.sp, fontWeight: FontWeight.w500),
                          ),
                        ],
                      ),
                      SizedBox(height: 10.h,),
                      Center(child: _submitBoxButton)
                    ],
                  ),
                ),
              ))),
    );
  }
}
class SeekingList {
  String text;

  SeekingList({required this.text,});
}