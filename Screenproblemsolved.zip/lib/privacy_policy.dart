import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:google_fonts/google_fonts.dart';

class PrivacyPolicy extends StatefulWidget {
  const PrivacyPolicy({super.key});

  @override
  State<PrivacyPolicy> createState() => _PrivacyPolicyState();
}

List<PolicyName> policyInfo = [];

class _PrivacyPolicyState extends State<PrivacyPolicy> {
  PolicyData() {
    policyInfo.clear();
    policyInfo.add(PolicyName(
        policyName: "Profile Information",
        description:
            "We recommend and encourage you (and all our members) to think carefully about the information you disclose about yourself. We also do not recommend that you put email addresses, URLs, instant messaging details, phone numbers, full names or addresses, credit card details, national identity numbers, drivers’ license details and other sensitive information which is open to abuse and misuse on your profile.When you post information about yourself or use the messaging function to communicate with other Users, the amount of personal information you share is at your own risk. Please see Section 4 below for more information on who can access what you post on BF Connect."));

    policyInfo.add(PolicyName(
        policyName: "Profile Verification Information",
        description:
        "For safety and security and to ensure you have the best possible user experience, we require Users to verify their accounts and might ask for your phone number and, in some instances, we might also ask that you carry out photo verification. We want to make sure you are not a robot! And we also want to avoid fake Bumble accounts being created which can be used for malicious activities and cybercrime – they threaten the BF Connect network and spoil things for everyone. This verification might be required by us for the prevention of fraud. You can also verify your photo on a voluntary basis (to add the blue ‘verified’ badge to your profile)."));

    policyInfo.add(PolicyName(
        policyName: "Purchases Information",
        description:
        "If you decide to purchase any of our premium services, we will process your payment information and retain this securely for the prevention of fraud and for audit/tax purposes."));

    policyInfo.add(PolicyName(
        policyName: "Device and Photos Information",
        description:
        "We may collect information about your device when you use the App including the unique device identifier, device model, and operating system, for a number of purposes, as set out in this policy. In addition, if you permit us to do so, the App may access your device’s address book solely in order to add someone to your contacts."));
    setState(() {});
  }

  @override
  void initState() {
    // TODO: implement initState
    PolicyData();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return ScreenUtilInit(
        designSize: const Size(430, 942),
        minTextAdapt: true,
        splitScreenMode: true,
        child: SafeArea(
            child: Scaffold(
          body: Padding(
            padding: EdgeInsets.only(left: 18.w, top: 50.h, right: 18.w),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    GestureDetector(
                      onTap: () {
                        Navigator.pop(context);
                      },
                      child: Container(
                        height: 60.h,
                        width: 60.w,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: Colors.black.withOpacity(0.025),
                        ),
                        child: const Center(child: Icon(Icons.arrow_back)),
                      ),
                    ),
                    SizedBox(
                      width: 20.w,
                    ),
                    Text(
                      "Privacy Policy",
                      style: GoogleFonts.gabarito(
                          fontSize: 20.sp, fontWeight: FontWeight.w600),
                    ),
                  ],
                ),
                SizedBox(
                  height: 20.h,
                ),
                Expanded(
                  child: ListView.builder(
                      itemCount: policyInfo.length,
                      // physics: NeverScrollableScrollPhysics(),
                      shrinkWrap: true,
                      itemBuilder: (context, index) {
                        return Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              policyInfo[index].policyName,
                              style: GoogleFonts.gabarito(
                                  fontSize: 20.sp, fontWeight: FontWeight.w600),
                            ),
                            SizedBox(
                              height: 10.h,
                            ),
                            Text(
                              policyInfo[index].description,
                              style: GoogleFonts.gabarito(
                                  fontSize: 14.sp, fontWeight: FontWeight.w400),
                            ),
                          ],
                        );
                      }),
                ),
                SizedBox(height: 10.h,),
              ],
            ),
          ),
        )));
  }
}

class PolicyName {
  String policyName;
  String description;

  PolicyName({required this.policyName, required this.description});
}
