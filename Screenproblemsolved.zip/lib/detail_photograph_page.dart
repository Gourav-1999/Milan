import 'dart:convert';
import 'dart:io';

import 'package:dotted_border/dotted_border.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:image_picker/image_picker.dart';
import 'package:milan/detail_gender_page.dart';
import 'package:milan/details_location_page.dart';
import 'package:milan/home_page.dart';
import 'package:milan/milan.dart';
import 'package:http/http.dart' as http;
import 'commons/local_storage.dart';
import 'login_page.dart';

class YourPhotographs extends StatefulWidget {
  const YourPhotographs({super.key});

  @override
  State<YourPhotographs> createState() => _YourPhotographsState();
}

class _YourPhotographsState extends State<YourPhotographs> {
  int? currentIndex;
  final Map<int, File?> _image = {};
  final List<bool> isClicked = List.generate(8, (index) => false);

  Future<void> completeDetail(BuildContext context) async {
    try {

      List<String> images = [];
      _image.forEach((key, imageFile) {
        if (imageFile != null) {
          images.add(base64Encode(imageFile.readAsBytesSync()));
        }
      });

      if (images.isEmpty) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Please add at least one image.')),
        );
        return;
      }

      Map<String, dynamic> body = {
        "steps": 11,
        "image_index": (currentIndex ?? 0) + 1,
        "images": images,
      };

      final url = Uri.parse('http://192.168.2.42:8004/api/v1/update-details');
      final response = await http.post(
        url,
        body: jsonEncode(body),
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer ${await LocalStorage.getToken()}',
        },
      );

      print(response.body);
      if (response.statusCode == 200) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Congratulations! Your Account Has Been Created')),
        );
        Navigator.pushAndRemoveUntil(
          context,
          MaterialPageRoute(builder: (context) =>  Milan(Index: 0)),
              (Route<dynamic> route) => false,
        );
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Failed to update. Please try again later.')),
        );
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error: $e')),
      );
    }
  }

  Future<void> _openCamera(int index) async {
    final ImagePicker picker = ImagePicker();
    final XFile? pickedImage = await picker.pickImage(source: ImageSource.camera);

    if (pickedImage != null) {
      setState(() {
        _image[index] = File(pickedImage.path);
      });
    }
  }
  @override
  Widget build(BuildContext context) {
    return SafeArea(child: Scaffold(
      body: Padding(
        padding:  EdgeInsets.only(left: 18.w,top: 50.h,right: 18.w),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              GestureDetector(
                onTap: (){
                  Navigator
                      .of(context)
                      .pushReplacement(new MaterialPageRoute(builder: (BuildContext context) {
                    return new Location();
                  }));
                },
                child: Container(
                  margin: EdgeInsets.only(bottom: 18.h),
                  height: 50.h,
                  width: 50.w,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: Colors.black.withOpacity(0.025),
                  ),
                  child: const Center(
                      child: Icon(Icons.arrow_back)
                  ),
                ),
              ),
              Text("Add Your\nPhotographs",style:GoogleFonts.gabarito(
                  fontSize: 30.sp,
                  fontWeight: FontWeight.w600
              ),),
              SizedBox(height: 10.h,),
              Text("Add your photos to the friend feed!",style:GoogleFonts.gabarito(
                  fontSize: 16.sp,
                  fontWeight: FontWeight.w500
              ),),

        GridView.builder(
          shrinkWrap: true,
          physics: NeverScrollableScrollPhysics(),
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 2, // number of items in each row
            mainAxisSpacing: 8.0, // spacing between rows
            crossAxisSpacing: 8.0,
             childAspectRatio: 1.025,
            // spacing between columns
          ),
          padding: EdgeInsets.only(right: 18.w,top: 18.h),
          // padding around the grid
          itemCount: 6,
          // total number of items
          itemBuilder: (context, index) {
            return index==0?DottedBorder(
              borderType: BorderType.RRect,
              radius: Radius.circular(20),
              strokeWidth: 2,
                color: Colors.grey.withOpacity(0.155),
              child: Stack(
                children: [
                  Container(
                    width: 225.w,
                    height: 225.h,
                    decoration: BoxDecoration(
                        color: Colors.blue.withOpacity(0.085),
                        image: DecorationImage(
                            image: AssetImage("assets/images/Rectangle 205.png"),
                            fit: BoxFit.fill
                        )
                    ),
                  ),
                  Positioned(
                      top: 120.h,
                      left: 130.w,
                      child: IconButton(icon: const Icon(Icons.delete_outline,color: Colors.white,), onPressed: () {  },)),
                  Positioned(
                      left: 130.w,
                      child: IconButton(icon: const Icon(Icons.edit,color: Colors.white,), onPressed: () {  },))
                ],

              ),
            ):DottedBorder(
              borderType: BorderType.RRect,
              radius: Radius.circular(15),
              strokeWidth: 2,
              color: Colors.grey.withOpacity(0.155),
              child: Center(
                child: Container(
                    margin: EdgeInsets.all(10),
                    width: 40.w,
                    height: 40.h,
                    decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: Colors.blue.withOpacity(0.085)
                    ),
                    child: Icon(Icons.add,color: Colors.blue,)
                ),
              ),
            );
          },
        ),

              SizedBox(height: 25.h,),
              Center(child: SizedBox(
                height: 40.h,
                width: 400.w,
                child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.black,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(25.0),
                      ), // Background color
                    ),
                    onPressed: () {
                      completeDetail(context);
                    },
                    child: const Text(
                      "Complete Profile",
                      style: TextStyle(
                          color: Colors.white, fontSize: 20, overflow: TextOverflow.ellipsis),
                      maxLines: 1,
                    )),
              )),
              SizedBox(height: 10.h,),
            ],
          ),
        ),
      ),
    ));
  }
}
