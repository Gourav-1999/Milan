import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:google_fonts/google_fonts.dart';

class HelpCenter extends StatefulWidget {
  const HelpCenter({super.key});

  @override
  State<HelpCenter> createState() => _HelpCenterState();
}
List<HelpData> itemList=[];
class _HelpCenterState extends State<HelpCenter> {

  DataList(){
    itemList.clear();
    itemList.add(HelpData(name: "What picture should I use on BF Connect?"));
    itemList.add(HelpData(name: "What should I put in my bio?"));
    itemList.add(HelpData(name: "How do I unmatch someone?"));
    itemList.add(HelpData(name: "How do BF Connect matches work?"));
    itemList.add(HelpData(name: "How does BF Connect work?"));
    itemList.add(HelpData(name: "Are BF Connect profiles real?"));
    itemList.add(HelpData(name: "Where does BF Connect work?"));
    itemList.add(HelpData(name: "Which BF Connect subscription is best?"));
    setState(() {

    });
  }

  @override
  void initState() {
    // TODO: implement initState
    DataList();
    super.initState();
  }
  @override
  Widget build(BuildContext context) {
    return ScreenUtilInit(
        designSize: const Size(430, 942),
        minTextAdapt: true,
        splitScreenMode: true,
        child: SafeArea(
            child: Scaffold(
          body: Padding(
            padding: EdgeInsets.only(left: 18.w, top: 50.h, right: 18.w),
            child: Column(
              children: [
                Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    GestureDetector(
                      onTap: () {
                        Navigator.pop(context);
                      },
                      child: Container(
                        height: 60.h,
                        width: 60.w,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: Colors.black.withOpacity(0.025),
                        ),
                        child: const Center(child: Icon(Icons.arrow_back)),
                      ),
                    ),
                    SizedBox(
                      width: 20.w,
                    ),
                    Text(
                      "Help Center",
                      style: GoogleFonts.gabarito(
                          fontSize: 20.sp, fontWeight: FontWeight.w600),
                    ),
                  ],
                ),
                SizedBox(
                  height: 20.h,
                ),
                ListView.builder(
                    itemCount: itemList.length,
                    physics: NeverScrollableScrollPhysics(),
                    shrinkWrap: true,
                    itemBuilder: (context, index) {
                      return GestureDetector(
                        onTap: () {

                        },
                        child:Container(
                          margin: EdgeInsets.only(top: 5.h, bottom: 5.h),
                          padding: EdgeInsets.all(20),
                          decoration: BoxDecoration(
                            color: Colors.white,
                            boxShadow: [
                              BoxShadow(
                                blurRadius: 10,
                                offset: Offset(0,10),
                                color: Colors.black12
                              )
                            ],
                            borderRadius: BorderRadius.circular(10),
                          ),
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Expanded(
                                  child: Text(
                                    itemList[index].name,
                                    style: GoogleFonts.gabarito(
                                        fontSize: 16.sp, fontWeight: FontWeight.w600
                                    ),
                                    maxLines: 1,
                                  )),
                              const Icon(
                                Icons.keyboard_arrow_down_outlined,
                              )
                            ],
                          ),
                        )
                      );
                    }),
              ],
            ),
          ),
        )));
  }
}
class HelpData{
  String name;
  HelpData({required this.name});
}