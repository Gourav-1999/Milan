import 'dart:async';
import 'dart:convert';
import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:flutter_otp_text_field/flutter_otp_text_field.dart';
import 'package:milan/milan.dart';
import 'package:milan/models/user_model.dart';
import 'package:milan/detail_name_page.dart';
import 'package:milan/login_page.dart';
import 'package:milan/welcome_page.dart';

import 'commons/local_storage.dart';

class OTP extends StatefulWidget {
  final String phoneNumber;
  final String isoCode;
  final String countryCode;

  OTP({
    required this.countryCode,
    required this.isoCode,
    required this.phoneNumber,
    super.key,
  });

  @override
  State<OTP> createState() => _OTPState();
}

class _OTPState extends State<OTP> {
  final TextEditingController otpController = TextEditingController();
  bool _isLoading = false;
  Dio dio = Dio();

  Timer? _timer;

  void configLoading() {
    EasyLoading.instance
      ..displayDuration = const Duration(milliseconds: 2000)
      ..indicatorType = EasyLoadingIndicatorType.fadingCircle
      ..loadingStyle = EasyLoadingStyle.dark
      ..indicatorSize = 45.0
      ..radius = 10.0
      ..progressColor = Colors.yellow
      ..backgroundColor = Colors.green
      ..indicatorColor = Colors.yellow
      ..textColor = Colors.yellow
      ..maskColor = Colors.blue.withOpacity(0.5)
      ..userInteractions = true
      ..dismissOnTap = false
      ..customAnimation = CustomAnimation();
  }

  void showSnackBar(String message) {
    ScaffoldMessenger.of(context)
        .showSnackBar(SnackBar(content: Text(message)));
  }

  Future<void> postPhoneData() async {
    if (otpController.text.isEmpty) {
      showSnackBar('Please enter a valid OTP');

      return;
    }

    Map<String, dynamic> map = {
      'iso_code': widget.isoCode.toLowerCase(),
      'phone_code': widget.countryCode,
      'phone': widget.phoneNumber,
      'otp': otpController.text,
    };

    String url = 'http://192.168.2.42:8004/api/v1/verify-firebase';

    try {
      setState(() {
        _isLoading = true;
      });

      final response = await dio.post(
        url,
        data: jsonEncode(map),
        options: Options(
          headers: {
            'Content-Type': 'application/json',
          },
        ),
      );

      print(response.data);

      // Check if the response is already in Map format or a JSON string

      dynamic responseData = response.data;

      // If it's a JSON string, decode it

      if (responseData is String) {
        responseData = json.decode(responseData);
      }

      if (response.statusCode == 200) {
        // Ensure responseData is a Map before accessing the data

        if (responseData is Map<String, dynamic>) {
          UserModal userModel = UserModal.fromJson(responseData);

          print(response.data);

          print(userModel.data?.steps);

          if (userModel.data != null) {
            final token = userModel.data?.rememberToken;

            final step = userModel.data?.steps;

            print('hello : $token');

            if (token != null) {
              await LocalStorage.storeToken(token);
            }

            // Navigating to the appropriate step screen

            if (step == null) {
              print(response.data);

              Navigator.pushReplacement(context,
                  MaterialPageRoute(builder: (context) => EnterName()));
            } else if (step == 1) {
              Navigator.popAndPushNamed(context, '/selectGender');
            } else if (step == 2) {
              Navigator.popAndPushNamed(context, '/lookGender');
            } else if (step == 3) {
              Navigator.popAndPushNamed(context, '/relationStatus');
            } else if (step == 4) {
              Navigator.popAndPushNamed(context, '/seekingFor');
            } else if (step == 5) {
              Navigator.popAndPushNamed(context, '/ethnicity');
            } else if (step == 6) {
              Navigator.popAndPushNamed(context, '/ifChild');
            } else if (step == 7) {
              Navigator.popAndPushNamed(context, '/dob');
            } else if (step == 8) {
              Navigator.popAndPushNamed(context, '/interest');
            } else if (step == 9) {
              Navigator.popAndPushNamed(context, '/location');
            } else if (step == 10) {
              Navigator.popAndPushNamed(context, '/addPhoto');
            } else if (step == 11) {
              Navigator.pushAndRemoveUntil(
                  context,
                  MaterialPageRoute(builder: (context) => Milan(Index: 0)),
                  (Route) => false);
            }
          }
        } else {
          print('Error: Response data is not a valid Map');
        }
      } else {
        print('Error: ${response.statusCode}');
      }
    } catch (e) {
      showSnackBar('Failed to send data: $e');

      print(e);
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  Future<void> resendOTP() async {
    String url = 'http://192.168.2.34:8004/api/v1/resend-otp';
    Map<String, dynamic> map = {
      'iso_code': widget.isoCode.toLowerCase(),
      'phone_code': widget.countryCode,
      'phone': widget.phoneNumber,
    };

    try {
      final response = await dio.post(url, data: jsonEncode(map));

      if (response.statusCode == 200) {
        showSnackBar('OTP resent successfully!');
      } else {
        showSnackBar('Failed to resend OTP');
      }
    } catch (e) {
      showSnackBar('Failed to resend OTP: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body: Padding(
          padding: EdgeInsets.only(left: 18.w, top: 50.h, right: 18.w),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              GestureDetector(
                onTap: () {
                  Navigator.of(context).pushReplacement(
                    MaterialPageRoute(builder: (BuildContext context) {
                      return LoginPage();
                    }),
                  );
                },
                child: Container(
                  margin: EdgeInsets.only(bottom: 18.h),
                  height: 50.h,
                  width: 50.w,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: Colors.black.withOpacity(0.025),
                  ),
                  child: const Center(child: Icon(Icons.arrow_back)),
                ),
              ),
              Text(
                "Enter Your\nVerification Code",
                style: GoogleFonts.gabarito(
                    fontSize: 30.sp, fontWeight: FontWeight.w600),
              ),
              SizedBox(height: 15.h),
              Text(
                "Please enter the code we just sent to number",
                style: GoogleFonts.gabarito(
                    fontSize: 16.sp, fontWeight: FontWeight.w500),
              ),
              SizedBox(height: 5.h),
              Row(
                children: [
                  Text(
                    widget.phoneNumber,
                    style: GoogleFonts.gabarito(
                        fontSize: 16.sp, fontWeight: FontWeight.w500),
                  ),
                  SizedBox(width: 5.w),
                  Container(
                    height: 30.h,
                    width: 65.w,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(20.r),
                      shape: BoxShape.rectangle,
                      border: Border.all(width: 1, color: Colors.blue),
                    ),
                    child: const Center(
                      child: Text(
                        "Change",
                        style: TextStyle(color: Colors.blue),
                      ),
                    ),
                  ),
                ],
              ),
              SizedBox(height: 10.h),
              OtpTextField(
                fieldHeight: 60.h,
                fieldWidth: 45.w,
                keyboardType: TextInputType.number,
                showFieldAsBox: true,
                focusedBorderColor: Colors.white,
                enabledBorderColor: Colors.white,
                borderColor: Colors.black.withOpacity(0.0),
                fillColor: Colors.black.withOpacity(0.075),
                filled: true,
                borderRadius: BorderRadius.circular(30.r),
                numberOfFields: 6,
                decoration: const InputDecoration(
                  border: InputBorder.none,
                ),
                onSubmit: (String code) {
                  otpController.text = code;
                  setState(() {});
                },
              ),
              SizedBox(height: 20.h),
              Center(
                child: Text(
                  "Didn’t receive verification code?",
                  style: GoogleFonts.gabarito(
                      fontSize: 14.sp, fontWeight: FontWeight.w400),
                ),
              ),
              Center(
                child: GestureDetector(
                  onTap: () {
                    resendOTP();
                  },
                  child: Text(
                    "Resend Code",
                    style: GoogleFonts.gabarito(
                        fontSize: 14.sp,
                        color: Colors.blue,
                        fontWeight: FontWeight.w400),
                  ),
                ),
              ),
              // SizedBox(height: 420.h),
              Spacer(),
              Center(
                child: SizedBox(
                  height: 40.h,
                  width: 400.w,
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.black,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(25.0.r),
                      ),
                    ),
                    onPressed: () {
                      if (otpController.text.isEmpty) {
                        showSnackBar("Please enter OTP");
                      } else {
                        postPhoneData();
                      }
                    },
                    child: Text(
                      "Verify",
                      style: TextStyle(
                          color: Colors.white,
                          fontSize: 20.sp,
                          overflow: TextOverflow.ellipsis),
                      maxLines: 1,
                    ),
                  ),
                ),
              ),
              SizedBox(height: 10.h),
            ],
          ),
        ),
      ),
    );
  }
}

class CustomAnimation extends EasyLoadingAnimation {
  CustomAnimation();

  @override
  Widget buildWidget(
    Widget child,
    AnimationController controller,
    AlignmentGeometry alignment,
  ) {
    return Opacity(
      opacity: controller.value,
      child: RotationTransition(
        turns: controller,
        child: child,
      ),
    );
  }
}
