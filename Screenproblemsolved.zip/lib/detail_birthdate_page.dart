import 'dart:convert';

import 'package:dio/dio.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';

import 'commons/local_storage.dart';
import 'detail_children_page.dart';
import 'detail_interest_page.dart';
import 'models/user_model.dart';  // Assuming this is your next screen

class BirthDate extends StatefulWidget {
  const BirthDate({super.key});

  @override
  State<BirthDate> createState() => _BirthDateState();
}

class _BirthDateState extends State<BirthDate> {
  DateTime? selectedDate;
  int currentIndex=0;
  final Dio _dio = Dio();
  final String apiUrl = 'http://192.168.2.42:8004/api/v1/update-details';



  Future<void> postDOB(String dob) async {
    Map<String, dynamic> map = {
      "dob": dob,
      "steps": 8,
    };

    try {
      final response = await _dio.post(
        apiUrl,
        data: jsonEncode(map),
        options: Options(
          headers: {
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ${await LocalStorage.getToken()}'
          },
        ),
      );
      print(response.data);
      print(map);
      UserModal userModal = UserModal.fromJson(response.data);
      print("Status--${userModal?.data?.gender}");
      if (response.statusCode == 200) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Successfully add DOB')),
        );
        Navigator.of(context).pushReplacement(
            new MaterialPageRoute(builder: (BuildContext context) {
              return new SelectInterestsPage();
            }));
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Error: Failed add DOB')),
        );
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Failed add DOB')),
      );
      print(e);
    }
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body: Padding(
          padding: EdgeInsets.only(left: 18.w, top: 50.h,right: 18.w),
          child: SingleChildScrollView(
            child: Container(
              height: MediaQuery.of(context).size.height,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  GestureDetector(
                    onTap: () {
                      Navigator.of(context).pushReplacement(
                        MaterialPageRoute(builder: (BuildContext context) {
                          return const ChildrenPage();
                        }),
                      );
                    },
                    child: Container(
                      margin: EdgeInsets.only(bottom: 18.h),
                      height: 50.h,
                      width: 50.w,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: Colors.black.withOpacity(0.025),
                      ),
                      child: const Center(child: Icon(Icons.arrow_back)),
                    ),
                  ),
                  Text(
                    "Your\nBirthday",
                    style: GoogleFonts.gabarito(
                        fontSize: 30.sp, fontWeight: FontWeight.w600),
                  ),
                  SizedBox(
                    height: 15.h,
                  ),
                  Text(
                    "Making birthdays brighter, together.",
                    style: GoogleFonts.gabarito(
                        fontSize: 16.sp, fontWeight: FontWeight.w500),
                  ),
                  SizedBox(
                    height: 40.h,
                  ),
                  DateSelectionScreen(
                    selectedDate: selectedDate,
                    onDateSelected: (DateTime date) {
                      setState(() {
                        selectedDate = date;
                      });
                      postDOB("$selectedDate");
                    },
                  ),
                  Spacer(),
                  //SizedBox(height: 470.h,),
                  Center(child: SizedBox(
                    height: 40.h,
                    width: 400.w,
                    child: ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.black,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(25.0.r),
                          ), // Background color
                        ),
                        onPressed: () {
                          if (currentIndex != null) {
                            ScaffoldMessenger.of(context).showSnackBar(
                              const SnackBar(
                                  content: Text('Please select DOB')),
                            );
                          } else {
                            postDOB("$selectedDate");
                          }
                        },
                        child: const Text(
                          "Next",
                          style: TextStyle(
                              color: Colors.white,
                              fontSize: 20,
                              overflow: TextOverflow.ellipsis),
                          maxLines: 1,
                        )),
                  )),
                  SizedBox(height: 10.h,)
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class DateSelectionScreen extends StatelessWidget {
  final DateTime? selectedDate;
  final ValueChanged<DateTime> onDateSelected;

  const DateSelectionScreen({
    super.key,
    required this.selectedDate,
    required this.onDateSelected,
  });

  // Function to open the date picker
   Future<void> _selectDate(BuildContext context) async {
    final DateTime currentDate = DateTime.now();
    final DateTime initialDate = selectedDate ?? currentDate;

    // Open the date picker
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: initialDate,
      firstDate: DateTime(1900), // Set the minimum year
      lastDate: DateTime.now() // Set the maximum year
    );

    // If a date is picked, pass it back to the parent
    if (picked != null) {
      onDateSelected(picked);
    }
  }

  @override
  Widget build(BuildContext context) {
    // Format the selected date using intl
    String formattedDate = selectedDate != null
        ? DateFormat('dd MMMM yyyy').format(selectedDate!) // Example format: 26 December 2024
        : 'DD/MM/YYYY';

    return GestureDetector(
      onTap: () {
        _selectDate(context);
      },
      child: Container(
        height: 50.h,
        width: double.infinity, // Make it take the full width
        padding: EdgeInsets.symmetric(horizontal: 18.w),
        margin: EdgeInsets.only(bottom: 18.h),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(10),
          color: Colors.black.withOpacity(0.025),
        ),
        child: Row(
          children: [
            Icon(Icons.calendar_month),
            SizedBox(width: 10.w),
            Expanded(
              child: Text(
                formattedDate,
                style: TextStyle(
                    fontSize: 16.sp, fontWeight: FontWeight.bold),
                overflow: TextOverflow.ellipsis, // Ensure text doesn't overflow
              ),
            ),
            Container(
              height: 20.h,
              width: 20.w,
              decoration: const BoxDecoration(
                image: DecorationImage(
                    image: AssetImage("assets/images/unfold.png"),
                    fit: BoxFit.contain),
              ),
            ),
          ],
        ),
      ),
    );
  }
}