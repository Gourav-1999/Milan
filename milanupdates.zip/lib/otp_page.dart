import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_otp_text_field/flutter_otp_text_field.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:milan/detail_name_page.dart';
import 'package:milan/login_page.dart';

class OTP extends StatefulWidget {
  const OTP({super.key});

  @override
  State<OTP> createState() => _OTPState();
}

class _OTPState extends State<OTP> {
  @override
  Widget build(BuildContext context) {
    return ScreenUtilInit(
      designSize: const Size(430, 942),
      minTextAdapt: true,
      splitScreenMode: true,
      child: SafeArea(child: Scaffold(
        body: Padding(
          padding:  EdgeInsets.only(left: 18.w,top: 50.h,right: 18.w),
          child: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
            
                GestureDetector(
                  onTap: (){
                    Navigator
                        .of(context)
                        .pushReplacement(new MaterialPageRoute(builder: (BuildContext context) {
                      return new LoginPage();
                    }));
                  },
                  child: Container(
                    margin: EdgeInsets.only(bottom: 18),
                    height: 50.h,
                    width: 50.w,
                    decoration: BoxDecoration(
                        shape: BoxShape.circle,
                      color: Colors.black.withOpacity(0.025),
                    ),
                    child: const Center(
                      child: Icon(Icons.arrow_back)
                    ),
                  ),
                ),
            
            
                Text("Enter Your\nVerification Code",style:GoogleFonts.gabarito(
                    fontSize: 30.sp,
                    fontWeight: FontWeight.w600
                ),),
                SizedBox(height: 15.h,),
                Text("Please enter the code we just send to number",style:GoogleFonts.gabarito(
                    fontSize: 16.sp,
                    fontWeight: FontWeight.w500
                ),),
                SizedBox(height: 5.h,),
                Row(
                  children: [
                    Text("0123456789",style:GoogleFonts.gabarito(
                        fontSize: 16.sp,
                        fontWeight: FontWeight.w500
                    ),),
                    SizedBox(width: 5.w,),
                    Container(
                      height: 30.h,
                      width: 65.w,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(20),
                        shape: BoxShape.rectangle,
                        border: Border.all(width: 1,color: Colors.blue)
                      ),
                      child: const Center(
                        child: Text("Change",style: TextStyle(color: Colors.blue,overflow: TextOverflow.ellipsis),),
                      ),
                    )
                  ],
                ),
                SizedBox(height: 10.h,),
                OtpTextField(
                  fieldHeight: 50.h,
                  fieldWidth: 50.w,
                  keyboardType: TextInputType.number,
                  numberOfFields: 6,
                  showFieldAsBox: true,
                  focusedBorderColor: Colors.white,
                  enabledBorderColor: Colors.white,
                  borderColor: Colors.black.withOpacity(0),
                  fillColor: Colors.black.withOpacity(0.025),
                  filled: true,
                  borderRadius: BorderRadius.circular(30),
            
                ),
                SizedBox(height: 20.h,),
                Center(
                  child: Text("Didn’t receive verification code",style:GoogleFonts.gabarito(
                      fontSize: 14.sp,
                      fontWeight: FontWeight.w400
                  ),),
                ),
                Center(
                  child: Text("Resend Code",style:GoogleFonts.gabarito(
                      fontSize: 14.sp,
                      color: Colors.blue,
                      fontWeight: FontWeight.w400
                  ),),
                ),
                SizedBox(height: 420.h,),
                Center(
                  child: _checkBoxButton,
                )
              ],
            ),
          ),
        )
      )),
    );
  }
}
Widget get _checkBoxButton => SizedBox(
  height: 58.h,
  width: 400.w,
  child: Builder(builder: (context) {
    return ElevatedButton(
        style: ElevatedButton.styleFrom(
          backgroundColor: Colors.black,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(25.0),
          ), // Background color
        ),
        onPressed: () {
          Navigator
              .of(context)
              .pushReplacement(new MaterialPageRoute(builder: (BuildContext context) {
            return new EnterName();
          }));
        },
        child: const Text(
          "Verify",
          style: TextStyle(
              color: Colors.white, fontSize: 20, overflow: TextOverflow.ellipsis),
          maxLines: 1,
        ));
  }),
);