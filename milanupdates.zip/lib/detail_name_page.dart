import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:milan/detail_gender_page.dart';

import 'login_page.dart';

class EnterName extends StatefulWidget {
  const EnterName({super.key});

  @override
  State<EnterName> createState() => _EnterNameState();
}

class _EnterNameState extends State<EnterName> {
  @override
  Widget build(BuildContext context) {
    return ScreenUtilInit(
      designSize: const Size(430, 942),
      minTextAdapt: true,
      splitScreenMode: true,
      child:  SafeArea(child: Scaffold(
        body: Padding(
          padding:  EdgeInsets.only(left: 18.w,top: 50.h,right: 18.w),
          child: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                GestureDetector(
                  onTap: (){
                    Navigator
                        .of(context)
                        .pushReplacement(new MaterialPageRoute(builder: (BuildContext context) {
                      return new LoginPage();
                    }));
                  },
                  child: Container(
                    margin: EdgeInsets.only(bottom: 18),
                    height: 50.h,
                    width: 50.w,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: Colors.black.withOpacity(0.025),
                    ),
                    child: const Center(
                        child: Icon(Icons.arrow_back)
                    ),
                  ),
                ),
                Text("Your\nName",style:GoogleFonts.gabarito(
                    fontSize: 30.sp,
                    fontWeight: FontWeight.w600
                ),),
                SizedBox(height: 10.h,),
                Text("Never miss a moment, reconnect with ease.",style:GoogleFonts.gabarito(
                    fontSize: 16.sp,
                    fontWeight: FontWeight.w500
                ),),
                SizedBox(height: 10.h,),
                _nameTextField,
                SizedBox(height: 20.h,),
                _bioTextField,
                SizedBox(height: 310.h,),
                Center(child: _submitBoxButton)
              ],
            ),
          ),
        ),
      )),
    );
  }
}
Widget get _nameTextField =>  Container(
  margin: EdgeInsets.only(right: 18.w),
  decoration: BoxDecoration(
      color: Colors.black.withOpacity(0.055),
      borderRadius: BorderRadius.circular(10)
  ),
  child: TextFormField(
    textInputAction: TextInputAction.done,
    keyboardType: TextInputType.text,
    decoration:  InputDecoration(
      fillColor: Colors.black.withOpacity(0.025),
      contentPadding: const EdgeInsets.only(left: 20,right: 10,top: 10,bottom: 10),
      border: InputBorder.none,
      hintText: 'Enter Full Name',
      hintStyle: const TextStyle(
          color: Colors.grey,
          overflow: TextOverflow.ellipsis),
    ),
    maxLines: 1,
  ),
);
Widget get _bioTextField =>  Container(
  height: 200.h,
  width:400.w,
  margin: EdgeInsets.only(right: 18.w),
  decoration: BoxDecoration(
      color: Colors.black.withOpacity(0.055),
      borderRadius: BorderRadius.circular(10)
  ),
  child: TextFormField(
    textInputAction: TextInputAction.done,
    keyboardType: TextInputType.text,
    decoration:  InputDecoration(
      fillColor: Colors.black.withOpacity(0.025),
      contentPadding: const EdgeInsets.only(left: 20,right: 10,top: 10,bottom: 10),
      border: InputBorder.none,
      hintText: 'My Bio',
      hintStyle: const TextStyle(
          color: Colors.grey,
          overflow: TextOverflow.ellipsis),
    ),
    maxLines: 1,
  ),
);
Widget get _submitBoxButton => SizedBox(
  height: 58.h,
  width: 400.w,
  child: Builder(builder: (context) {
    return ElevatedButton(
        style: ElevatedButton.styleFrom(
          backgroundColor: Colors.black,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(25.0),
          ), // Background color
        ),
        onPressed: () {
          Navigator
              .of(context)
              .pushReplacement(new MaterialPageRoute(builder: (BuildContext context) {
            return new GenderPage();
          }));
        },
        child: const Text(
          "Next",
          style: TextStyle(
              color: Colors.white, fontSize: 20, overflow: TextOverflow.ellipsis),
          maxLines: 1,
        ));
  }),
);