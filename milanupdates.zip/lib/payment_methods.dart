import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:milan/milan.dart';
import 'package:roundcheckbox/roundcheckbox.dart';

class PaymentMethods extends StatefulWidget {
  const PaymentMethods({super.key});

  @override
  State<PaymentMethods> createState() => _PaymentMethodsState();
}
int currentIndex = 0;
class _PaymentMethodsState extends State<PaymentMethods> {
  @override
  Widget build(BuildContext context) {
    return ScreenUtilInit(
      designSize: const Size(430, 942),
      minTextAdapt: true,
      splitScreenMode: true,
      child: SafeArea(child: Scaffold(
        resizeToAvoidBottomInset: false,
        body: Padding(
          padding:  EdgeInsets.only(left: 18.w, top: 50.h,right: 18.w),
          child: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    GestureDetector(
                      onTap: () {
                        Navigator.pop(context);
                      },
                      child: Container(
            
                        height: 60.h,
                        width: 60.w,
                        decoration: BoxDecoration(
            
                          shape: BoxShape.circle,
                          color: Colors.black.withOpacity(0.025),
                        ),
                        child: const Center(child: Icon(Icons.arrow_back)),
                      ),
                    ),
                    SizedBox(width: 20.w,),
                    Text(
                      "Payment Methods",
                      style: GoogleFonts.gabarito(
                          fontSize: 20.sp, fontWeight: FontWeight.w600),
                    ),
                  ],
                ),
                SizedBox(height: 10.h,),
            Container(
              padding: EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: Colors.black.withOpacity(0.025),
                borderRadius: BorderRadius.circular(20),),
              child: Column(
                children: [
                  Row(
                    children: [
                      Text(
                        "Bank Name",
                        style: GoogleFonts.gabarito(
                            fontSize: 16.sp, fontWeight: FontWeight.w600),
                      ),
                      Spacer(),
                      Container(
                        height: 40.h,
                        width: 40.w,
                        decoration: BoxDecoration(
                            image: DecorationImage(
                              image: AssetImage("assets/images/fi_196578.png"),
                              fit: BoxFit.contain,
                            )
                        ),
                      ),
                    ],
                  ),
                  Row(
                    children: [
                      Text(
                        "xxxx5986",
                        style: GoogleFonts.gabarito(
                            fontSize: 14.sp, fontWeight: FontWeight.w400),
                      ),
                      Spacer(),
                      Text(
                        "John Smith",
                        style: GoogleFonts.gabarito(
                            fontSize: 14.sp, fontWeight: FontWeight.w400),
                      ),
                    ],
                  ),
                ],
              ),
            ),
                SizedBox(height: 10.h,),
                Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                      height: 20.h,
                      width: 20.h,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        border: Border.all(width: 4,color: Colors.black),
                      ),
                    ),
                    SizedBox(width: 10.w,),
                    Text(
                      "Card/Debit/ATM",
                      style: GoogleFonts.gabarito(
                          fontSize: 16.sp, fontWeight: FontWeight.w600),
                    ),
                  ],
                ),
                SizedBox(height: 10.h,),
                Text(
                  "Name on card",
                  style: GoogleFonts.gabarito(
                      fontSize: 16.sp, fontWeight: FontWeight.w500),
                ),
                SizedBox(height: 10.h,),
                _cardNameField,
                SizedBox(height: 10.h,),
                Text(
                  "Card Number",
                  style: GoogleFonts.gabarito(
                      fontSize: 16.sp, fontWeight: FontWeight.w500),
                ),
                SizedBox(height: 10.h,),
                _cardNumberField,
                SizedBox(height: 10.h,),
                Row(
                  children: [
                    Text(
                      "Valid Thru",
                      style: GoogleFonts.gabarito(
                          fontSize: 16.sp, fontWeight: FontWeight.w500),
                    ),
                    SizedBox(width: 60.w,),
                    Text(
                      "CVV",
                      style: GoogleFonts.gabarito(
                          fontSize: 16.sp, fontWeight: FontWeight.w500),
                    ),
                  ],
                ),
                SizedBox(height: 10.h,),
                Row(
                  children: [
                    _validThruField,
                    SizedBox(width: 10.w,),
                     _cVVThruField
                  ],
                ),
                SizedBox(height: 10.h,),
                Row(
                  children: [
                    RoundCheckBox(
                      onTap: (selected) {},
                      size: 25,
                      borderColor: Colors.transparent,
                      isRound: false,
                      checkedColor: Colors.black,
                      uncheckedColor: Colors.black.withOpacity(0.025),
                    ),
                    SizedBox(width: 10.w,),
                    Text(
                      "Save Card",
                      style: GoogleFonts.gabarito(
                          fontSize: 16.sp, fontWeight: FontWeight.w500),
                    ),
                  ],
                ),
                SizedBox(height: 15.h,),
                _submitBoxButton,
                SizedBox(height: 15.h,),
                Divider(color: Colors.black.withOpacity(0.025),),
                SizedBox(height: 5.h,),
                Row(
                  children: [
                    RoundCheckBox(
                      onTap: (selected) {},
                      size: 25,
                      borderColor: Colors.transparent,
                      checkedColor: Colors.black,
                      uncheckedColor: Colors.black.withOpacity(0.025),
                    ),
                    SizedBox(width: 20.w,),
                    Text(
                      "Apple Pay",
                      style: GoogleFonts.gabarito(
                          fontSize: 16.sp, fontWeight: FontWeight.w500),
                    ),
                  ],
                ),
                SizedBox(height: 5.h,),
                Divider(color: Colors.black.withOpacity(0.025),),
                SizedBox(height: 5.h,),
                Row(
                  children: [
                    RoundCheckBox(
                      onTap: (selected) {},
                      size: 25,
                      borderColor: Colors.transparent,
                      checkedColor: Colors.black,
                      uncheckedColor: Colors.black.withOpacity(0.025),
                    ),
                    SizedBox(width: 20.w,),
                    Text(
                      "Amazon Pay",
                      style: GoogleFonts.gabarito(
                          fontSize: 16.sp, fontWeight: FontWeight.w500),
                    ),
                  ],
                ),
                SizedBox(height: 5.h,),
                Divider(color: Colors.black.withOpacity(0.025),),
                SizedBox(height: 5.h,),
                Row(
                  children: [
                    RoundCheckBox(
                      onTap: (selected) {},
                      size: 25,
                      borderColor: Colors.transparent,
                      checkedColor: Colors.black,
                      uncheckedColor: Colors.black.withOpacity(0.025),
                    ),
                    SizedBox(width: 20.w,),
                    Text(
                      "Net-banking",
                      style: GoogleFonts.gabarito(
                          fontSize: 16.sp, fontWeight: FontWeight.w500),
                    ),
                  ],
                ),
                SizedBox(height: 5.h,),
                Divider(color: Colors.black.withOpacity(0.025),),
              ],
            ),
          ),
        )
      )),
    );
  }
}
Widget get _cardNameField =>  Container(

  decoration: BoxDecoration(
      color: Colors.black.withOpacity(0.025),
      borderRadius: BorderRadius.circular(10)
  ),
  child: TextFormField(
    textInputAction: TextInputAction.done,
    keyboardType: TextInputType.text,
    decoration:  InputDecoration(
      fillColor: Colors.black.withOpacity(0.025),
      contentPadding: const EdgeInsets.only(left: 20,right: 10,top: 10,bottom: 10),
      border: InputBorder.none,
      hintText: 'John Smith',
      hintStyle: const TextStyle(
          color: Colors.grey,
          overflow: TextOverflow.ellipsis),
    ),
    maxLines: 1,
  ),
);
Widget get _cardNumberField =>  Container(

  decoration: BoxDecoration(
      color: Colors.black.withOpacity(0.025),
      borderRadius: BorderRadius.circular(10)
  ),
  child: TextFormField(
    textInputAction: TextInputAction.done,
    keyboardType: TextInputType.number,
    decoration:  InputDecoration(
      fillColor: Colors.black.withOpacity(0.025),
      contentPadding: const EdgeInsets.only(left: 20,right: 10,top: 10,bottom: 10),
      border: InputBorder.none,
      hintText: 'XXXX XXXX XXXX',
      hintStyle: const TextStyle(
          color: Colors.grey,
          overflow: TextOverflow.ellipsis),
    ),
    maxLines: 1,
  ),
);
Widget get _validThruField =>  Container(
height: 40.h,
  width: 120.w,
  decoration: BoxDecoration(
      color: Colors.black.withOpacity(0.025),
      borderRadius: BorderRadius.circular(10)
  ),
  child: TextFormField(

    textInputAction: TextInputAction.done,
    keyboardType: TextInputType.number,
    decoration:  InputDecoration(
      fillColor: Colors.black.withOpacity(0.025),
      contentPadding: const EdgeInsets.only(left: 20,right: 10,top: 10,bottom: 10),
      border: InputBorder.none,
      hintText: 'MM/YY',
      hintStyle: const TextStyle(
          color: Colors.grey,
          overflow: TextOverflow.ellipsis),
    ),
    maxLines: 1,
  ),
);
Widget get _cVVThruField =>  Container(
  height: 40.h,
  width: 120.w,
  decoration: BoxDecoration(
      color: Colors.black.withOpacity(0.025),
      borderRadius: BorderRadius.circular(10)
  ),
  child: TextFormField(

    textInputAction: TextInputAction.done,
    keyboardType: TextInputType.number,
    decoration:  InputDecoration(
      fillColor: Colors.black.withOpacity(0.025),
      contentPadding: const EdgeInsets.only(left: 20,right: 10,top: 10,bottom: 10),
      border: InputBorder.none,
      hintText: '000',
      hintStyle: const TextStyle(
          color: Colors.grey,
          overflow: TextOverflow.ellipsis),
    ),
    maxLines: 1,
  ),
);
Widget get _submitBoxButton => SizedBox(
  height: 50.h,
  width: 400.w,
  child: Builder(builder: (context) {
    return ElevatedButton(
        style: ElevatedButton.styleFrom(
          backgroundColor: Colors.black,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(30.0),
          ), // Background color
        ),
        onPressed: () {
          Navigator
              .of(context)
              .push(new MaterialPageRoute(builder: (BuildContext context) {
            return new PaymentSecondScreen();
          }));
        },
        child: const Text(
          "Add Card",
          style: TextStyle(
              color: Colors.white, fontSize: 20, overflow: TextOverflow.ellipsis),
          maxLines: 1,
        ));
  }),
);
Widget get _payBoxButton => SizedBox(
  height: 50.h,
  width: 360.w,
  child: Builder(builder: (context) {
    return ElevatedButton(
        style: ElevatedButton.styleFrom(
          backgroundColor: Colors.black,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(30.0),
          ), // Background color
        ),
        onPressed: () {
          Navigator
              .of(context)
              .push(new MaterialPageRoute(builder: (BuildContext context) {
            return new PayPage();
          }));
        },
        child: const Text(
          "Pay",
          style: TextStyle(
              color: Colors.white, fontSize: 20, overflow: TextOverflow.ellipsis),
          maxLines: 1,
        ));
  }),
);
Widget get _homeButton => SizedBox(
  height: 50.h,
  width: 360.w,
  child: Builder(builder: (context) {
    return ElevatedButton(
        style: ElevatedButton.styleFrom(
          backgroundColor: Colors.black,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(30.0),
          ), // Background color
        ),
        onPressed: () {
          Navigator
              .of(context)
              .pushReplacement(new MaterialPageRoute(builder: (BuildContext context) {
            return new Milan(Index: 0);
          }));
        },
        child: const Text(
          "Back to Home",
          style: TextStyle(
              color: Colors.white, fontSize: 20, overflow: TextOverflow.ellipsis),
          maxLines: 1,
        ));
  }),
);
Widget get _eReceiptButton => SizedBox(
  height: 50.h,
  width: 360.w,
  child: Builder(builder: (context) {
    return ElevatedButton(
        style: ElevatedButton.styleFrom(
          backgroundColor: Colors.black.withOpacity(0.000025),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(30.0),
          ), // Background color
        ),
        onPressed: () {
          // Navigator
          //     .of(context)
          //     .push(new MaterialPageRoute(builder: (BuildContext context) {
          //   return new PayPage();
          // }));
        },
        child: const Text(
          "e-receipt",
          style: TextStyle(
              color: Colors.white, fontSize: 20, overflow: TextOverflow.ellipsis),
          maxLines: 1,
        ));
  }),
);

class PaymentSecondScreen extends StatefulWidget {
  const PaymentSecondScreen({super.key});

  @override
  State<PaymentSecondScreen> createState() => _PaymentSecondScreenState();
}

class _PaymentSecondScreenState extends State<PaymentSecondScreen> {
  List<BankDetails> dataList=[];
  Details(){
    dataList.clear();
    dataList.add(BankDetails(image: "assets/images/fi_196578.png", accNo: "xxxx5986", bankName: "Bank Name", personName: "John Smith"));
    dataList.add(BankDetails(image: "assets/images/mc_symbol 1.png", accNo: "xxxx5986", bankName: "Bank Name", personName: "John Smith"));
 setState(() {

 });
  }
  @override
  void initState() {
    // TODO: implement initState
    Details();
    super.initState();
  }
  @override
  Widget build(BuildContext context) {
    return ScreenUtilInit(
      designSize: const Size(430, 942),
      minTextAdapt: true,
      splitScreenMode: true,
      child: SafeArea(child: Scaffold(
        body: Padding(
          padding: EdgeInsets.only(left: 18.w, top: 50.h,right: 18.w),
          child: Column(
            children: [
              Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  GestureDetector(
                    onTap: () {
                      Navigator.pop(context);
                    },
                    child: Container(

                      height: 60.h,
                      width: 60.w,
                      decoration: BoxDecoration(

                        shape: BoxShape.circle,
                        color: Colors.black.withOpacity(0.025),
                      ),
                      child: const Center(child: Icon(Icons.arrow_back)),
                    ),
                  ),
                  SizedBox(width: 20.w,),
                  Text(
                    "Payment Methods",
                    style: GoogleFonts.gabarito(
                        fontSize: 20.sp, fontWeight: FontWeight.w600),
                  ),
                ],
              ),
              SizedBox(height: 10.h,),
              ListView.builder(
                  itemCount: dataList.length,
                  physics: NeverScrollableScrollPhysics(),
                  shrinkWrap: true,
                  itemBuilder: (context, index) {
                    return GestureDetector(
                      onTap: () {
                        setState(() {
                          currentIndex = index;
                        });
                      },
                      child: Container(
                        padding: EdgeInsets.all(10),
                        decoration: BoxDecoration(
                          color: Colors.black.withOpacity(0.025),
                          borderRadius: BorderRadius.circular(20),
                          border: Border.all(width: 1.5, color: currentIndex == index
                              ? Colors.blue:Colors.transparent),
                        ),
                        margin: EdgeInsets.only(top: 10.h, bottom: 10.h),
                        child: Column(
                          children: [
                            Row(
                              children: [
                                Text(
                                  dataList[index].bankName,
                                  style: GoogleFonts.gabarito(
                                      fontSize: 16.sp, fontWeight: FontWeight.w600),
                                ),
                                Spacer(),
                                Container(
                                  height: 40.h,
                                  width: 40.w,
                                  decoration: BoxDecoration(
                                      image: DecorationImage(
                                        image: AssetImage(dataList[index].image),
                                        fit: BoxFit.contain,
                                      )
                                  ),
                                ),
                              ],
                            ),
                            Row(
                              children: [
                                Text(
                                  dataList[index].accNo,
                                  style: GoogleFonts.gabarito(
                                      fontSize: 14.sp, fontWeight: FontWeight.w400),
                                ),
                                Spacer(),
                                Text(
                                  dataList[index].personName,
                                  style: GoogleFonts.gabarito(
                                      fontSize: 14.sp, fontWeight: FontWeight.w400),
                                ),
                              ],
                            ),
                          ],
                        ),
                      )
                      //     : Container(
                      //   padding: EdgeInsets.all(10),
                      //   decoration: BoxDecoration(
                      //     color: Colors.black.withOpacity(0.025),
                      //     borderRadius: BorderRadius.circular(20),
                      //   ),
                      //   child: Column(
                      //     children: [
                      //       Row(
                      //         children: [
                      //           Text(
                      //             "Bank Name",
                      //             style: GoogleFonts.gabarito(
                      //                 fontSize: 16.sp, fontWeight: FontWeight.w600),
                      //           ),
                      //           Spacer(),
                      //           Container(
                      //             height: 40.h,
                      //             width: 40.w,
                      //             decoration: BoxDecoration(
                      //                 image: DecorationImage(
                      //                   image: AssetImage("assets/images/mc_symbol 1.png"),
                      //                   fit: BoxFit.contain,
                      //                 )
                      //             ),
                      //           ),
                      //         ],
                      //       ),
                      //       Row(
                      //         children: [
                      //           Text(
                      //             "xxxx5986",
                      //             style: GoogleFonts.gabarito(
                      //                 fontSize: 14.sp, fontWeight: FontWeight.w400),
                      //           ),
                      //           Spacer(),
                      //           Text(
                      //             "John Smith",
                      //             style: GoogleFonts.gabarito(
                      //                 fontSize: 14.sp, fontWeight: FontWeight.w400),
                      //           ),
                      //         ],
                      //       ),
                      //     ],
                      //   ),
                      // ),
                    );
                  }),
              SizedBox(height: 10.h,),
              Divider(color: Colors.black.withOpacity(0.025),),
              SizedBox(height: 5.h,),
              Row(
                children: [
                  RoundCheckBox(
                    onTap: (selected) {},
                    size: 25,
                    borderColor: Colors.transparent,
                    checkedColor: Colors.black,
                    uncheckedColor: Colors.black.withOpacity(0.025),
                  ),
                  SizedBox(width: 20.w,),
                  Text(
                    "Card/Debit/ATM",
                    style: GoogleFonts.gabarito(
                        fontSize: 16.sp, fontWeight: FontWeight.w500),
                  ),
                ],
              ),
              SizedBox(height: 5.h,),
              Divider(color: Colors.black.withOpacity(0.025),),
              SizedBox(height: 5.h,),
              Row(
                children: [
                  RoundCheckBox(
                    onTap: (selected) {},
                    size: 25,
                    borderColor: Colors.transparent,
                    checkedColor: Colors.black,
                    uncheckedColor: Colors.black.withOpacity(0.025),
                  ),
                  SizedBox(width: 20.w,),
                  Text(
                    "Apple Pay",
                    style: GoogleFonts.gabarito(
                        fontSize: 16.sp, fontWeight: FontWeight.w500),
                  ),
                ],
              ),
              SizedBox(height: 5.h,),
              Divider(color: Colors.black.withOpacity(0.025),),
              SizedBox(height: 5.h,),
              Row(
                children: [
                  RoundCheckBox(
                    onTap: (selected) {},
                    size: 25,
                    borderColor: Colors.transparent,
                    checkedColor: Colors.black,
                    uncheckedColor: Colors.black.withOpacity(0.025),
                  ),
                  SizedBox(width: 20.w,),
                  Text(
                    "Amazon Pay",
                    style: GoogleFonts.gabarito(
                        fontSize: 16.sp, fontWeight: FontWeight.w500),
                  ),
                ],
              ),
              SizedBox(height: 5.h,),
              Divider(color: Colors.black.withOpacity(0.025),),
              SizedBox(height: 5.h,),
              Row(
                children: [
                  RoundCheckBox(
                    onTap: (selected) {},
                    size: 25,
                    borderColor: Colors.transparent,
                    checkedColor: Colors.black,
                    uncheckedColor: Colors.black.withOpacity(0.025),
                  ),
                  SizedBox(width: 20.w,),
                  Text(
                    "Net-banking",
                    style: GoogleFonts.gabarito(
                        fontSize: 16.sp, fontWeight: FontWeight.w500),
                  ),
                ],
              ),
              SizedBox(height: 5.h,),
              Divider(color: Colors.black.withOpacity(0.025),),
              Spacer(),
              _payBoxButton,
              SizedBox(height: 20.h,)
            ],
          ),
        ),
      )),
    );
  }
}
class PayPage extends StatefulWidget {
  const PayPage({super.key});

  @override
  State<PayPage> createState() => _PayPageState();
}

class _PayPageState extends State<PayPage> {
  @override
  Widget build(BuildContext context) {
    return ScreenUtilInit(
      designSize: const Size(430, 942),
      minTextAdapt: true,
      splitScreenMode: true,
      child: SafeArea(child: Scaffold(
        body: Padding(
          padding:  EdgeInsets.only(left: 18.w,top:300.h,right: 18.w),
          child: Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                  height: 90.h,
                  width: 90.w,
                  decoration: BoxDecoration(
                      image: DecorationImage(
                        image: AssetImage("assets/images/fi_9592255.png"),
                        fit: BoxFit.contain,
                      )
                  ),
                ),
                Text(
                  "Congratulations!!!",
                  style: GoogleFonts.gabarito(
                      fontSize: 20.sp, fontWeight: FontWeight.w600),
                ),
                Text(
                  "Thank you for subscribing.\nWe're excited to have you on board!",
                  style: GoogleFonts.gabarito(
                      fontSize: 16.sp, fontWeight: FontWeight.w400),textAlign: TextAlign.center,
                ),
                Spacer(),
                _homeButton,
                SizedBox(height: 10.h,),
                _eReceiptButton,
                SizedBox(height: 20.h,),
              ],
            ),
          ),
        ),
      )),
    );
  }
}
class BankDetails{
  String bankName;
  String image;
  String personName;
  String accNo;
  BankDetails({required this.image,required this.accNo,required this.bankName,required this.personName});
}
