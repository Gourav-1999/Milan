import 'package:appinio_swiper/appinio_swiper.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:google_fonts/google_fonts.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

List<StoryList> itemList = [];

class _HomePageState extends State<HomePage> {
  final AppinioSwiperController controller = AppinioSwiperController();

  void loadData() {
    itemList.clear();
    itemList.add(StoryList(
      firstName: "Akash",
      image: "assets/images/homepagegirl.png",
      age: "22",
      hobbies: ["Music", "Badminton", "Comics"],
      likes: "22K",
      place: "New York",
      lastName: 'Alex',
    ));
    itemList.add(StoryList(
      firstName: "Akash",
      image: "assets/images/homepagegirl.png",
      age: "22",
      hobbies: ["Music", "Badminton", "Guitar"],
      likes: "22K",
      place: "New York",
      lastName: 'Alex',
    ));
    itemList.add(StoryList(
      firstName: "Akash",
      image: "assets/images/homepagegirl.png",
      age: "22",
      hobbies: ["Music", "Badminton", "Dance"],
      likes: "22K",
      place: "New York",
      lastName: 'Alex',
    ));
    setState(() {});
  }

  @override
  void initState() {
    super.initState();
    Future.delayed(const Duration(seconds: 1), loadData);
  }

  @override
  Widget build(BuildContext context) {
    return ScreenUtilInit(
      designSize: const Size(430, 942),
      minTextAdapt: true,
      splitScreenMode: true,
      child: SafeArea(
        child: Scaffold(
          body: Padding(
            padding: EdgeInsets.only(left: 18.w, top: 30.h, right: 18.w),
            child: Column(
              children: [
                SizedBox(
                  height: MediaQuery.of(context).size.height * 0.75,
                  child: AppinioSwiper(
                    invertAngleOnBottomDrag: true,
                    backgroundCardCount: 1,
                    backgroundCardOffset: Offset(0, 65),
                    cardCount: itemList.length,
                    swipeOptions: const SwipeOptions.all(),
                    cardBuilder: (BuildContext context, int index) {
                      return Stack(
                        children: [
                          Container(
                            margin: EdgeInsets.only(bottom: 50.h),
                            decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(30),
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.black.withOpacity(0.1),
                                  offset: Offset(0, -1),
                                  blurRadius: 20,
                                )
                              ],
                            ),
                            child: Container(
                              decoration: BoxDecoration(
                                image: DecorationImage(
                                  image: AssetImage(itemList[index].image),
                                  fit: BoxFit.fill,
                                ),
                                borderRadius: BorderRadius.circular(20),
                              ),
                            ),
                          ),
                          Positioned(
                            top: 380.h,
                            left: 20.w,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  itemList[index].firstName,
                                  overflow: TextOverflow.ellipsis,
                                  style: GoogleFonts.gabarito(
                                    fontSize: 30.sp,
                                    height:1,
                                    color: Colors.white,
                                    fontWeight: FontWeight.w600,
                                  ),
                                  maxLines: 2,
                                ),
                                Row(
                                  children: [
                                    Text(
                                      "${itemList[index].lastName},",
                                      overflow: TextOverflow.ellipsis,
                                      style: GoogleFonts.gabarito(
                                        fontSize: 30.sp,
                                        height:1,
                                        color: Colors.white,
                                        fontWeight: FontWeight.w600,
                                      ),
                                      maxLines: 2,
                                    ),
                                    SizedBox(width: 5),
                                    Text(
                                      itemList[index].age,
                                      overflow: TextOverflow.ellipsis,
                                      style: GoogleFonts.gabarito(
                                        fontSize: 30.sp,
                                        color: Colors.white,
                                        fontWeight: FontWeight.w600,
                                      ),
                                      maxLines: 2,
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ),
                          Positioned(
                            top: 455.h,
                            left: 20.w,
                            child: Row(
                              children: [
                                Icon(Icons.location_on_outlined, color: Colors.white),
                                Text(
                                  itemList[index].place,
                                  overflow: TextOverflow.ellipsis,
                                  style: GoogleFonts.gabarito(
                                    fontSize: 16.sp,
                                    color: Colors.white,
                                    fontWeight: FontWeight.w400,
                                  ),
                                  maxLines: 1,
                                ),
                              ],
                            ),
                          ),
                          Positioned(
                            top: 490.h,
                            left: 20.w,
                            child: Text(
                              "My name is ${itemList[index].firstName}, wanna make my friend",
                              overflow: TextOverflow.ellipsis,
                              style: GoogleFonts.gabarito(
                                fontSize: 16.sp,
                                color: Colors.white,
                                fontWeight: FontWeight.w400,
                              ),
                              maxLines: 2,
                            ),
                          ),
                          Positioned(
                            top: 520.h,
                            left: 20.w,
                            child: SizedBox(
                              height: 50.h,
                              width: 300.w,
                              child: GridView.builder(
                                physics: NeverScrollableScrollPhysics(),
                                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                                  crossAxisCount: 3,
                                  crossAxisSpacing: 8.0,
                                  mainAxisSpacing: 8.0,
                                  childAspectRatio: 3,
                                ),
                                itemCount: itemList[index].hobbies.length,
                                itemBuilder: (context, hobbyIndex) {
                                  return Container(
                                    decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(15.0),
                                      color: Colors.white.withOpacity(0.085),
                                    ),
                                    alignment: Alignment.center,
                                    child: Text(
                                      itemList[index].hobbies[hobbyIndex],
                                      textAlign: TextAlign.center,
                                      style: TextStyle(color: Colors.white),
                                    ),
                                  );
                                },
                              ),
                            ),
                          ),
                          Positioned(
                            top: 565.h,
                            left: 240.w,
                            child: Container(
                              height: 60.h,
                              width: 60.w,
                              alignment: Alignment.center,
                              decoration: BoxDecoration(
                                  color: Colors.white12,
                                  shape: BoxShape.circle,
                                  boxShadow: [
                                    BoxShadow(
                                        blurRadius: 40,
                                        spreadRadius: 60,
                                        color: Colors.black.withOpacity(0.025))
                                  ]),
                              child: IconButton(
                                icon: Icon(
                                  Icons.message_outlined,
                                  color: Colors.orangeAccent,
                                  size: 30,
                                ),
                                onPressed: () {},
                              ),
                            ),
                          ),
                          Positioned(
                            top: 560.h,
                            left: 160.w,
                            child: Container(
                              height: 70.h,
                              width: 70.w,
                              alignment: Alignment.center,
                              decoration:
                              BoxDecoration(color: Colors.pinkAccent, shape: BoxShape.circle),
                              child: IconButton(
                                icon: Icon(
                                  Icons.add,
                                  color: Colors.white,
                                  size: 30,
                                ),
                                onPressed: () {},
                              ),
                            ),
                          ),
                          Positioned(
                            top: 565.h,
                            left: 90.w,
                            child: Container(
                              height: 60.h,
                              width: 60.w,
                              alignment: Alignment.center,
                              decoration: BoxDecoration(
                                  color: Colors.white12,
                                  shape: BoxShape.circle,
                                  boxShadow: [
                                    BoxShadow(
                                        blurRadius: 40,
                                        spreadRadius: 60,
                                        color: Colors.black.withOpacity(0.025))
                                  ]
                              ),
                              child: IconButton(
                                icon: Icon(
                                  Icons.replay,
                                  color: Colors.red,
                                  size: 30,
                                ),
                                onPressed: () {
                                  Navigator.pop(context);
                                },
                              ),
                            ),
                          ),
                        ],
                      );
                    },
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class StoryList {
  String image;
  String firstName;
  String place;
  String age;
  String likes;
  List<String> hobbies;
  String lastName;

  StoryList({
    required this.lastName,
    required this.firstName,
    required this.image,
    required this.age,
    required this.hobbies,
    required this.likes,
    required this.place,
  });
}
