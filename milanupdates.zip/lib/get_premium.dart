import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:milan/detail_looking_page.dart';
import 'package:milan/detail_name_page.dart';
import 'package:milan/payment_methods.dart';
import 'package:roundcheckbox/roundcheckbox.dart';

import 'custom_select.dart';

class Membership extends StatefulWidget {
  const Membership({super.key});

  @override
  State<Membership> createState() => _MembershipState();
}

@override
class _MembershipState extends State<Membership> {
  int currentIndex = 0;
  List<OptionList> itemList = [];
  List<Feature> dataList = [];
  optionList() {
    itemList.clear();
    itemList.add(OptionList(planStatus: "Current Plan", image: "assets/images/Basic Plan.png", money: "Free", plan: "Basic Plan"));
    itemList.add(OptionList(planStatus: "Per Month", image: "assets/images/Premium Plan.png", money: "\$19.99", plan: "Premium Plan"));
    itemList.add(OptionList(planStatus: "3 Month", image: "assets/images/Dimond Plan.png", money: "\$55.99", plan: "Diamond Plan"));
    setState(() {});
  }

  DataList(){
    dataList.clear();
    dataList.add(Feature(feature: "Unlimited Likes"));
    dataList.add(Feature(feature: "Unlimited Rewinds"));
    dataList.add(Feature(feature: "See who Likes You"));
    dataList.add(Feature(feature: "New Top Picks every day"));
    dataList.add(Feature(feature: "Message before matching"));
    dataList.add(Feature(feature: "Prioritized Likes"));
    dataList.add(Feature(feature: "See the Likes you've sent in the last 7 days"));
    setState(() {

    });
  }

  @override
  void initState() {
    // TODO: implement initState
    optionList();
    DataList();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return ScreenUtilInit(
      designSize: const Size(430, 942),
      minTextAdapt: true,
      splitScreenMode: true,
      child: SafeArea(
          child: Scaffold(
              body: Padding(
                padding: EdgeInsets.only(left: 18.w, top: 50.h,right: 18.w),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        GestureDetector(
                          onTap: () {
                            Navigator.pop(context);
                          },
                          child: Container(

                            height: 60.h,
                            width: 60.w,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              color: Colors.black.withOpacity(0.025),
                            ),
                            child: const Center(child: Icon(Icons.arrow_back)),
                          ),
                        ),
                        SizedBox(width: 20.w,),
                        Text(
                          "Get Premium Plan",
                          style: GoogleFonts.gabarito(
                              fontSize: 20.sp, fontWeight: FontWeight.w600),
                        ),
                      ],
                    ),
                    SizedBox(height: 20.h,),
                    SizedBox(
                      height: 180.h,
                      child: ListView.builder(
                          itemCount: itemList.length,
                          physics: NeverScrollableScrollPhysics(),
                          shrinkWrap: true,
                          scrollDirection: Axis.horizontal,
                          itemBuilder: (context, index) {
                            return GestureDetector(
                              onTap: () {
                                setState(() {
                                  currentIndex = index;
                                });
                              },
                              child: currentIndex == index
                                  ? Container(
                                width: 125.w,
                                margin: EdgeInsets.only(top: 5.h, bottom: 5.h,right: 5.w,left: 5.w),
                                padding: EdgeInsets.all(20),
                                decoration: BoxDecoration(
                                  border:
                                  Border.all(width: 1.5, color: Colors.blue),
                                  color: Colors.black.withOpacity(0.025),
                                  borderRadius: BorderRadius.circular(20.r),
                                ),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Row(
                                      crossAxisAlignment: CrossAxisAlignment.center,
                                      children: [
                                        Container(
                                          height: 40.h,
                                          width: 40.w,
                                          decoration: BoxDecoration(
                                            shape: BoxShape.circle,
                                            image: DecorationImage(
                                              image: AssetImage(itemList[index].image),
                                              fit: BoxFit.cover,
                                            )
                                          ),
                                        ),
                                        Spacer(),
                                        Container(
                                          height: 25.h,
                                          width: 25.w,
                                          decoration: BoxDecoration(
                                              shape: BoxShape.circle,
                                              color: Colors.black,
                                          ),
                                          child: Center(
                                            child: Icon(Icons.done,color: Colors.white,size: 14.sp,weight: 3,),
                                          ),
                                        ),
                                      ],
                                    ),
                                    Text(
                                      itemList[index].plan,
                                      style: GoogleFonts.gabarito(
                                          color: Colors.black,
                                          fontSize: 16.sp, fontWeight: FontWeight.w600
                                      ),
                                      maxLines: 1,
                                    ),
                                    Text(
                                      itemList[index].money,
                                      style: GoogleFonts.gabarito(
                                          color: Colors.blue,
                                          fontSize: 18.sp, fontWeight: FontWeight.w600
                                      ),
                                      maxLines: 1,
                                    ),
                                    Text(
                                      itemList[index].planStatus,
                                      style: GoogleFonts.gabarito(
                                          color: Colors.black,
                                          fontSize: 14.sp, fontWeight: FontWeight.w400
                                      ),
                                      maxLines: 1,
                                    ),
                                  ],
                                ),
                              )
                                  : Container(
                                width: 125.w,
                                decoration: BoxDecoration(
                                  color: Colors.black.withOpacity(0.025),
                                  borderRadius: BorderRadius.circular(20.r),
                                ),
                                margin: EdgeInsets.only(top: 5.h, bottom: 5.h,right: 5.w),
                                padding: EdgeInsets.all(20),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Container(
                                      height: 30.h,
                                      width: 30.w,
                                      decoration: BoxDecoration(
                                          shape: BoxShape.circle,
                                          image: DecorationImage(
                                            image: AssetImage(itemList[index].image),
                                            fit: BoxFit.cover,
                                          )
                                      ),
                                    ),
                                    Text(
                                      itemList[index].plan,
                                      style: GoogleFonts.gabarito(

                                          fontSize: 16.sp, fontWeight: FontWeight.w600
                                      ),
                                      maxLines: 1,
                                    ),
                                    Text(
                                      itemList[index].money,
                                      style: GoogleFonts.gabarito(

                                          fontSize: 18.sp, fontWeight: FontWeight.w600
                                      ),
                                      maxLines: 1,
                                    ),
                                    Text(
                                      itemList[index].planStatus,
                                      style: GoogleFonts.gabarito(

                                          fontSize: 14.sp, fontWeight: FontWeight.w400
                                      ),
                                      maxLines: 1,
                                    ),
                                  ],
                                ),
                              ),
                            );
                          }),
                    ),
                    SizedBox(height: 20.h,),
                    Container(
                      padding: EdgeInsets.all(20),
                      decoration: BoxDecoration(
                        color: Colors.black.withOpacity(0.025),
                        borderRadius: BorderRadius.circular(20),),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            "Feature Included",
                            style: GoogleFonts.gabarito(
                                fontSize: 20.sp, fontWeight: FontWeight.w600),
                          ),
                          ListView.builder(
                              itemCount: dataList.length,
                              physics: NeverScrollableScrollPhysics(),
                              shrinkWrap: true,
                              itemBuilder: (context, index) {
                                return Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Row(
                                      crossAxisAlignment: CrossAxisAlignment.center,
                                      children: [
                                        Container(
                                          height: 25.h,
                                          width: 25.w,
                                          margin: EdgeInsets.only(bottom: 5.h,top: 5.h),
                                          decoration: BoxDecoration(
                                            shape: BoxShape.circle,
                                            color: Colors.white70
                                          ),
                                          child: Center(
                                            child: Icon(Icons.done,color: Colors.black,size: 14,weight: 3,),
                                          ),
                                        ),
                                        SizedBox(width: 10.w,),
                                        Text(
                                          dataList[index].feature,
                                          style: GoogleFonts.gabarito(
                                              fontSize: 14.sp, fontWeight: FontWeight.w400),
                                        ),
                                      ],
                                    ),
                                  ],
                                );
                              }),
                        ],
                      ),
                    ),
                    Spacer(),
                    Center(child: _submitBoxButton),
                    SizedBox(height: 10.h,)
                  ],
                ),
              ))),
    );
  }
}
Widget get _submitBoxButton => SizedBox(
  height: 58.h,
  width: 360.w,
  child: Builder(builder: (context) {
    return ElevatedButton(
        style: ElevatedButton.styleFrom(
          backgroundColor: Colors.black,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(25.0),
          ), // Background color
        ),
        onPressed: () {
          Navigator
              .of(context)
              .push(new MaterialPageRoute(builder: (BuildContext context) {
            return new PaymentSecondScreen();
          }));
        },
        child: const Text(
          "Buy Now",
          style: TextStyle(
              color: Colors.white, fontSize: 20, overflow: TextOverflow.ellipsis),
          maxLines: 1,
        ));
  }),
);
class OptionList {
  String plan;
  String image;
  String money;
  String planStatus;

  OptionList({required this.planStatus, required this.image,required this.money,required this.plan});
}
class Feature{
  String feature;
  Feature({required this.feature});
}